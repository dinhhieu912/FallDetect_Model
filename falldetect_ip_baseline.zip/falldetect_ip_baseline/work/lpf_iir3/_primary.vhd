library verilog;
use verilog.vl_types.all;
entity lpf_iir3 is
    generic(
        WIDTH           : integer := 16;
        SHIFT           : integer := 4
    );
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        input_valid     : in     vl_logic;
        input_ready     : out    vl_logic;
        input_x         : in     vl_logic_vector;
        input_y         : in     vl_logic_vector;
        input_z         : in     vl_logic_vector;
        output_valid    : out    vl_logic;
        output_ready    : in     vl_logic;
        output_x        : out    vl_logic_vector;
        output_y        : out    vl_logic_vector;
        output_z        : out    vl_logic_vector
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of WIDTH : constant is 2;
    attribute mti_svvh_generic_type of SHIFT : constant is 2;
end lpf_iir3;
