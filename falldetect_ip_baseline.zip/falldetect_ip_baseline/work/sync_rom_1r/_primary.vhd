library verilog;
use verilog.vl_types.all;
entity sync_rom_1r is
    generic(
        DATA_WIDTH      : integer := 32;
        DEPTH           : integer := 256;
        MEM_FILE        : string  := "memory.mem"
    );
    port(
        clk             : in     vl_logic;
        en              : in     vl_logic;
        addr            : in     vl_logic_vector;
        data            : out    vl_logic_vector
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of DATA_WIDTH : constant is 2;
    attribute mti_svvh_generic_type of DEPTH : constant is 2;
    attribute mti_svvh_generic_type of MEM_FILE : constant is 1;
end sync_rom_1r;
