library verilog;
use verilog.vl_types.all;
entity dense_engine is
    generic(
        IN_FEATURES     : integer := 32;
        OUT_FEATURES    : integer := 16;
        NUM_MAC         : integer := 4;
        INPUT_ZERO_POINT: integer := -128;
        OUTPUT_ZERO_POINT: integer := -128;
        ACTIVATION_MIN  : integer := -128;
        ACTIVATION_MAX  : integer := 127;
        WEIGHT_MEM_FILE : string  := "mem/dense1_weight_lane4.mem";
        BIAS_MEM_FILE   : string  := "mem/dense1_bias.mem";
        MULTIPLIER_MEM_FILE: string  := "mem/dense1_multiplier.mem";
        RSHIFT_MEM_FILE : string  := "mem/dense1_rshift.mem";
        OUT_WIDTH       : vl_logic_vector(31 downto 0)
    );
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        input_valid     : in     vl_logic;
        input_ready     : out    vl_logic;
        input_data      : in     vl_logic_vector(7 downto 0);
        command_valid   : in     vl_logic;
        command_ready   : out    vl_logic;
        output_valid    : out    vl_logic;
        output_ready    : in     vl_logic;
        output_data     : out    vl_logic_vector(7 downto 0);
        output_feature  : out    vl_logic_vector;
        busy            : out    vl_logic;
        done            : out    vl_logic
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of IN_FEATURES : constant is 2;
    attribute mti_svvh_generic_type of OUT_FEATURES : constant is 2;
    attribute mti_svvh_generic_type of NUM_MAC : constant is 2;
    attribute mti_svvh_generic_type of INPUT_ZERO_POINT : constant is 2;
    attribute mti_svvh_generic_type of OUTPUT_ZERO_POINT : constant is 2;
    attribute mti_svvh_generic_type of ACTIVATION_MIN : constant is 2;
    attribute mti_svvh_generic_type of ACTIVATION_MAX : constant is 2;
    attribute mti_svvh_generic_type of WEIGHT_MEM_FILE : constant is 1;
    attribute mti_svvh_generic_type of BIAS_MEM_FILE : constant is 1;
    attribute mti_svvh_generic_type of MULTIPLIER_MEM_FILE : constant is 1;
    attribute mti_svvh_generic_type of RSHIFT_MEM_FILE : constant is 1;
    attribute mti_svvh_generic_type of OUT_WIDTH : constant is 4;
end dense_engine;
