library verilog;
use verilog.vl_types.all;
entity global_avg_pool_int8 is
    generic(
        IN_LENGTH       : integer := 12;
        CHANNELS        : integer := 32;
        INPUT_ZERO_POINT: integer := -128;
        OUTPUT_ZERO_POINT: integer := -128;
        MULTIPLIER_Q31  : vl_logic_vector(31 downto 0) := (Hi0, Hi1, Hi0, Hi0, Hi1, Hi1, Hi0, Hi1, Hi1, Hi1, Hi1, Hi1, Hi1, Hi1, Hi0, Hi0, Hi0, Hi0, Hi0, Hi0, Hi1, Hi0, Hi1, Hi1, Hi0, Hi0, Hi1, Hi0, Hi0, Hi0, Hi0, Hi0);
        RIGHT_SHIFT     : integer := 2;
        POS_WIDTH       : vl_logic_vector(31 downto 0);
        CH_WIDTH        : vl_logic_vector(31 downto 0)
    );
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        input_valid     : in     vl_logic;
        input_ready     : out    vl_logic;
        input_data      : in     vl_logic_vector(7 downto 0);
        input_position  : in     vl_logic_vector;
        input_channel   : in     vl_logic_vector;
        output_valid    : out    vl_logic;
        output_ready    : in     vl_logic;
        output_data     : out    vl_logic_vector(7 downto 0);
        output_channel  : out    vl_logic_vector;
        done            : out    vl_logic
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of IN_LENGTH : constant is 2;
    attribute mti_svvh_generic_type of CHANNELS : constant is 2;
    attribute mti_svvh_generic_type of INPUT_ZERO_POINT : constant is 2;
    attribute mti_svvh_generic_type of OUTPUT_ZERO_POINT : constant is 2;
    attribute mti_svvh_generic_type of MULTIPLIER_Q31 : constant is 2;
    attribute mti_svvh_generic_type of RIGHT_SHIFT : constant is 2;
    attribute mti_svvh_generic_type of POS_WIDTH : constant is 4;
    attribute mti_svvh_generic_type of CH_WIDTH : constant is 4;
end global_avg_pool_int8;
