library verilog;
use verilog.vl_types.all;
entity fall_detect_apb_top is
    generic(
        LPF_SHIFT       : integer := 4;
        ENERGY_WIDTH    : integer := 40
    );
    port(
        PCLK            : in     vl_logic;
        PRESETn         : in     vl_logic;
        PSEL            : in     vl_logic;
        PENABLE         : in     vl_logic;
        PWRITE          : in     vl_logic;
        PADDR           : in     vl_logic_vector(7 downto 0);
        PWDATA          : in     vl_logic_vector(31 downto 0);
        PRDATA          : out    vl_logic_vector(31 downto 0);
        PREADY          : out    vl_logic;
        PSLVERR         : out    vl_logic;
        sample_valid    : in     vl_logic;
        sample_ready    : out    vl_logic;
        accel_x         : in     vl_logic_vector(15 downto 0);
        accel_y         : in     vl_logic_vector(15 downto 0);
        accel_z         : in     vl_logic_vector(15 downto 0);
        cnn_features_int8: in     vl_logic_vector(71 downto 0);
        irq             : out    vl_logic
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of LPF_SHIFT : constant is 2;
    attribute mti_svvh_generic_type of ENERGY_WIDTH : constant is 2;
end fall_detect_apb_top;
