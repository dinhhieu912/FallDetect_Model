library verilog;
use verilog.vl_types.all;
entity fall_cnn_int8_top is
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        input_valid     : in     vl_logic;
        input_ready     : out    vl_logic;
        input_data      : in     vl_logic_vector(7 downto 0);
        start_valid     : in     vl_logic;
        start_ready     : out    vl_logic;
        output_valid    : out    vl_logic;
        output_ready    : in     vl_logic;
        output_logit    : out    vl_logic_vector(7 downto 0);
        fall_detected   : out    vl_logic;
        done            : out    vl_logic
    );
end fall_cnn_int8_top;
