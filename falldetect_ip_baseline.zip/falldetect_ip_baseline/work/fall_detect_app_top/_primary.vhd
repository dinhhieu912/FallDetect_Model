library verilog;
use verilog.vl_types.all;
entity fall_detect_app_top is
    generic(
        LPF_SHIFT       : integer := 4;
        ENERGY_WIDTH    : integer := 40
    );
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        sample_valid    : in     vl_logic;
        sample_ready    : out    vl_logic;
        accel_x         : in     vl_logic_vector(15 downto 0);
        accel_y         : in     vl_logic_vector(15 downto 0);
        accel_z         : in     vl_logic_vector(15 downto 0);
        cnn_features_int8: in     vl_logic_vector(71 downto 0);
        cfg_accel_threshold: in     vl_logic_vector;
        cfg_jerk_threshold: in     vl_logic_vector;
        cfg_consecutive : in     vl_logic_vector(7 downto 0);
        event_valid     : out    vl_logic;
        event_ready     : in     vl_logic;
        event_logit     : out    vl_logic_vector(7 downto 0);
        event_fall      : out    vl_logic;
        dsp_armed       : out    vl_logic;
        cnn_active      : out    vl_logic
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of LPF_SHIFT : constant is 2;
    attribute mti_svvh_generic_type of ENERGY_WIDTH : constant is 2;
end fall_detect_app_top;
