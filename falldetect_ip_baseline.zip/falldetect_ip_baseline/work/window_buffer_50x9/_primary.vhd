library verilog;
use verilog.vl_types.all;
entity window_buffer_50x9 is
    generic(
        WINDOW_LENGTH   : integer := 50;
        FEATURES        : integer := 9
    );
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        sample_valid    : in     vl_logic;
        sample_ready    : out    vl_logic;
        sample_features : in     vl_logic_vector;
        trigger         : in     vl_logic;
        resume_capture  : in     vl_logic;
        window_full     : out    vl_logic;
        output_valid    : out    vl_logic;
        output_ready    : in     vl_logic;
        output_data     : out    vl_logic_vector(7 downto 0);
        done            : out    vl_logic
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of WINDOW_LENGTH : constant is 2;
    attribute mti_svvh_generic_type of FEATURES : constant is 2;
end window_buffer_50x9;
