library verilog;
use verilog.vl_types.all;
entity dsp_trigger_fsm is
    generic(
        ENERGY_WIDTH    : integer := 40
    );
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        energy_valid    : in     vl_logic;
        accel_energy    : in     vl_logic_vector;
        jerk_energy     : in     vl_logic_vector;
        window_full     : in     vl_logic;
        cfg_accel_threshold: in     vl_logic_vector;
        cfg_jerk_threshold: in     vl_logic_vector;
        cfg_consecutive : in     vl_logic_vector(7 downto 0);
        rearm           : in     vl_logic;
        armed           : out    vl_logic;
        trigger         : out    vl_logic
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of ENERGY_WIDTH : constant is 2;
end dsp_trigger_fsm;
