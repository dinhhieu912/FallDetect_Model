library verilog;
use verilog.vl_types.all;
entity requantize_int8 is
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        in_valid        : in     vl_logic;
        in_ready        : out    vl_logic;
        accumulator     : in     vl_logic_vector(31 downto 0);
        multiplier_q31  : in     vl_logic_vector(31 downto 0);
        right_shift     : in     vl_logic_vector(5 downto 0);
        output_zero_point: in     vl_logic_vector(31 downto 0);
        activation_min  : in     vl_logic_vector(31 downto 0);
        activation_max  : in     vl_logic_vector(31 downto 0);
        out_valid       : out    vl_logic;
        out_data        : out    vl_logic_vector(7 downto 0)
    );
end requantize_int8;
