library verilog;
use verilog.vl_types.all;
entity maxpool1d_stream is
    generic(
        IN_LENGTH       : integer := 50;
        CHANNELS        : integer := 16;
        POS_WIDTH       : vl_logic_vector(31 downto 0);
        CH_WIDTH        : vl_logic_vector(31 downto 0)
    );
    port(
        clk             : in     vl_logic;
        rst_n           : in     vl_logic;
        input_valid     : in     vl_logic;
        input_ready     : out    vl_logic;
        input_data      : in     vl_logic_vector(7 downto 0);
        input_position  : in     vl_logic_vector;
        input_channel   : in     vl_logic_vector;
        output_valid    : out    vl_logic;
        output_ready    : in     vl_logic;
        output_data     : out    vl_logic_vector(7 downto 0);
        output_position : out    vl_logic_vector;
        output_channel  : out    vl_logic_vector;
        done            : out    vl_logic
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of IN_LENGTH : constant is 2;
    attribute mti_svvh_generic_type of CHANNELS : constant is 2;
    attribute mti_svvh_generic_type of POS_WIDTH : constant is 4;
    attribute mti_svvh_generic_type of CH_WIDTH : constant is 4;
end maxpool1d_stream;
