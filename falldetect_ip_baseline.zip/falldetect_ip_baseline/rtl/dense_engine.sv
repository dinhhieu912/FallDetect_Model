`timescale 1ns/1ps

module dense_engine #(
    parameter integer IN_FEATURES = 32,
    parameter integer OUT_FEATURES = 16,
    parameter integer NUM_MAC = 4,
    parameter integer INPUT_ZERO_POINT = -128,
    parameter integer OUTPUT_ZERO_POINT = -128,
    parameter integer ACTIVATION_MIN = -128,
    parameter integer ACTIVATION_MAX = 127,
    parameter WEIGHT_MEM_FILE = "mem/dense1_weight_lane4.mem",
    parameter BIAS_MEM_FILE = "mem/dense1_bias.mem",
    parameter MULTIPLIER_MEM_FILE = "mem/dense1_multiplier.mem",
    parameter RSHIFT_MEM_FILE = "mem/dense1_rshift.mem",
    parameter integer OUT_WIDTH = (OUT_FEATURES <= 1) ? 1 : $clog2(OUT_FEATURES)
) (
    input logic clk, input logic rst_n,
    input logic input_valid, output logic input_ready,
    input logic signed [7:0] input_data,
    input logic command_valid, output logic command_ready,
    output logic output_valid, input logic output_ready,
    output logic signed [7:0] output_data,
    output logic [OUT_WIDTH-1:0] output_feature,
    output logic busy, output logic done
);
    localparam integer GROUPS=OUT_FEATURES/NUM_MAC;
    localparam integer GROUP_WIDTH=(GROUPS<=1)?1:$clog2(GROUPS);
    localparam integer INPUT_WIDTH=(IN_FEATURES<=1)?1:$clog2(IN_FEATURES);
    localparam integer LOAD_WIDTH=$clog2(IN_FEATURES+1);
    localparam integer WEIGHT_DEPTH=GROUPS*IN_FEATURES;

    typedef enum logic[3:0]{ST_LOAD,ST_READY,ST_INIT,ST_WEIGHT_READ,ST_MAC,
        ST_RQ,ST_RQ_WAIT,ST_OUTPUT} state_t;
    state_t state;
    logic signed[7:0] input_mem[0:IN_FEATURES-1];
    logic signed[31:0] bias_mem[0:OUT_FEATURES-1];
    logic signed[31:0] multiplier_mem[0:OUT_FEATURES-1];
    logic[7:0] rshift_mem[0:OUT_FEATURES-1];
    logic[LOAD_WIDTH-1:0] load_count;
    logic[GROUP_WIDTH-1:0] output_group;
    logic[INPUT_WIDTH-1:0] input_index;
    logic[((NUM_MAC<=1)?1:$clog2(NUM_MAC))-1:0] output_lane;
    logic[$clog2(WEIGHT_DEPTH)-1:0] weight_addr;
    logic weight_en;
    logic[NUM_MAC*8-1:0] weight_word;
    logic signed[31:0] accumulator[0:NUM_MAC-1];
    logic signed[7:0] lane_weight[0:NUM_MAC-1];
    logic signed[8:0] centered_input;
    logic signed[16:0] lane_product[0:NUM_MAC-1];
    logic[NUM_MAC-1:0] rq_in_valid,rq_out_valid;
    logic signed[7:0] rq_data[0:NUM_MAC-1];
    integer lane;

    initial begin
        if((OUT_FEATURES%NUM_MAC)!=0)$fatal(1,"OUT_FEATURES must divide NUM_MAC");
        $readmemh(BIAS_MEM_FILE,bias_mem);
        $readmemh(MULTIPLIER_MEM_FILE,multiplier_mem);
        $readmemh(RSHIFT_MEM_FILE,rshift_mem);
    end
    sync_rom_1r #(.DATA_WIDTH(NUM_MAC*8),.DEPTH(WEIGHT_DEPTH),.MEM_FILE(WEIGHT_MEM_FILE)) rom(
        .clk,.en(weight_en),.addr(weight_addr),.data(weight_word));
    assign centered_input=$signed(input_mem[input_index])-$signed(INPUT_ZERO_POINT);
    generate for(genvar g=0;g<NUM_MAC;g++)begin:lanes
        assign lane_weight[g]=$signed(weight_word[g*8+:8]);
        assign lane_product[g]=$signed(centered_input)*$signed(lane_weight[g]);
        requantize_int8 rq(.clk,.rst_n,.in_valid(rq_in_valid[g]),.in_ready(),
            .accumulator(accumulator[g]),
            .multiplier_q31(multiplier_mem[output_group*NUM_MAC+g]),
            .right_shift(rshift_mem[output_group*NUM_MAC+g][5:0]),
            .output_zero_point(OUTPUT_ZERO_POINT),
            .activation_min(ACTIVATION_MIN),.activation_max(ACTIVATION_MAX),
            .out_valid(rq_out_valid[g]),.out_data(rq_data[g]));
    end endgenerate

    always_comb begin
        input_ready=0;command_ready=0;output_valid=0;output_data=0;busy=0;weight_en=0;rq_in_valid='0;
        weight_addr=output_group*IN_FEATURES+input_index;
        output_feature=output_group*NUM_MAC+output_lane;
        case(state)
            ST_LOAD:input_ready=1;
            ST_READY:command_ready=1;
            ST_WEIGHT_READ:begin busy=1;weight_en=1;end
            ST_RQ:begin busy=1;rq_in_valid='1;end
            ST_RQ_WAIT:busy=1;
            ST_OUTPUT:begin busy=1;output_valid=1;output_data=rq_data[output_lane];end
            default:busy=1;
        endcase
    end
    always_ff@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin state<=ST_LOAD;load_count<='0;output_group<='0;input_index<='0;output_lane<='0;done<=0;
            for(lane=0;lane<NUM_MAC;lane++)accumulator[lane]<='0;
        end else begin
            done<=0;
            case(state)
                ST_LOAD:if(input_valid&&input_ready)begin
                    input_mem[load_count]<=input_data;
                    if(load_count==IN_FEATURES-1)begin load_count<='0;state<=ST_READY;end
                    else load_count<=load_count+1'b1;
                end
                ST_READY:if(command_valid&&command_ready)begin output_group<='0;state<=ST_INIT;end
                ST_INIT:begin input_index<='0;output_lane<='0;
                    for(lane=0;lane<NUM_MAC;lane++)accumulator[lane]<=bias_mem[output_group*NUM_MAC+lane];
                    state<=ST_WEIGHT_READ;
                end
                ST_WEIGHT_READ:state<=ST_MAC;
                ST_MAC:begin
                    for(lane=0;lane<NUM_MAC;lane++)accumulator[lane]<=accumulator[lane]+lane_product[lane];
                    if(input_index==IN_FEATURES-1)state<=ST_RQ;
                    else begin input_index<=input_index+1'b1;state<=ST_WEIGHT_READ;end
                end
                ST_RQ:state<=ST_RQ_WAIT;
                ST_RQ_WAIT:if(rq_out_valid[0])begin output_lane<='0;state<=ST_OUTPUT;end
                ST_OUTPUT:if(output_valid&&output_ready)begin
                    if(output_lane<NUM_MAC-1)output_lane<=output_lane+1'b1;
                    else if(output_group<GROUPS-1)begin output_group<=output_group+1'b1;state<=ST_INIT;end
                    else begin done<=1;load_count<='0;state<=ST_LOAD;end
                end
                default:state<=ST_LOAD;
            endcase
        end
    end
endmodule
