`timescale 1ns/1ps

module fall_cnn_int8_top (
    input  logic                 clk,
    input  logic                 rst_n,
    input  logic                 input_valid,
    output logic                 input_ready,
    input  logic signed [7:0]    input_data,
    input  logic                 start_valid,
    output logic                 start_ready,
    output logic                 output_valid,
    input  logic                 output_ready,
    output logic signed [7:0]    output_logit,
    output logic                 fall_detected,
    output logic                 done
);
    logic c1_valid,c1_ready; logic signed[7:0] c1_data; logic[5:0] c1_pos; logic[3:0] c1_ch;
    logic p1_valid,p1_ready; logic signed[7:0] p1_data; logic[4:0] p1_pos; logic[3:0] p1_ch;
    logic c2_valid,c2_ready,c2_cmd_ready; logic signed[7:0] c2_data; logic[4:0] c2_pos,c2_ch;
    logic p2_valid,p2_ready; logic signed[7:0] p2_data; logic[3:0] p2_pos; logic[4:0] p2_ch;
    logic gap_valid,gap_ready; logic signed[7:0] gap_data; logic[4:0] gap_ch;
    logic d1_valid,d1_ready,d1_cmd_ready; logic signed[7:0] d1_data; logic[3:0] d1_feature;
    logic d2_cmd_ready; logic[0:0] d2_feature;
    logic c1_cmd_ready;

    assign start_ready = c1_cmd_ready;
    assign fall_detected = output_valid && ($signed(output_logit) > -8'sd14);

    conv1d_engine conv1 (
        .clk,.rst_n,.input_valid,.input_ready,.input_data,
        .command_valid(start_valid),.command_ready(c1_cmd_ready),
        .output_valid(c1_valid),.output_ready(c1_ready),.output_data(c1_data),
        .output_position(c1_pos),.output_channel(c1_ch),.busy(),.done()
    );
    maxpool1d_stream #(.IN_LENGTH(50),.CHANNELS(16)) pool1 (
        .clk,.rst_n,.input_valid(c1_valid),.input_ready(c1_ready),.input_data(c1_data),
        .input_position(c1_pos),.input_channel(c1_ch),
        .output_valid(p1_valid),.output_ready(p1_ready),.output_data(p1_data),
        .output_position(p1_pos),.output_channel(p1_ch),.done()
    );
    conv1d_engine #(
        .IN_LENGTH(25),.IN_CHANNELS(16),.OUT_CHANNELS(32),.KERNEL_SIZE(3),.NUM_MAC(4),
        .INPUT_ZERO_POINT(-128),.OUTPUT_ZERO_POINT(-128),
        .WEIGHT_MEM_FILE("mem/conv2_weight_lane4.mem"),.BIAS_MEM_FILE("mem/conv2_bias.mem"),
        .MULTIPLIER_MEM_FILE("mem/conv2_multiplier.mem"),.RSHIFT_MEM_FILE("mem/conv2_rshift.mem")
    ) conv2 (
        .clk,.rst_n,.input_valid(p1_valid),.input_ready(p1_ready),.input_data(p1_data),
        .command_valid(c2_cmd_ready),.command_ready(c2_cmd_ready),
        .output_valid(c2_valid),.output_ready(c2_ready),.output_data(c2_data),
        .output_position(c2_pos),.output_channel(c2_ch),.busy(),.done()
    );
    maxpool1d_stream #(.IN_LENGTH(25),.CHANNELS(32)) pool2 (
        .clk,.rst_n,.input_valid(c2_valid),.input_ready(c2_ready),.input_data(c2_data),
        .input_position(c2_pos),.input_channel(c2_ch),
        .output_valid(p2_valid),.output_ready(p2_ready),.output_data(p2_data),
        .output_position(p2_pos),.output_channel(p2_ch),.done()
    );
    global_avg_pool_int8 gap (
        .clk,.rst_n,.input_valid(p2_valid),.input_ready(p2_ready),.input_data(p2_data),
        .input_position(p2_pos),.input_channel(p2_ch),
        .output_valid(gap_valid),.output_ready(gap_ready),.output_data(gap_data),
        .output_channel(gap_ch),.done()
    );
    dense_engine dense1 (
        .clk,.rst_n,.input_valid(gap_valid),.input_ready(gap_ready),.input_data(gap_data),
        .command_valid(d1_cmd_ready),.command_ready(d1_cmd_ready),
        .output_valid(d1_valid),.output_ready(d1_ready),.output_data(d1_data),
        .output_feature(d1_feature),.busy(),.done()
    );
    dense_engine #(
        .IN_FEATURES(16),.OUT_FEATURES(1),.NUM_MAC(1),
        .INPUT_ZERO_POINT(-128),.OUTPUT_ZERO_POINT(-14),
        .WEIGHT_MEM_FILE("mem/dense2_weight_lane1.mem"),.BIAS_MEM_FILE("mem/dense2_bias.mem"),
        .MULTIPLIER_MEM_FILE("mem/dense2_multiplier.mem"),.RSHIFT_MEM_FILE("mem/dense2_rshift.mem")
    ) dense2 (
        .clk,.rst_n,.input_valid(d1_valid),.input_ready(d1_ready),.input_data(d1_data),
        .command_valid(d2_cmd_ready),.command_ready(d2_cmd_ready),
        .output_valid,.output_ready,.output_data(output_logit),
        .output_feature(d2_feature),.busy(),.done
    );
endmodule
