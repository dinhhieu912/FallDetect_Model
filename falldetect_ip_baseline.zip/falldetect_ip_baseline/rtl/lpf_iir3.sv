`timescale 1ns/1ps

module lpf_iir3 #(
    parameter integer WIDTH = 16,
    parameter integer SHIFT = 4
) (
    input logic clk, input logic rst_n,
    input logic input_valid, output logic input_ready,
    input logic signed [WIDTH-1:0] input_x,input_y,input_z,
    output logic output_valid, input logic output_ready,
    output logic signed [WIDTH-1:0] output_x,output_y,output_z
);
    logic signed[WIDTH-1:0] state_x,state_y,state_z;
    logic signed[WIDTH:0] delta_x,delta_y,delta_z;
    logic signed[WIDTH:0] next_x_ext,next_y_ext,next_z_ext;
    assign delta_x=$signed({input_x[WIDTH-1],input_x})-$signed({state_x[WIDTH-1],state_x});
    assign delta_y=$signed({input_y[WIDTH-1],input_y})-$signed({state_y[WIDTH-1],state_y});
    assign delta_z=$signed({input_z[WIDTH-1],input_z})-$signed({state_z[WIDTH-1],state_z});
    assign next_x_ext=$signed({state_x[WIDTH-1],state_x})+($signed(delta_x)>>>SHIFT);
    assign next_y_ext=$signed({state_y[WIDTH-1],state_y})+($signed(delta_y)>>>SHIFT);
    assign next_z_ext=$signed({state_z[WIDTH-1],state_z})+($signed(delta_z)>>>SHIFT);
    assign input_ready=!output_valid||output_ready;
    always_ff@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin state_x<='0;state_y<='0;state_z<='0;output_valid<=0;output_x<='0;output_y<='0;output_z<='0;end
        else begin
            if(output_valid&&output_ready)output_valid<=0;
            if(input_valid&&input_ready)begin
                state_x<=next_x_ext[WIDTH-1:0];state_y<=next_y_ext[WIDTH-1:0];state_z<=next_z_ext[WIDTH-1:0];
                output_x<=next_x_ext[WIDTH-1:0];output_y<=next_y_ext[WIDTH-1:0];output_z<=next_z_ext[WIDTH-1:0];
                output_valid<=1;
            end
        end
    end
endmodule
