`timescale 1ns/1ps

module fall_detect_apb_top #(
    parameter integer LPF_SHIFT=4,
    parameter integer ENERGY_WIDTH=40
) (
    input logic PCLK,input logic PRESETn,
    input logic PSEL,input logic PENABLE,input logic PWRITE,
    input logic[7:0] PADDR,input logic[31:0] PWDATA,
    output logic[31:0] PRDATA,output logic PREADY,output logic PSLVERR,
    input logic sample_valid,output logic sample_ready,
    input logic signed[15:0] accel_x,accel_y,accel_z,
    input logic[71:0] cnn_features_int8,
    output logic irq
);
    localparam logic[7:0] ADDR_ID          =8'h00;
    localparam logic[7:0] ADDR_CONTROL     =8'h04;
    localparam logic[7:0] ADDR_STATUS      =8'h08;
    localparam logic[7:0] ADDR_ACCEL_LO    =8'h0C;
    localparam logic[7:0] ADDR_ACCEL_HI    =8'h10;
    localparam logic[7:0] ADDR_JERK_LO     =8'h14;
    localparam logic[7:0] ADDR_JERK_HI     =8'h18;
    localparam logic[7:0] ADDR_TRIGGER_CFG =8'h1C;
    localparam logic[7:0] ADDR_EVENT       =8'h20;
    localparam logic[7:0] ADDR_IRQ_STATUS  =8'h24;

    logic enable,irq_enable;
    logic[ENERGY_WIDTH-1:0] cfg_accel_threshold,cfg_jerk_threshold;
    logic[7:0] cfg_consecutive;
    logic app_sample_ready,app_event_valid,app_event_ready,app_event_fall,dsp_armed,cnn_active;
    logic signed[7:0] app_event_logit,event_logit_reg;
    logic event_fall_reg,event_pending;
    logic apb_write,valid_address;

    assign PREADY=1'b1;
    assign apb_write=PSEL&&PENABLE&&PWRITE;
    assign sample_ready=enable&&app_sample_ready;
    assign app_event_ready=!event_pending;
    assign irq=irq_enable&&event_pending;

    always @* begin
        valid_address=1'b1;
        case(PADDR)
            ADDR_ID:          PRDATA=32'h46414C4C; // "FALL"
            ADDR_CONTROL:     PRDATA={30'd0,irq_enable,enable};
            ADDR_STATUS:      PRDATA={28'd0,sample_ready,event_pending,cnn_active,dsp_armed};
            ADDR_ACCEL_LO:    PRDATA=cfg_accel_threshold[31:0];
            ADDR_ACCEL_HI:    PRDATA={24'd0,cfg_accel_threshold[39:32]};
            ADDR_JERK_LO:     PRDATA=cfg_jerk_threshold[31:0];
            ADDR_JERK_HI:     PRDATA={24'd0,cfg_jerk_threshold[39:32]};
            ADDR_TRIGGER_CFG: PRDATA={24'd0,cfg_consecutive};
            ADDR_EVENT:       PRDATA={23'd0,event_fall_reg,event_logit_reg};
            ADDR_IRQ_STATUS:  PRDATA={31'd0,event_pending};
            default:begin PRDATA=32'd0;valid_address=1'b0;end
        endcase
        PSLVERR=PSEL&&PENABLE&&((PADDR[1:0]!=2'b00)||!valid_address);
    end

    fall_detect_app_top #(.LPF_SHIFT(LPF_SHIFT),.ENERGY_WIDTH(ENERGY_WIDTH)) app (
        .clk(PCLK),.rst_n(PRESETn),
        .sample_valid(sample_valid&&enable),.sample_ready(app_sample_ready),
        .accel_x,.accel_y,.accel_z,.cnn_features_int8,
        .cfg_accel_threshold,.cfg_jerk_threshold,.cfg_consecutive,
        .event_valid(app_event_valid),.event_ready(app_event_ready),
        .event_logit(app_event_logit),.event_fall(app_event_fall),
        .dsp_armed,.cnn_active
    );

    always_ff@(posedge PCLK or negedge PRESETn)begin
        if(!PRESETn)begin
            enable<=0;irq_enable<=1;cfg_accel_threshold<={ENERGY_WIDTH{1'b1}};
            cfg_jerk_threshold<=40'd14325;cfg_consecutive<=3;
            event_logit_reg<='0;event_fall_reg<=0;event_pending<=0;
        end else begin
            if(apb_write)begin
                case(PADDR)
                    ADDR_CONTROL:begin enable<=PWDATA[0];irq_enable<=PWDATA[1];end
                    ADDR_ACCEL_LO:cfg_accel_threshold[31:0]<=PWDATA;
                    ADDR_ACCEL_HI:cfg_accel_threshold[39:32]<=PWDATA[7:0];
                    ADDR_JERK_LO:cfg_jerk_threshold[31:0]<=PWDATA;
                    ADDR_JERK_HI:cfg_jerk_threshold[39:32]<=PWDATA[7:0];
                    ADDR_TRIGGER_CFG:cfg_consecutive<=PWDATA[7:0];
                    ADDR_IRQ_STATUS:if(PWDATA[0])event_pending<=0;
                    default:begin end
                endcase
            end
            if(app_event_valid&&app_event_ready)begin
                event_logit_reg<=app_event_logit;event_fall_reg<=app_event_fall;event_pending<=1;
            end
        end
    end
endmodule
