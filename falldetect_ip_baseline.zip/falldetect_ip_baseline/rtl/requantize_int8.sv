`timescale 1ns/1ps

module requantize_int8 (
    input  logic                     clk,
    input  logic                     rst_n,

    input  logic                     in_valid,
    output logic                     in_ready,
    input  logic signed [31:0]       accumulator,
    input  logic signed [31:0]       multiplier_q31,
    input  logic        [5:0]        right_shift,
    input  logic signed [31:0]       output_zero_point,
    input  logic signed [31:0]       activation_min,
    input  logic signed [31:0]       activation_max,

    output logic                     out_valid,
    output logic signed [7:0]        out_data
);

    // Contract: multiplier_q31 is positive and 0 <= right_shift <= 31.
    // This covers every requantization multiplier in the frozen small model.
    // The arithmetic matches TFLite's reference MultiplyByQuantizedMultiplier
    // for real multipliers strictly between zero and one.

    function automatic logic signed [7:0] requantize_fn (
        input logic signed [31:0] acc,
        input logic signed [31:0] multiplier,
        input logic        [5:0]  rshift,
        input logic signed [31:0] zero_point,
        input logic signed [31:0] clamp_min,
        input logic signed [31:0] clamp_max
    );
        logic signed [63:0] product;
        logic signed [63:0] nudged;
        logic signed [63:0] abs_nudged;
        logic signed [63:0] high_mul;
        logic signed [63:0] scaled;
        logic signed [63:0] shifted;
        logic signed [63:0] zero_point_ext;
        logic        [63:0] mask;
        logic        [63:0] remainder;
        logic        [63:0] threshold;
        begin
            product = $signed(acc) * $signed(multiplier);

            // SaturatingRoundingDoublingHighMul. The unique INT32_MIN ×
            // INT32_MIN saturation case cannot occur because multiplier is
            // constrained to a positive Q31 value below INT32_MAX.
            if (product >= 0)
                nudged = product + 64'sd1073741824;
            else
                nudged = product - 64'sd1073741823;

            // Signed division in the C++ reference truncates toward zero;
            // arithmetic right shift alone would round negative values down.
            if (nudged >= 0) begin
                high_mul = nudged >>> 31;
            end else begin
                abs_nudged = -nudged;
                high_mul = -(abs_nudged >>> 31);
            end

            // gemmlowp RoundingDivideByPOT.
            if (rshift == 0) begin
                scaled = high_mul;
            end else begin
                mask      = (64'd1 << rshift) - 1;
                remainder = $unsigned(high_mul) & mask;
                threshold = (mask >> 1) + ((high_mul < 0) ? 64'd1 : 64'd0);
                scaled    = (high_mul >>> rshift)
                          + ((remainder > threshold) ? 64'sd1 : 64'sd0);
            end

            zero_point_ext = $signed({{32{zero_point[31]}}, zero_point});
            shifted = scaled + zero_point_ext;
            if (shifted < $signed(clamp_min))
                requantize_fn = $signed(clamp_min[7:0]);
            else if (shifted > $signed(clamp_max))
                requantize_fn = $signed(clamp_max[7:0]);
            else
                requantize_fn = $signed(shifted[7:0]);
        end
    endfunction

    assign in_ready = 1'b1;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_valid <= 1'b0;
            out_data  <= '0;
        end else begin
            out_valid <= in_valid;
            if (in_valid) begin
                out_data <= requantize_fn(
                    accumulator,
                    multiplier_q31,
                    right_shift,
                    output_zero_point,
                    activation_min,
                    activation_max
                );
            end
        end
    end

endmodule
