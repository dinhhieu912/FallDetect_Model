`timescale 1ns/1ps

module sync_rom_1r #(
    parameter int DATA_WIDTH = 32,
    parameter int DEPTH = 256,
    parameter MEM_FILE = "memory.mem"
) (
    input  logic                         clk,
    input  logic                         en,
    input  logic [$clog2(DEPTH)-1:0]     addr,
    output logic [DATA_WIDTH-1:0]         data
);

    logic [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    initial begin
        $readmemh(MEM_FILE, mem);
    end

    always_ff @(posedge clk) begin
        if (en)
            data <= mem[addr];
    end

endmodule
