`timescale 1ns/1ps

module global_avg_pool_int8 #(
    parameter integer IN_LENGTH = 12,
    parameter integer CHANNELS = 32,
    parameter integer INPUT_ZERO_POINT = -128,
    parameter integer OUTPUT_ZERO_POINT = -128,
    parameter signed [31:0] MULTIPLIER_Q31 = 32'sd1308363552,
    parameter integer RIGHT_SHIFT = 2,
    parameter integer POS_WIDTH = $clog2(IN_LENGTH),
    parameter integer CH_WIDTH = $clog2(CHANNELS)
) (
    input  logic                     clk,
    input  logic                     rst_n,
    input  logic                     input_valid,
    output logic                     input_ready,
    input  logic signed [7:0]        input_data,
    input  logic [POS_WIDTH-1:0]     input_position,
    input  logic [CH_WIDTH-1:0]      input_channel,
    output logic                     output_valid,
    input  logic                     output_ready,
    output logic signed [7:0]        output_data,
    output logic [CH_WIDTH-1:0]      output_channel,
    output logic                     done
);

    typedef enum logic [2:0] {ST_CLEAR, ST_ACCUM, ST_RQ, ST_RQ_WAIT, ST_OUTPUT} state_t;
    state_t state;
    logic signed [31:0] accumulator [0:CHANNELS-1];
    logic [CH_WIDTH-1:0] clear_channel;
    logic [CH_WIDTH-1:0] emit_channel;
    logic rq_in_valid, rq_out_valid;
    logic signed [7:0] rq_out_data;
    logic signed [7:0] output_data_reg;
    logic signed [8:0] centered_input;
    integer unused_index;

    assign centered_input = $signed(input_data) - $signed(INPUT_ZERO_POINT);

    requantize_int8 requantizer (
        .clk, .rst_n,
        .in_valid(rq_in_valid), .in_ready(),
        .accumulator(accumulator[emit_channel]),
        .multiplier_q31(MULTIPLIER_Q31),
        .right_shift(RIGHT_SHIFT[5:0]),
        .output_zero_point(OUTPUT_ZERO_POINT),
        .activation_min(-32'sd128), .activation_max(32'sd127),
        .out_valid(rq_out_valid), .out_data(rq_out_data)
    );

    always_comb begin
        input_ready = 1'b0;
        output_valid = 1'b0;
        output_data = output_data_reg;
        output_channel = emit_channel;
        rq_in_valid = 1'b0;
        case (state)
            ST_ACCUM: input_ready = 1'b1;
            ST_RQ: rq_in_valid = 1'b1;
            ST_OUTPUT: output_valid = 1'b1;
            default: begin end
        endcase
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_CLEAR;
            clear_channel <= '0;
            emit_channel <= '0;
            output_data_reg <= '0;
            done <= 1'b0;
        end else begin
            done <= 1'b0;
            case (state)
                ST_CLEAR: begin
                    accumulator[clear_channel] <= 32'sd0;
                    if (clear_channel == CHANNELS-1) begin
                        clear_channel <= '0;
                        state <= ST_ACCUM;
                    end else begin
                        clear_channel <= clear_channel + 1'b1;
                    end
                end
                ST_ACCUM: begin
                    if (input_valid && input_ready) begin
                        accumulator[input_channel] <= accumulator[input_channel]
                                                        + $signed(centered_input);
                        if ((input_position == IN_LENGTH-1)
                                && (input_channel == CHANNELS-1)) begin
                            emit_channel <= '0;
                            state <= ST_RQ;
                        end
                    end
                end
                ST_RQ: state <= ST_RQ_WAIT;
                ST_RQ_WAIT: begin
                    if (rq_out_valid) begin
                        output_data_reg <= rq_out_data;
                        state <= ST_OUTPUT;
                    end
                end
                ST_OUTPUT: begin
                    if (output_valid && output_ready) begin
                        if (emit_channel == CHANNELS-1) begin
                            done <= 1'b1;
                            clear_channel <= '0;
                            state <= ST_CLEAR;
                        end else begin
                            emit_channel <= emit_channel + 1'b1;
                            state <= ST_RQ;
                        end
                    end
                end
                default: state <= ST_CLEAR;
            endcase
        end
    end
endmodule
