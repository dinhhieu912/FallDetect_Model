`timescale 1ns/1ps

module dsp_trigger_fsm #(
    parameter integer ENERGY_WIDTH=40
) (
    input logic clk,input logic rst_n,
    input logic energy_valid,
    input logic[ENERGY_WIDTH-1:0] accel_energy,jerk_energy,
    input logic window_full,
    input logic[ENERGY_WIDTH-1:0] cfg_accel_threshold,cfg_jerk_threshold,
    input logic[7:0] cfg_consecutive,
    input logic rearm,
    output logic armed,
    output logic trigger
);
    logic[7:0] suspicious_count;
    logic suspicious;
    assign suspicious=(accel_energy>=cfg_accel_threshold)||(jerk_energy>=cfg_jerk_threshold);
    always_ff@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin armed<=1;suspicious_count<=0;trigger<=0;end
        else begin
            trigger<=0;
            if(rearm)begin armed<=1;suspicious_count<=0;end
            else if(armed&&energy_valid)begin
                if(window_full&&suspicious)begin
                    if((cfg_consecutive<=1)||(suspicious_count+1'b1>=cfg_consecutive))begin
                        trigger<=1;armed<=0;suspicious_count<=0;
                    end else suspicious_count<=suspicious_count+1'b1;
                end else suspicious_count<=0;
            end
        end
    end
endmodule
