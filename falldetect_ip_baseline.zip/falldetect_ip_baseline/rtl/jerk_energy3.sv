`timescale 1ns/1ps

module jerk_energy3 #(
    parameter integer WIDTH=16,
    parameter integer ENERGY_WIDTH=40
) (
    input logic clk,input logic rst_n,
    input logic input_valid,output logic input_ready,
    input logic signed[WIDTH-1:0] input_x,input_y,input_z,
    output logic output_valid,input logic output_ready,
    output logic[ENERGY_WIDTH-1:0] accel_energy,jerk_energy
);
    logic signed[WIDTH-1:0] prev_x,prev_y,prev_z;
    logic have_previous;
    logic signed[WIDTH:0] dx,dy,dz;
    logic signed[2*WIDTH-1:0] ax2,ay2,az2;
    logic signed[2*(WIDTH+1)-1:0] dx2,dy2,dz2;
    logic[ENERGY_WIDTH-1:0] accel_sum,jerk_sum;
    assign dx=$signed({input_x[WIDTH-1],input_x})-$signed({prev_x[WIDTH-1],prev_x});
    assign dy=$signed({input_y[WIDTH-1],input_y})-$signed({prev_y[WIDTH-1],prev_y});
    assign dz=$signed({input_z[WIDTH-1],input_z})-$signed({prev_z[WIDTH-1],prev_z});
    assign ax2=$signed(input_x)*$signed(input_x);assign ay2=$signed(input_y)*$signed(input_y);assign az2=$signed(input_z)*$signed(input_z);
    assign dx2=$signed(dx)*$signed(dx);assign dy2=$signed(dy)*$signed(dy);assign dz2=$signed(dz)*$signed(dz);
    assign accel_sum=$unsigned(ax2)+$unsigned(ay2)+$unsigned(az2);
    assign jerk_sum=have_previous?($unsigned(dx2)+$unsigned(dy2)+$unsigned(dz2)):'0;
    assign input_ready=!output_valid||output_ready;
    always_ff@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin prev_x<='0;prev_y<='0;prev_z<='0;have_previous<=0;output_valid<=0;accel_energy<='0;jerk_energy<='0;end
        else begin
            if(output_valid&&output_ready)output_valid<=0;
            if(input_valid&&input_ready)begin
                prev_x<=input_x;prev_y<=input_y;prev_z<=input_z;have_previous<=1;
                accel_energy<=accel_sum;jerk_energy<=jerk_sum;output_valid<=1;
            end
        end
    end
endmodule
