`timescale 1ns/1ps

module window_buffer_50x9 #(
    parameter integer WINDOW_LENGTH=50,
    parameter integer FEATURES=9
) (
    input logic clk,input logic rst_n,
    input logic sample_valid,output logic sample_ready,
    input logic[FEATURES*8-1:0] sample_features,
    input logic trigger,input logic resume_capture,
    output logic window_full,
    output logic output_valid,input logic output_ready,
    output logic signed[7:0] output_data,
    output logic done
);
    localparam integer SLOT_WIDTH=$clog2(WINDOW_LENGTH);
    localparam integer COUNT_WIDTH=$clog2(WINDOW_LENGTH+1);
    typedef enum logic[1:0]{ST_CAPTURE,ST_DRAIN,ST_HOLD} state_t;
    state_t state;
    logic signed[7:0] memory[0:WINDOW_LENGTH*FEATURES-1];
    logic[SLOT_WIDTH-1:0] write_slot,read_slot;
    logic[$clog2(FEATURES)-1:0] read_feature;
    logic[COUNT_WIDTH-1:0] sample_count;
    integer channel;
    assign sample_ready=(state==ST_CAPTURE);
    assign window_full=(sample_count==WINDOW_LENGTH);
    assign output_valid=(state==ST_DRAIN);
    assign output_data=memory[read_slot*FEATURES+read_feature];
    always_ff@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin state<=ST_CAPTURE;write_slot<='0;read_slot<='0;read_feature<='0;sample_count<='0;done<=0;end
        else begin
            done<=0;
            case(state)
                ST_CAPTURE:begin
                    if(sample_valid&&sample_ready)begin
                        for(channel=0;channel<FEATURES;channel++)memory[write_slot*FEATURES+channel]<=sample_features[channel*8+:8];
                        if(write_slot==WINDOW_LENGTH-1)write_slot<='0;else write_slot<=write_slot+1'b1;
                        if(sample_count<WINDOW_LENGTH)sample_count<=sample_count+1'b1;
                    end
                    if(trigger&&window_full)begin read_slot<=write_slot;read_feature<='0;state<=ST_DRAIN;end
                end
                ST_DRAIN:if(output_valid&&output_ready)begin
                    if(read_feature==FEATURES-1)begin
                        read_feature<='0;
                        if(read_slot==WINDOW_LENGTH-1)read_slot<='0;else read_slot<=read_slot+1'b1;
                        if(read_slot==((write_slot==0)?WINDOW_LENGTH-1:write_slot-1))begin done<=1;state<=ST_HOLD;end
                    end else read_feature<=read_feature+1'b1;
                end
                ST_HOLD:if(resume_capture)state<=ST_CAPTURE;
                default:state<=ST_CAPTURE;
            endcase
        end
    end
endmodule
