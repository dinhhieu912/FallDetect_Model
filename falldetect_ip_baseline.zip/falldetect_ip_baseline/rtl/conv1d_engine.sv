`timescale 1ns/1ps

module conv1d_engine #(
    parameter int IN_LENGTH = 50,
    parameter int IN_CHANNELS = 9,
    parameter int OUT_CHANNELS = 16,
    parameter int KERNEL_SIZE = 5,
    parameter int NUM_MAC = 4,
    parameter int INPUT_ZERO_POINT = -22,
    parameter int OUTPUT_ZERO_POINT = -128,
    parameter int ACTIVATION_MIN = -128,
    parameter int ACTIVATION_MAX = 127,
    parameter WEIGHT_MEM_FILE = "mem/conv1_weight_lane4.mem",
    parameter BIAS_MEM_FILE = "mem/conv1_bias.mem",
    parameter MULTIPLIER_MEM_FILE = "mem/conv1_multiplier.mem",
    parameter RSHIFT_MEM_FILE = "mem/conv1_rshift.mem"
) (
    input  logic                                     clk,
    input  logic                                     rst_n,

    input  logic                                     input_valid,
    output logic                                     input_ready,
    input  logic signed [7:0]                        input_data,

    input  logic                                     command_valid,
    output logic                                     command_ready,

    output logic                                     output_valid,
    input  logic                                     output_ready,
    output logic signed [7:0]                        output_data,
    output logic [$clog2(IN_LENGTH)-1:0]             output_position,
    output logic [$clog2(OUT_CHANNELS)-1:0]          output_channel,

    output logic                                     busy,
    output logic                                     done
);

    localparam int INPUT_COUNT = IN_LENGTH * IN_CHANNELS;
    localparam int GROUPS = OUT_CHANNELS / NUM_MAC;
    localparam int TAPS = KERNEL_SIZE * IN_CHANNELS;
    localparam int WEIGHT_DEPTH = GROUPS * TAPS;
    localparam int PAD_LEFT = KERNEL_SIZE / 2;

    localparam logic signed [8:0] INPUT_ZP_9 = INPUT_ZERO_POINT;
    localparam logic signed [31:0] OUTPUT_ZP_32 = OUTPUT_ZERO_POINT;
    localparam logic signed [31:0] ACT_MIN_32 = ACTIVATION_MIN;
    localparam logic signed [31:0] ACT_MAX_32 = ACTIVATION_MAX;

    typedef enum logic [3:0] {
        ST_LOAD,
        ST_READY,
        ST_INIT,
        ST_WEIGHT_READ,
        ST_MAC,
        ST_REQUANTIZE,
        ST_REQUANTIZE_WAIT,
        ST_OUTPUT
    } state_t;

    state_t state;

    logic signed [7:0] input_mem [0:INPUT_COUNT-1];
    logic signed [31:0] bias_mem [0:OUT_CHANNELS-1];
    logic signed [31:0] multiplier_mem [0:OUT_CHANNELS-1];
    logic        [7:0]  rshift_mem [0:OUT_CHANNELS-1];

    logic [$clog2(INPUT_COUNT+1)-1:0] load_count;
    logic [$clog2(IN_LENGTH)-1:0] position_index;
    logic [$clog2(GROUPS)-1:0] output_group;
    logic [$clog2(KERNEL_SIZE)-1:0] kernel_index;
    logic [$clog2(IN_CHANNELS)-1:0] input_channel_index;
    logic [$clog2(NUM_MAC)-1:0] output_lane;

    logic [$clog2(WEIGHT_DEPTH)-1:0] weight_addr;
    logic                             weight_en;
    logic [NUM_MAC*8-1:0]             weight_word;

    logic signed [31:0] accumulator [0:NUM_MAC-1];
    logic signed [7:0] lane_weight [0:NUM_MAC-1];
    logic signed [16:0] lane_product [0:NUM_MAC-1];
    logic signed [8:0] centered_input;

    logic [NUM_MAC-1:0] requant_in_valid;
    logic [NUM_MAC-1:0] requant_out_valid;
    logic signed [7:0] requant_data [0:NUM_MAC-1];

    integer source_position;
    integer lane;

    initial begin
        $readmemh(BIAS_MEM_FILE, bias_mem);
        $readmemh(MULTIPLIER_MEM_FILE, multiplier_mem);
        $readmemh(RSHIFT_MEM_FILE, rshift_mem);
    end

    sync_rom_1r #(
        .DATA_WIDTH (NUM_MAC * 8),
        .DEPTH      (WEIGHT_DEPTH),
        .MEM_FILE   (WEIGHT_MEM_FILE)
    ) weight_rom (
        .clk  (clk),
        .en   (weight_en),
        .addr (weight_addr),
        .data (weight_word)
    );

    generate
        for (genvar g = 0; g < NUM_MAC; g++) begin : gen_lanes
            assign lane_weight[g] = $signed(weight_word[g*8 +: 8]);
            assign lane_product[g] = $signed(centered_input) * $signed(lane_weight[g]);

            requantize_int8 requantizer (
                .clk               (clk),
                .rst_n             (rst_n),
                .in_valid          (requant_in_valid[g]),
                .in_ready          (),
                .accumulator       (accumulator[g]),
                .multiplier_q31    (multiplier_mem[output_group*NUM_MAC + g]),
                .right_shift       (rshift_mem[output_group*NUM_MAC + g][5:0]),
                .output_zero_point (OUTPUT_ZP_32),
                .activation_min    (ACT_MIN_32),
                .activation_max    (ACT_MAX_32),
                .out_valid         (requant_out_valid[g]),
                .out_data          (requant_data[g])
            );
        end
    endgenerate

    always_comb begin
        input_ready       = 1'b0;
        command_ready     = 1'b0;
        output_valid      = 1'b0;
        output_data       = '0;
        output_position   = position_index;
        output_channel    = output_group * NUM_MAC + output_lane;
        busy              = 1'b0;
        weight_en         = 1'b0;
        weight_addr       = output_group * TAPS
                          + kernel_index * IN_CHANNELS
                          + input_channel_index;
        requant_in_valid  = '0;

        case (state)
            ST_LOAD: begin
                input_ready = 1'b1;
            end
            ST_READY: begin
                command_ready = 1'b1;
            end
            ST_WEIGHT_READ: begin
                busy = 1'b1;
                weight_en = 1'b1;
            end
            ST_REQUANTIZE: begin
                busy = 1'b1;
                requant_in_valid = '1;
            end
            ST_REQUANTIZE_WAIT: begin
                busy = 1'b1;
            end
            ST_OUTPUT: begin
                busy = 1'b1;
                output_valid = 1'b1;
                output_data = requant_data[output_lane];
            end
            default: begin
                busy = 1'b1;
            end
        endcase
    end

    always_comb begin
        source_position = $signed({1'b0, position_index})
                        + $signed({1'b0, kernel_index})
                        - PAD_LEFT;
        centered_input = 9'sd0;
        if ((source_position >= 0) && (source_position < IN_LENGTH)) begin
            centered_input = $signed(
                input_mem[source_position * IN_CHANNELS + input_channel_index]
            ) - INPUT_ZP_9;
        end
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state               <= ST_LOAD;
            load_count          <= '0;
            position_index      <= '0;
            output_group        <= '0;
            kernel_index        <= '0;
            input_channel_index <= '0;
            output_lane         <= '0;
            done                <= 1'b0;
            for (lane = 0; lane < NUM_MAC; lane = lane + 1)
                accumulator[lane] <= '0;
        end else begin
            done <= 1'b0;

            case (state)
                ST_LOAD: begin
                    if (input_valid && input_ready) begin
                        input_mem[load_count] <= input_data;
                        if (load_count == INPUT_COUNT - 1) begin
                            load_count <= '0;
                            state <= ST_READY;
                        end else begin
                            load_count <= load_count + 1'b1;
                        end
                    end
                end

                ST_READY: begin
                    if (command_valid && command_ready) begin
                        position_index <= '0;
                        output_group <= '0;
                        state <= ST_INIT;
                    end
                end

                ST_INIT: begin
                    kernel_index <= '0;
                    input_channel_index <= '0;
                    output_lane <= '0;
                    for (lane = 0; lane < NUM_MAC; lane = lane + 1)
                        accumulator[lane] <= bias_mem[output_group*NUM_MAC + lane];
                    state <= ST_WEIGHT_READ;
                end

                ST_WEIGHT_READ: begin
                    state <= ST_MAC;
                end

                ST_MAC: begin
                    for (lane = 0; lane < NUM_MAC; lane = lane + 1)
                        accumulator[lane] <= accumulator[lane] + lane_product[lane];

                    if ((kernel_index == KERNEL_SIZE - 1)
                            && (input_channel_index == IN_CHANNELS - 1)) begin
                        state <= ST_REQUANTIZE;
                    end else begin
                        if (input_channel_index == IN_CHANNELS - 1) begin
                            input_channel_index <= '0;
                            kernel_index <= kernel_index + 1'b1;
                        end else begin
                            input_channel_index <= input_channel_index + 1'b1;
                        end
                        state <= ST_WEIGHT_READ;
                    end
                end

                ST_REQUANTIZE: begin
                    state <= ST_REQUANTIZE_WAIT;
                end

                ST_REQUANTIZE_WAIT: begin
                    if (requant_out_valid[0]) begin
                        output_lane <= '0;
                        state <= ST_OUTPUT;
                    end
                end

                ST_OUTPUT: begin
                    if (output_valid && output_ready) begin
                        if (output_lane < NUM_MAC - 1) begin
                            output_lane <= output_lane + 1'b1;
                        end else if (output_group < GROUPS - 1) begin
                            output_group <= output_group + 1'b1;
                            state <= ST_INIT;
                        end else if (position_index < IN_LENGTH - 1) begin
                            position_index <= position_index + 1'b1;
                            output_group <= '0;
                            state <= ST_INIT;
                        end else begin
                            done <= 1'b1;
                            load_count <= '0;
                            state <= ST_LOAD;
                        end
                    end
                end

                default: begin
                    state <= ST_LOAD;
                end
            endcase
        end
    end

endmodule
