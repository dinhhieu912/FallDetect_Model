`timescale 1ns/1ps

module maxpool1d_stream #(
    parameter integer IN_LENGTH = 50,
    parameter integer CHANNELS  = 16,
    parameter integer POS_WIDTH = $clog2(IN_LENGTH),
    parameter integer CH_WIDTH  = $clog2(CHANNELS)
) (
    input  logic                         clk,
    input  logic                         rst_n,

    input  logic                         input_valid,
    output logic                         input_ready,
    input  logic signed [7:0]            input_data,
    input  logic [POS_WIDTH-1:0]         input_position,
    input  logic [CH_WIDTH-1:0]          input_channel,

    output logic                         output_valid,
    input  logic                         output_ready,
    output logic signed [7:0]            output_data,
    output logic [POS_WIDTH-2:0]         output_position,
    output logic [CH_WIDTH-1:0]          output_channel,

    output logic                         done
);

    localparam integer OUT_LENGTH = IN_LENGTH / 2;

    logic signed [7:0] first_sample [0:CHANNELS-1];
    logic              output_valid_reg;
    logic signed [7:0] output_data_reg;
    logic [POS_WIDTH-2:0] output_position_reg;
    logic [CH_WIDTH-1:0] output_channel_reg;
    logic              output_last_reg;

    wire output_fire = output_valid_reg && output_ready;
    wire input_fire  = input_valid && input_ready;

    // One-entry elastic output register. An input may replace an output in the
    // same cycle in which the downstream consumer accepts that output.
    assign input_ready     = !output_valid_reg || output_ready;
    assign output_valid    = output_valid_reg;
    assign output_data     = output_data_reg;
    assign output_position = output_position_reg;
    assign output_channel  = output_channel_reg;

    integer index;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            output_valid_reg    <= 1'b0;
            output_data_reg     <= '0;
            output_position_reg <= '0;
            output_channel_reg  <= '0;
            output_last_reg     <= 1'b0;
            done                <= 1'b0;
            // first_sample is intentionally not reset. Every used entry is
            // overwritten by the even-position sample before it is read.
        end else begin
            done <= 1'b0;

            if (output_fire) begin
                output_valid_reg <= 1'b0;
                if (output_last_reg)
                    done <= 1'b1;
            end

            if (input_fire) begin
                if (!input_position[0]) begin
                    first_sample[input_channel] <= input_data;

                    // For odd input lengths, the final unpaired position is
                    // consumed but intentionally produces no VALID output.
                    if ((IN_LENGTH % 2) != 0
                            && (input_position == IN_LENGTH-1)
                            && (input_channel == CHANNELS-1))
                        done <= 1'b1;
                end else begin
                    output_valid_reg    <= 1'b1;
                    output_data_reg     <= ($signed(first_sample[input_channel]) > $signed(input_data))
                                             ? first_sample[input_channel]
                                             : input_data;
                    output_position_reg <= input_position[POS_WIDTH-1:1];
                    output_channel_reg  <= input_channel;
                    output_last_reg     <= ((input_position >> 1) == OUT_LENGTH-1)
                                             && (input_channel == CHANNELS-1);
                end
            end
        end
    end

endmodule
