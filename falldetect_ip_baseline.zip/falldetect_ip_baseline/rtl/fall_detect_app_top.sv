`timescale 1ns/1ps

module fall_detect_app_top #(
    parameter integer LPF_SHIFT=4,
    parameter integer ENERGY_WIDTH=40
) (
    input logic clk,input logic rst_n,
    input logic sample_valid,output logic sample_ready,
    input logic signed[15:0] accel_x,accel_y,accel_z,
    input logic[71:0] cnn_features_int8,
    input logic[ENERGY_WIDTH-1:0] cfg_accel_threshold,cfg_jerk_threshold,
    input logic[7:0] cfg_consecutive,
    output logic event_valid,input logic event_ready,
    output logic signed[7:0] event_logit,
    output logic event_fall,
    output logic dsp_armed,output logic cnn_active
);
    typedef enum logic[1:0]{ST_MONITOR,ST_LOAD_CNN,ST_RUN_CNN,ST_EVENT} ctrl_state_t;
    ctrl_state_t ctrl_state;
    logic accepted_sample,dsp_pending;
    logic lpf_in_ready,lpf_valid,lpf_ready;
    logic signed[15:0] lpf_x,lpf_y,lpf_z;
    logic energy_valid;
    logic[ENERGY_WIDTH-1:0] accel_energy,jerk_energy;
    logic trigger_pulse,trigger_rearm;
    logic buffer_sample_ready,window_full,buffer_valid,buffer_ready,buffer_done,buffer_release;
    logic signed[7:0] buffer_data;
    logic cnn_start_valid,cnn_start_ready,cnn_valid,cnn_ready,cnn_fall,cnn_done;
    logic signed[7:0] cnn_logit;

    assign sample_ready=(ctrl_state==ST_MONITOR)&&!dsp_pending&&!trigger_pulse
                        &&lpf_in_ready&&buffer_sample_ready;
    assign accepted_sample=sample_valid&&sample_ready;
    assign lpf_ready=1'b1;
    assign trigger_rearm=(ctrl_state==ST_EVENT)&&event_valid&&event_ready;
    assign buffer_release=trigger_rearm;
    assign cnn_start_valid=(ctrl_state==ST_LOAD_CNN);
    assign cnn_ready=(ctrl_state==ST_RUN_CNN)&&!event_valid;
    assign cnn_active=(ctrl_state==ST_LOAD_CNN)||(ctrl_state==ST_RUN_CNN);

    lpf_iir3 #(.WIDTH(16),.SHIFT(LPF_SHIFT)) lpf (
        .clk,.rst_n,.input_valid(accepted_sample),.input_ready(lpf_in_ready),
        .input_x(accel_x),.input_y(accel_y),.input_z(accel_z),
        .output_valid(lpf_valid),.output_ready(lpf_ready),
        .output_x(lpf_x),.output_y(lpf_y),.output_z(lpf_z)
    );
    jerk_energy3 #(.WIDTH(16),.ENERGY_WIDTH(ENERGY_WIDTH)) jerk (
        .clk,.rst_n,.input_valid(lpf_valid),.input_ready(),
        .input_x(lpf_x),.input_y(lpf_y),.input_z(lpf_z),
        .output_valid(energy_valid),.output_ready(1'b1),
        .accel_energy,.jerk_energy
    );
    dsp_trigger_fsm #(.ENERGY_WIDTH(ENERGY_WIDTH)) trigger_fsm (
        .clk,.rst_n,.energy_valid,.accel_energy,.jerk_energy,.window_full,
        .cfg_accel_threshold,.cfg_jerk_threshold,.cfg_consecutive,
        .rearm(trigger_rearm),.armed(dsp_armed),.trigger(trigger_pulse)
    );
    window_buffer_50x9 window_buffer (
        .clk,.rst_n,.sample_valid(accepted_sample),.sample_ready(buffer_sample_ready),
        .sample_features(cnn_features_int8),.trigger(trigger_pulse),.resume_capture(buffer_release),
        .window_full,.output_valid(buffer_valid),.output_ready(buffer_ready),
        .output_data(buffer_data),.done(buffer_done)
    );
    fall_cnn_int8_top cnn (
        .clk,.rst_n,.input_valid(buffer_valid),.input_ready(buffer_ready),.input_data(buffer_data),
        .start_valid(cnn_start_valid),.start_ready(cnn_start_ready),
        .output_valid(cnn_valid),.output_ready(cnn_ready),.output_logit(cnn_logit),
        .fall_detected(cnn_fall),.done(cnn_done)
    );

    always_ff@(posedge clk or negedge rst_n)begin
        if(!rst_n)begin ctrl_state<=ST_MONITOR;dsp_pending<=0;event_valid<=0;event_logit<='0;event_fall<=0;end
        else begin
            if(accepted_sample)dsp_pending<=1;
            if(energy_valid)dsp_pending<=0;
            case(ctrl_state)
                ST_MONITOR:if(trigger_pulse)ctrl_state<=ST_LOAD_CNN;
                ST_LOAD_CNN:if(cnn_start_valid&&cnn_start_ready)ctrl_state<=ST_RUN_CNN;
                ST_RUN_CNN:if(cnn_valid&&cnn_ready)begin
                    event_logit<=cnn_logit;event_fall<=cnn_fall;event_valid<=1;ctrl_state<=ST_EVENT;
                end
                ST_EVENT:if(event_valid&&event_ready)begin event_valid<=0;ctrl_state<=ST_MONITOR;end
                default:ctrl_state<=ST_MONITOR;
            endcase
        end
    end
endmodule
