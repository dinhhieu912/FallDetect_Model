# Implementation Flow

The synthesis top is `fall_detect_apb_top`. The target clock is 50 MHz (`20 ns`).

## Generic Yosys

```powershell
powershell -ExecutionPolicy Bypass -File scripts/run_yosys_generic.ps1 -YosysExe yosys
```

This produces a generic netlist, JSON and synthesis log under `implementation/yosys_generic/`.

## NanGate45

```powershell
powershell -ExecutionPolicy Bypass -File scripts/run_nangate45.ps1 `
  -YosysExe yosys `
  -Liberty D:\pdk\NanGate45\NanGate_45nm_OCL_typical.lib
```

The liberty path must point to the installed NanGate45 standard-cell library. The resulting mapped netlist and cell-area statistics are written under `implementation/nangate45/`.

## Vivado FPGA

```powershell
vivado -mode batch -source scripts/run_vivado_impl.tcl -tclargs xc7a35tcpg236-1
```

Change the part argument to the actual FPGA. Reports include post-synthesis and post-route utilization/timing plus routed power. The script intentionally does not generate a bitstream because board-specific pin and I/O-standard constraints have not been supplied.

No synthesis tool was installed on the development machine when this package was produced, so no fabricated area, timing or power figures are reported.
