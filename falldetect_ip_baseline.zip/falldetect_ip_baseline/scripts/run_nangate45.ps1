param(
    [Parameter(Mandatory=$true)][string]$Liberty,
    [string]$YosysExe = "yosys"
)
$ErrorActionPreference = "Stop"
if (!(Test-Path -LiteralPath $Liberty)) { throw "NanGate45 liberty file not found: $Liberty" }
$root = Split-Path -Parent $PSScriptRoot
$outDir = Join-Path $root "implementation\nangate45"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$libertyAbs = (Resolve-Path -LiteralPath $Liberty).Path.Replace('\','/')
Push-Location $root
try {
    $sources = (Get-Content "rtl\filelist.f") -join " "
    $commands = "read_verilog -sv $sources; hierarchy -check -top fall_detect_apb_top; proc; flatten; opt; memory; opt; dfflibmap -liberty `"$libertyAbs`"; abc -liberty `"$libertyAbs`"; clean; check; stat -liberty `"$libertyAbs`"; write_verilog -noattr -noexpr implementation/nangate45/fall_detect_apb_top_nangate45.v"
    & $YosysExe -l "implementation\nangate45\synthesis.log" -p $commands
    if ($LASTEXITCODE -ne 0) { throw "NanGate45 synthesis failed" }
}
finally { Pop-Location }
