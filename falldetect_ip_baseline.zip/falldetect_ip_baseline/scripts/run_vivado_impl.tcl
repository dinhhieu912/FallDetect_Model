set script_dir [file dirname [file normalize [info script]]]
set root [file normalize [file join $script_dir ..]]
set part_name [expr {$argc > 0 ? [lindex $argv 0] : "xc7a35tcpg236-1"}]
set out_dir [file join $root implementation vivado]
file mkdir $out_dir
cd $root

set sources {}
set fp [open [file join $root rtl filelist.f] r]
while {[gets $fp line] >= 0} {
    if {[string trim $line] ne ""} { lappend sources [file join $root [string trim $line]] }
}
close $fp
read_verilog -sv $sources
read_xdc [file join $root constraints fall_detect_50mhz.xdc]
synth_design -top fall_detect_apb_top -part $part_name -flatten_hierarchy rebuilt
write_checkpoint -force [file join $out_dir post_synth.dcp]
report_utilization -file [file join $out_dir utilization_synth.rpt]
report_timing_summary -file [file join $out_dir timing_synth.rpt]
opt_design
place_design
phys_opt_design
route_design
write_checkpoint -force [file join $out_dir post_route.dcp]
report_utilization -file [file join $out_dir utilization_route.rpt]
report_timing_summary -file [file join $out_dir timing_route.rpt]
report_power -file [file join $out_dir power_route.rpt]
