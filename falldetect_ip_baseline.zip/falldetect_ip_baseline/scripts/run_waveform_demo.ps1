param(
    [string]$IverilogRoot = "D:\Icarus\iverilog",
    [switch]$OpenGtkWave
)
$ErrorActionPreference = "Stop"
$iverilog = Join-Path $IverilogRoot "bin\iverilog.exe"
$vvp = Join-Path $IverilogRoot "bin\vvp.exe"
$gtkwave = Join-Path $IverilogRoot "gtkwave\bin\gtkwave.exe"
$root = Split-Path -Parent $PSScriptRoot
$buildDir = Join-Path $root "verification\build"
$waveDir = Join-Path $root "verification\waves"
$vvpFile = Join-Path $buildDir "sim_wave_demo.vvp"
$vcdFile = Join-Path $waveDir "fall_detect_demo.vcd"

if (!(Test-Path -LiteralPath $iverilog) -or !(Test-Path -LiteralPath $vvp)) {
    throw "Icarus executables were not found below $IverilogRoot"
}
New-Item -ItemType Directory -Force -Path $buildDir,$waveDir | Out-Null
Push-Location $root
try {
    & $iverilog -g2012 -Wall -s tb_fall_detect_app_top -o $vvpFile `
        "rtl\sync_rom_1r.sv" "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" "rtl\maxpool1d_stream.sv" `
        "rtl\global_avg_pool_int8.sv" "rtl\dense_engine.sv" `
        "rtl\fall_cnn_int8_top.sv" "rtl\lpf_iir3.sv" `
        "rtl\jerk_energy3.sv" "rtl\dsp_trigger_fsm.sv" `
        "rtl\window_buffer_50x9.sv" "rtl\fall_detect_app_top.sv" `
        "verification\tb_fall_detect_app_top.sv"
    if ($LASTEXITCODE -ne 0) { throw "Waveform demo compilation failed" }
    & $vvp $vvpFile
    if ($LASTEXITCODE -ne 0) { throw "Waveform demo simulation failed" }
}
finally { Pop-Location }

if (!(Test-Path -LiteralPath $vcdFile)) { throw "VCD was not generated: $vcdFile" }
Write-Host "Waveform generated: $vcdFile"
if ($OpenGtkWave) {
    if (!(Test-Path -LiteralPath $gtkwave)) { throw "GTKWave not found: $gtkwave" }
    Start-Process -FilePath $gtkwave -ArgumentList @($vcdFile)
}
