param(
    [string]$IverilogRoot = "D:\Icarus\iverilog"
)

$ErrorActionPreference = "Stop"

$iverilog = Join-Path $IverilogRoot "bin\iverilog.exe"
$vvp = Join-Path $IverilogRoot "bin\vvp.exe"
$projectRoot = Split-Path -Parent $PSScriptRoot
$buildDir = Join-Path $projectRoot "verification\build"
$appRtl = @(
    "rtl\sync_rom_1r.sv", "rtl\requantize_int8.sv",
    "rtl\conv1d_engine.sv", "rtl\maxpool1d_stream.sv",
    "rtl\global_avg_pool_int8.sv", "rtl\dense_engine.sv",
    "rtl\fall_cnn_int8_top.sv", "rtl\lpf_iir3.sv",
    "rtl\jerk_energy3.sv", "rtl\dsp_trigger_fsm.sv",
    "rtl\window_buffer_50x9.sv", "rtl\fall_detect_app_top.sv"
)

if (!(Test-Path -LiteralPath $iverilog) -or !(Test-Path -LiteralPath $vvp)) {
    throw "Icarus executables were not found below $IverilogRoot"
}

New-Item -ItemType Directory -Force -Path $buildDir | Out-Null
Push-Location $projectRoot
try {
    & $iverilog -g2012 -Wall -s tb_requantize_int8 `
        -o (Join-Path $buildDir "sim_requant.vvp") `
        "rtl\requantize_int8.sv" `
        "verification\tb_requantize_int8.sv"
    if ($LASTEXITCODE -ne 0) { throw "requantize_int8 compilation failed" }

    & $vvp (Join-Path $buildDir "sim_requant.vvp")
    if ($LASTEXITCODE -ne 0) { throw "requantize_int8 simulation failed" }

    & $iverilog -g2012 -Wall -s tb_conv1d_engine `
        -o (Join-Path $buildDir "sim_conv1.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" `
        "verification\tb_conv1d_engine.sv"
    if ($LASTEXITCODE -ne 0) { throw "conv1d_engine compilation failed" }

    & $vvp (Join-Path $buildDir "sim_conv1.vvp")
    if ($LASTEXITCODE -ne 0) { throw "conv1d_engine simulation failed" }

    & $iverilog -g2012 -Wall -s tb_maxpool1d_stream `
        -o (Join-Path $buildDir "sim_maxpool1.vvp") `
        "rtl\maxpool1d_stream.sv" `
        "verification\tb_maxpool1d_stream.sv"
    if ($LASTEXITCODE -ne 0) { throw "maxpool1d_stream compilation failed" }

    & $vvp (Join-Path $buildDir "sim_maxpool1.vvp")
    if ($LASTEXITCODE -ne 0) { throw "maxpool1d_stream simulation failed" }

    & $iverilog -g2012 -Wall -s tb_conv1_pool1_chain `
        -o (Join-Path $buildDir "sim_conv1_pool1.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" `
        "rtl\maxpool1d_stream.sv" `
        "verification\tb_conv1_pool1_chain.sv"
    if ($LASTEXITCODE -ne 0) { throw "Conv1-Pool1 chain compilation failed" }

    & $vvp (Join-Path $buildDir "sim_conv1_pool1.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Conv1-Pool1 chain simulation failed" }

    & $iverilog -g2012 -Wall -s tb_conv2_engine `
        -o (Join-Path $buildDir "sim_conv2.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" `
        "verification\tb_conv2_engine.sv"
    if ($LASTEXITCODE -ne 0) { throw "Conv2 engine compilation failed" }

    & $vvp (Join-Path $buildDir "sim_conv2.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Conv2 engine simulation failed" }

    & $iverilog -g2012 -Wall -s tb_conv1_pool1_conv2_chain `
        -o (Join-Path $buildDir "sim_conv1_pool1_conv2.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" `
        "rtl\maxpool1d_stream.sv" `
        "verification\tb_conv1_pool1_conv2_chain.sv"
    if ($LASTEXITCODE -ne 0) { throw "Conv1-Pool1-Conv2 compilation failed" }

    & $vvp (Join-Path $buildDir "sim_conv1_pool1_conv2.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Conv1-Pool1-Conv2 simulation failed" }

    & $iverilog -g2012 -Wall -s tb_pool2_stream `
        -o (Join-Path $buildDir "sim_pool2.vvp") `
        "rtl\maxpool1d_stream.sv" `
        "verification\tb_pool2_stream.sv"
    if ($LASTEXITCODE -ne 0) { throw "Pool2 compilation failed" }
    & $vvp (Join-Path $buildDir "sim_pool2.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Pool2 simulation failed" }

    & $iverilog -g2012 -Wall -s tb_cnn_frontend_chain `
        -o (Join-Path $buildDir "sim_cnn_frontend.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" `
        "rtl\maxpool1d_stream.sv" `
        "verification\tb_cnn_frontend_chain.sv"
    if ($LASTEXITCODE -ne 0) { throw "CNN frontend compilation failed" }
    & $vvp (Join-Path $buildDir "sim_cnn_frontend.vvp")
    if ($LASTEXITCODE -ne 0) { throw "CNN frontend simulation failed" }

    & $iverilog -g2012 -Wall -s tb_global_avg_pool_int8 `
        -o (Join-Path $buildDir "sim_gap.vvp") `
        "rtl\requantize_int8.sv" `
        "rtl\global_avg_pool_int8.sv" `
        "verification\tb_global_avg_pool_int8.sv"
    if ($LASTEXITCODE -ne 0) { throw "GAP compilation failed" }
    & $vvp (Join-Path $buildDir "sim_gap.vvp")
    if ($LASTEXITCODE -ne 0) { throw "GAP simulation failed" }

    & $iverilog -g2012 -Wall -s tb_dense_engine `
        -o (Join-Path $buildDir "sim_dense1.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\dense_engine.sv" `
        "verification\tb_dense_engine.sv"
    if ($LASTEXITCODE -ne 0) { throw "Dense1 compilation failed" }
    & $vvp (Join-Path $buildDir "sim_dense1.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Dense1 simulation failed" }

    & $iverilog -g2012 -Wall -s tb_dense2_engine `
        -o (Join-Path $buildDir "sim_dense2.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\dense_engine.sv" `
        "verification\tb_dense2_engine.sv"
    if ($LASTEXITCODE -ne 0) { throw "Dense2 compilation failed" }
    & $vvp (Join-Path $buildDir "sim_dense2.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Dense2 simulation failed" }

    & $iverilog -g2012 -Wall -s tb_fall_cnn_int8_top `
        -o (Join-Path $buildDir "sim_full_cnn.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" `
        "rtl\maxpool1d_stream.sv" `
        "rtl\global_avg_pool_int8.sv" `
        "rtl\dense_engine.sv" `
        "rtl\fall_cnn_int8_top.sv" `
        "verification\tb_fall_cnn_int8_top.sv"
    if ($LASTEXITCODE -ne 0) { throw "Full CNN compilation failed" }
    & $vvp (Join-Path $buildDir "sim_full_cnn.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Full CNN simulation failed" }

    & $iverilog -g2012 -Wall -s tb_fall_detect_app_top `
        -o (Join-Path $buildDir "sim_app_top.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" `
        "rtl\maxpool1d_stream.sv" `
        "rtl\global_avg_pool_int8.sv" `
        "rtl\dense_engine.sv" `
        "rtl\fall_cnn_int8_top.sv" `
        "rtl\lpf_iir3.sv" `
        "rtl\jerk_energy3.sv" `
        "rtl\dsp_trigger_fsm.sv" `
        "rtl\window_buffer_50x9.sv" `
        "rtl\fall_detect_app_top.sv" `
        "verification\tb_fall_detect_app_top.sv"
    if ($LASTEXITCODE -ne 0) { throw "Application top compilation failed" }
    & $vvp (Join-Path $buildDir "sim_app_top.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Application top simulation failed" }

    & $iverilog -g2012 -Wall -s tb_window_buffer_50x9 `
        -o (Join-Path $buildDir "sim_window_buffer.vvp") `
        "rtl\window_buffer_50x9.sv" `
        "verification\tb_window_buffer_50x9.sv"
    if ($LASTEXITCODE -ne 0) { throw "Window buffer compilation failed" }
    & $vvp (Join-Path $buildDir "sim_window_buffer.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Window buffer simulation failed" }

    & $iverilog -g2012 -Wall -s tb_dsp_trigger_fsm `
        -o (Join-Path $buildDir "sim_trigger_fsm.vvp") `
        "rtl\dsp_trigger_fsm.sv" `
        "verification\tb_dsp_trigger_fsm.sv"
    if ($LASTEXITCODE -ne 0) { throw "Trigger FSM compilation failed" }
    & $vvp (Join-Path $buildDir "sim_trigger_fsm.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Trigger FSM simulation failed" }

    & $iverilog -g2012 -Wall -s tb_dsp_datapath `
        -o (Join-Path $buildDir "sim_dsp_datapath.vvp") `
        "rtl\lpf_iir3.sv" `
        "rtl\jerk_energy3.sv" `
        "verification\tb_dsp_datapath.sv"
    if ($LASTEXITCODE -ne 0) { throw "DSP datapath compilation failed" }
    & $vvp (Join-Path $buildDir "sim_dsp_datapath.vvp")
    if ($LASTEXITCODE -ne 0) { throw "DSP datapath simulation failed" }

    & $iverilog -g2012 -Wall -s tb_fall_detect_apb_top `
        -o (Join-Path $buildDir "sim_apb_top.vvp") `
        "rtl\sync_rom_1r.sv" `
        "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" `
        "rtl\maxpool1d_stream.sv" `
        "rtl\global_avg_pool_int8.sv" `
        "rtl\dense_engine.sv" `
        "rtl\fall_cnn_int8_top.sv" `
        "rtl\lpf_iir3.sv" `
        "rtl\jerk_energy3.sv" `
        "rtl\dsp_trigger_fsm.sv" `
        "rtl\window_buffer_50x9.sv" `
        "rtl\fall_detect_app_top.sv" `
        "rtl\fall_detect_apb_top.sv" `
        "verification\tb_fall_detect_apb_top.sv"
    if ($LASTEXITCODE -ne 0) { throw "APB top compilation failed" }
    & $vvp (Join-Path $buildDir "sim_apb_top.vvp")
    if ($LASTEXITCODE -ne 0) { throw "APB top simulation failed" }

    & $iverilog -g2012 -Wall -s tb_no_trigger_sleep `
        -o (Join-Path $buildDir "sim_no_trigger.vvp") `
        $appRtl "verification\tb_no_trigger_sleep.sv"
    if ($LASTEXITCODE -ne 0) { throw "No-trigger compilation failed" }
    & $vvp (Join-Path $buildDir "sim_no_trigger.vvp")
    if ($LASTEXITCODE -ne 0) { throw "No-trigger simulation failed" }

    & $iverilog -g2012 -Wall -s tb_nonfall_event `
        -o (Join-Path $buildDir "sim_nonfall.vvp") `
        $appRtl "verification\tb_nonfall_event.sv"
    if ($LASTEXITCODE -ne 0) { throw "Non-fall compilation failed" }
    & $vvp (Join-Path $buildDir "sim_nonfall.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Non-fall simulation failed" }

    & $iverilog -g2012 -Wall -s tb_reset_mid_inference `
        -o (Join-Path $buildDir "sim_reset_mid.vvp") `
        $appRtl "verification\tb_reset_mid_inference.sv"
    if ($LASTEXITCODE -ne 0) { throw "Reset-mid-inference compilation failed" }
    & $vvp (Join-Path $buildDir "sim_reset_mid.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Reset-mid-inference simulation failed" }

    & $iverilog -g2012 -Wall -s tb_two_inferences `
        -o (Join-Path $buildDir "sim_two_inferences.vvp") `
        $appRtl "verification\tb_two_inferences.sv"
    if ($LASTEXITCODE -ne 0) { throw "Two-inference compilation failed" }
    & $vvp (Join-Path $buildDir "sim_two_inferences.vvp")
    if ($LASTEXITCODE -ne 0) { throw "Two-inference simulation failed" }

    & $iverilog -g2012 -Wall -s tb_kfall_batch_cnn `
        -o (Join-Path $buildDir "sim_kfall_batch.vvp") `
        "rtl\sync_rom_1r.sv" "rtl\requantize_int8.sv" `
        "rtl\conv1d_engine.sv" "rtl\maxpool1d_stream.sv" `
        "rtl\global_avg_pool_int8.sv" "rtl\dense_engine.sv" `
        "rtl\fall_cnn_int8_top.sv" "verification\tb_kfall_batch_cnn.sv"
    if ($LASTEXITCODE -ne 0) { throw "KFall batch compilation failed" }
    & $vvp (Join-Path $buildDir "sim_kfall_batch.vvp")
    if ($LASTEXITCODE -ne 0) { throw "KFall batch simulation failed" }
}
finally {
    Pop-Location
}
