param(
    [string]$IverilogRoot = "D:\Icarus\iverilog",
    [Parameter(Mandatory = $true)]
    [string]$LegacyRtlDir
)

# Icarus writes ordinary warnings to stderr. Windows PowerShell wraps those
# lines as non-terminating NativeCommandError records, so native exit codes are
# checked explicitly below instead of promoting stderr to a terminating error.
$ErrorActionPreference = "Continue"

$iverilog = Join-Path $IverilogRoot "bin\iverilog.exe"
$vvp = Join-Path $IverilogRoot "bin\vvp.exe"
$projectRoot = Split-Path -Parent $PSScriptRoot
$buildDir = Join-Path $projectRoot "verification\build\legacy"
$logDir = Join-Path $projectRoot "verification\legacy_logs"

if (!(Test-Path -LiteralPath $iverilog) -or !(Test-Path -LiteralPath $vvp)) {
    throw "Icarus executables were not found below $IverilogRoot"
}

$legacyRoot = (Resolve-Path -LiteralPath $LegacyRtlDir).Path
New-Item -ItemType Directory -Force -Path $buildDir, $logDir | Out-Null

$designSources = @(
    Get-ChildItem -LiteralPath $legacyRoot -Filter "*.v" -File |
        Where-Object { $_.Name -notlike "tb_*" } |
        ForEach-Object { $_.FullName }
)
$testbenches = @(
    Get-ChildItem -LiteralPath $legacyRoot -Filter "tb_*.v" -File |
        Sort-Object Name
)

$results = @()
Push-Location $legacyRoot
try {
    foreach ($tb in $testbenches) {
        $top = [IO.Path]::GetFileNameWithoutExtension($tb.Name)
        $simFile = Join-Path $buildDir "$top.vvp"
        $logFile = Join-Path $logDir "$top.log"
        $compileArgs = @("-g2012", "-Wall", "-s", $top, "-o", $simFile) + $designSources + @($tb.FullName)

        $compileOutput = @(& $iverilog @compileArgs 2>&1)
        $compileExit = $LASTEXITCODE
        if ($compileExit -ne 0) {
            $status = "COMPILE_FAIL"
            $compileOutput | Set-Content -LiteralPath $logFile
        } else {
            $simOutput = @(& $vvp $simFile 2>&1)
            $simExit = $LASTEXITCODE
            @($compileOutput + $simOutput) | Set-Content -LiteralPath $logFile
            $text = ($simOutput -join "`n")
            if (($simExit -ne 0) -or ($text -match "(?im)^(ERROR|FATAL):") -or ($text -match "(?i)\bFAIL\b")) {
                $status = "SIM_FAIL"
            } elseif ($text -match "(?i)\bPASS\b") {
                $status = "PASS_REPORTED"
            } else {
                $status = "SMOKE_ONLY"
            }
        }

        $results += [PSCustomObject]@{
            testbench = $top
            status = $status
            log = $logFile
        }
        Write-Output "$top|$status"
    }
}
finally {
    Pop-Location
}

$results | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $logDir "summary.json")

if ($results.status -contains "COMPILE_FAIL" -or $results.status -contains "SIM_FAIL") {
    exit 1
}
