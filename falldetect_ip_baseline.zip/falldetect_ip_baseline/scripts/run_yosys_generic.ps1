param(
    [string]$YosysExe = "yosys"
)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$outDir = Join-Path $root "implementation\yosys_generic"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
Push-Location $root
try {
    $sources = (Get-Content "rtl\filelist.f") -join " "
    $commands = "read_verilog -sv $sources; hierarchy -check -top fall_detect_apb_top; proc; flatten; opt; memory; opt; synth -top fall_detect_apb_top; check; stat; write_json implementation/yosys_generic/fall_detect_apb_top.json; write_verilog -noattr implementation/yosys_generic/fall_detect_apb_top_generic.v"
    & $YosysExe -l "implementation\yosys_generic\synthesis.log" -p $commands
    if ($LASTEXITCODE -ne 0) { throw "Generic Yosys synthesis failed" }
}
finally { Pop-Location }
