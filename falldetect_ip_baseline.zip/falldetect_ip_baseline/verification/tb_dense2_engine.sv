`timescale 1ns/1ps
module tb_dense2_engine;
    logic clk,rst_n,in_valid,in_ready,cmd_valid,cmd_ready,out_valid,out_ready,busy,done;
    logic signed[7:0] in_data,out_data;logic[0:0] out_feature;
    logic signed[7:0] in_mem[0:15],expected[0:0];integer sent,cycles,errors;
    dense_engine #(.IN_FEATURES(16),.OUT_FEATURES(1),.NUM_MAC(1),
        .INPUT_ZERO_POINT(-128),.OUTPUT_ZERO_POINT(-14),.ACTIVATION_MIN(-128),.ACTIVATION_MAX(127),
        .WEIGHT_MEM_FILE("mem/dense2_weight_lane1.mem"),.BIAS_MEM_FILE("mem/dense2_bias.mem"),
        .MULTIPLIER_MEM_FILE("mem/dense2_multiplier.mem"),.RSHIFT_MEM_FILE("mem/dense2_rshift.mem")) dut(
        .clk,.rst_n,.input_valid(in_valid),.input_ready(in_ready),.input_data(in_data),
        .command_valid(cmd_valid),.command_ready(cmd_ready),.output_valid(out_valid),.output_ready(out_ready),
        .output_data(out_data),.output_feature(out_feature),.busy,.done);
    always #5 clk=~clk;
    initial begin
        $readmemh("verification/vectors/dense1_out.mem",in_mem);$readmemh("verification/vectors/dense2_out.mem",expected);
        if($isunknown(in_mem[0])||$isunknown(in_mem[15])||$isunknown(expected[0]))$fatal(1,"Dense2 vectors missing");
        clk=0;rst_n=0;in_valid=0;in_data=0;cmd_valid=0;out_ready=0;sent=0;cycles=0;errors=0;
        repeat(3)@(posedge clk);rst_n=1;
        while (sent < 16) begin
            @(negedge clk);
            in_valid = 1;
            in_data = in_mem[sent];
            @(posedge clk);
            if (in_valid && in_ready)
                sent = sent + 1;
        end
        @(negedge clk);
        in_valid = 0;
        if (!cmd_ready)
            @(posedge cmd_ready);
        @(negedge clk);
        cmd_valid = 1;
        @(negedge clk);
        cmd_valid = 0;
        while (!done && cycles < 500) begin
            @(negedge clk);
            out_ready = ((cycles % 4) != 0);
            @(posedge clk);
            if (out_valid && out_ready) begin
                if (out_feature !== 0) begin
                    $error("Dense2 tag");
                    errors = errors + 1;
                end
                if (out_data !== expected[0]) begin
                    $error("Dense2 got %0d exp %0d", out_data, expected[0]);
                    errors = errors + 1;
                end
            end
            cycles = cycles + 1;
        end
        if(cycles>=500)$fatal(1,"Dense2 timeout");
        if(errors==0)$display("PASS: Dense2 engine matched logit byte %0d",expected[0]);else $fatal(1,"Dense2 errors %0d",errors);$finish;
    end
endmodule
