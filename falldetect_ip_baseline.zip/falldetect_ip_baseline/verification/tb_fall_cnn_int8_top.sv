`timescale 1ns/1ps
module tb_fall_cnn_int8_top;
    localparam integer INPUT_COUNT=450;
    localparam integer TIMEOUT_CYCLES=60000;
    logic clk,rst_n,input_valid,input_ready,start_valid,start_ready,output_valid,output_ready,fall_detected,done;
    logic signed[7:0] input_data,output_logit;
    logic signed[7:0] input_mem[0:INPUT_COUNT-1],expected[0:0];
    integer sent,cycles,outputs,errors;logic done_seen;
    fall_cnn_int8_top dut(.*);
    always #5 clk=~clk;
    initial begin
        $readmemh("verification/vectors/input.mem",input_mem);
        $readmemh("verification/vectors/dense2_out.mem",expected);
        if($isunknown(input_mem[0])||$isunknown(input_mem[INPUT_COUNT-1])||$isunknown(expected[0]))
            $fatal(1,"End-to-end vectors missing or incomplete");
        clk=0;rst_n=0;input_valid=0;input_data=0;start_valid=0;output_ready=0;
        sent=0;cycles=0;outputs=0;errors=0;done_seen=0;
        repeat(3)@(posedge clk);rst_n=1;
        while(sent<INPUT_COUNT)begin
            @(negedge clk);input_valid=1;input_data=input_mem[sent];
            @(posedge clk);if(input_valid&&input_ready)sent++;
        end
        @(negedge clk);input_valid=0;
        if(!start_ready)@(posedge start_ready);
        @(negedge clk);start_valid=1;
        @(negedge clk);start_valid=0;
        while((outputs<1||!done_seen)&&cycles<TIMEOUT_CYCLES)begin
            @(negedge clk);output_ready=((cycles%7)!=0);@(posedge clk);
            if(output_valid&&output_ready)begin
                if(output_logit!==expected[0])begin
                    $error("End-to-end logit got %0d expected %0d",output_logit,expected[0]);errors++;
                end
                if(!fall_detected)begin
                    $error("Expected fall_detected=1 because logit %0d > zero-point -14",output_logit);errors++;
                end
                outputs++;
            end
            if(done)done_seen=1;
            cycles++;
        end
        if(cycles>=TIMEOUT_CYCLES)$fatal(1,"End-to-end timeout outputs=%0d done=%0d",outputs,done_seen);
        if(outputs!=1)$fatal(1,"Expected exactly one logit, got %0d",outputs);
        if(errors==0)$display("PASS: full INT8 CNN matched logit byte %0d and fall decision in %0d cycles",expected[0],cycles);
        else $fatal(1,"FAIL: end-to-end CNN had %0d errors",errors);
        $finish;
    end
endmodule
