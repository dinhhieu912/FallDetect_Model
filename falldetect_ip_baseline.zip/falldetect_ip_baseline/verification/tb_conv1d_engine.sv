`timescale 1ns/1ps

module tb_conv1d_engine;

    localparam int INPUT_COUNT = 50 * 9;
    localparam int OUTPUT_COUNT = 50 * 16;
    localparam int TIMEOUT_CYCLES = 50000;

    logic clk;
    logic rst_n;
    logic input_valid;
    logic input_ready;
    logic signed [7:0] input_data;
    logic command_valid;
    logic command_ready;
    logic output_valid;
    logic output_ready;
    logic signed [7:0] output_data;
    logic [5:0] output_position;
    logic [3:0] output_channel;
    logic busy;
    logic done;

    logic signed [7:0] input_mem [0:INPUT_COUNT-1];
    logic signed [7:0] expected_mem [0:OUTPUT_COUNT-1];

    int index;
    int received;
    int cycles;
    int errors;

    conv1d_engine #(
        .WEIGHT_MEM_FILE     ("mem/conv1_weight_lane4.mem"),
        .BIAS_MEM_FILE       ("mem/conv1_bias.mem"),
        .MULTIPLIER_MEM_FILE ("mem/conv1_multiplier.mem"),
        .RSHIFT_MEM_FILE     ("mem/conv1_rshift.mem")
    ) dut (
        .clk             (clk),
        .rst_n           (rst_n),
        .input_valid     (input_valid),
        .input_ready     (input_ready),
        .input_data      (input_data),
        .command_valid   (command_valid),
        .command_ready   (command_ready),
        .output_valid    (output_valid),
        .output_ready    (output_ready),
        .output_data     (output_data),
        .output_position (output_position),
        .output_channel  (output_channel),
        .busy            (busy),
        .done            (done)
    );

    always #5 clk = ~clk;

    initial begin
        $readmemh("verification/vectors/input.mem", input_mem);
        $readmemh("verification/vectors/conv1_out.mem", expected_mem);

        if ($isunknown(input_mem[0]) || $isunknown(input_mem[INPUT_COUNT-1])
                || $isunknown(expected_mem[0])
                || $isunknown(expected_mem[OUTPUT_COUNT-1])) begin
            $fatal(1, "Conv1 input/golden vector files are missing or incomplete");
        end

        clk           = 1'b0;
        rst_n         = 1'b0;
        input_valid   = 1'b0;
        input_data    = '0;
        command_valid = 1'b0;
        output_ready  = 1'b0;
        received      = 0;
        cycles        = 0;
        errors        = 0;

        repeat (3) @(posedge clk);
        rst_n = 1'b1;

        // Load one complete [50,9] tensor in time-major/channel-minor order.
        for (index = 0; index < INPUT_COUNT; index++) begin
            @(negedge clk);
            if (!input_ready) begin
                $fatal(1, "input_ready dropped while loading sample %0d", index);
            end
            input_valid = 1'b1;
            input_data = input_mem[index];
        end
        @(negedge clk);
        input_valid = 1'b0;

        if (!command_ready)
            @(posedge command_ready);
        @(negedge clk);
        command_valid = 1'b1;
        @(negedge clk);
        command_valid = 1'b0;

        // Exercise output backpressure while checking all tensor bytes and
        // their explicit position/channel tags.
        while ((received < OUTPUT_COUNT) && (cycles < TIMEOUT_CYCLES)) begin
            @(negedge clk);
            output_ready = ((cycles % 7) != 0);
            @(posedge clk);
            // Sample the accepted item in the active region. Sampling after
            // the NBA region would observe the next lane/tag, causing a
            // one-output scoreboard shift.
            if (output_valid && output_ready) begin
                if (output_position !== received / 16) begin
                    $error(
                        "Position mismatch at output %0d: got %0d expected %0d",
                        received, output_position, received / 16
                    );
                    errors++;
                end
                if (output_channel !== received % 16) begin
                    $error(
                        "Channel mismatch at output %0d: got %0d expected %0d",
                        received, output_channel, received % 16
                    );
                    errors++;
                end
                if (output_data !== expected_mem[received]) begin
                    $error(
                        "Data mismatch at output %0d (t=%0d, c=%0d): got %0d expected %0d",
                        received,
                        received / 16,
                        received % 16,
                        output_data,
                        expected_mem[received]
                    );
                    errors++;
                end
                received++;
            end
            cycles++;
        end

        #1;

        if (cycles >= TIMEOUT_CYCLES)
            $fatal(1, "Timeout after %0d cycles; received %0d/%0d outputs", cycles, received, OUTPUT_COUNT);

        if (!done)
            $error("done was not asserted with the final accepted output");

        if (errors == 0)
            $display(
                "PASS: conv1d_engine matched all %0d bytes in %0d monitored cycles",
                OUTPUT_COUNT, cycles
            );
        else
            $fatal(1, "FAIL: conv1d_engine had %0d errors", errors);

        $finish;
    end

endmodule
