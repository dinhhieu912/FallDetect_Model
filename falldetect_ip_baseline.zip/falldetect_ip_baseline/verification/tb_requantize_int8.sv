`timescale 1ns/1ps

module tb_requantize_int8;

    localparam int NUM_VECTORS = 256;

    logic clk;
    logic rst_n;
    logic in_valid;
    logic in_ready;
    logic signed [31:0] accumulator;
    logic signed [31:0] multiplier_q31;
    logic [5:0] right_shift;
    logic signed [31:0] output_zero_point;
    logic signed [31:0] activation_min;
    logic signed [31:0] activation_max;
    logic out_valid;
    logic signed [7:0] out_data;

    logic signed [31:0] acc_mem      [0:NUM_VECTORS-1];
    logic signed [31:0] mult_mem     [0:NUM_VECTORS-1];
    logic        [7:0]  rshift_mem   [0:NUM_VECTORS-1];
    logic signed [31:0] output_zp_mem[0:NUM_VECTORS-1];
    logic signed [31:0] act_min_mem  [0:NUM_VECTORS-1];
    logic signed [31:0] act_max_mem  [0:NUM_VECTORS-1];
    logic signed [7:0]  expected_mem [0:NUM_VECTORS-1];

    int index;
    int errors;

    requantize_int8 dut (
        .clk               (clk),
        .rst_n             (rst_n),
        .in_valid          (in_valid),
        .in_ready          (in_ready),
        .accumulator       (accumulator),
        .multiplier_q31    (multiplier_q31),
        .right_shift       (right_shift),
        .output_zero_point (output_zero_point),
        .activation_min    (activation_min),
        .activation_max    (activation_max),
        .out_valid         (out_valid),
        .out_data          (out_data)
    );

    always #5 clk = ~clk;

    initial begin
        $readmemh("verification/vectors/requant_acc.mem",            acc_mem);
        $readmemh("verification/vectors/requant_multiplier.mem",     mult_mem);
        $readmemh("verification/vectors/requant_rshift.mem",          rshift_mem);
        $readmemh("verification/vectors/requant_output_zp.mem",       output_zp_mem);
        $readmemh("verification/vectors/requant_activation_min.mem",  act_min_mem);
        $readmemh("verification/vectors/requant_activation_max.mem",  act_max_mem);
        $readmemh("verification/vectors/requant_expected.mem",        expected_mem);

        if ($isunknown(acc_mem[0]) || $isunknown(acc_mem[NUM_VECTORS-1])
                || $isunknown(mult_mem[0]) || $isunknown(rshift_mem[0])
                || $isunknown(output_zp_mem[0]) || $isunknown(act_min_mem[0])
                || $isunknown(act_max_mem[0]) || $isunknown(expected_mem[0])) begin
            $fatal(1, "Requantization vector files are missing or incomplete");
        end

        clk               = 1'b0;
        rst_n             = 1'b0;
        in_valid          = 1'b0;
        accumulator       = '0;
        multiplier_q31    = '0;
        right_shift       = '0;
        output_zero_point = '0;
        activation_min    = -32'sd128;
        activation_max    =  32'sd127;
        errors            = 0;

        repeat (3) @(posedge clk);
        rst_n = 1'b1;

        for (index = 0; index < NUM_VECTORS; index++) begin
            @(negedge clk);
            in_valid          = 1'b1;
            accumulator       = acc_mem[index];
            multiplier_q31    = mult_mem[index];
            right_shift       = rshift_mem[index][5:0];
            output_zero_point = output_zp_mem[index];
            activation_min    = act_min_mem[index];
            activation_max    = act_max_mem[index];

            @(posedge clk);
            #1;
            if (!out_valid) begin
                $error("Missing out_valid for vector %0d", index);
                errors++;
            end else if (out_data !== expected_mem[index]) begin
                $error(
                    "Vector %0d failed: acc=%0d mult=%0d rshift=%0d got=%0d expected=%0d",
                    index,
                    accumulator,
                    multiplier_q31,
                    right_shift,
                    out_data,
                    expected_mem[index]
                );
                errors++;
            end
        end

        @(negedge clk);
        in_valid = 1'b0;
        @(posedge clk);
        #1;
        if (out_valid) begin
            $error("out_valid did not clear after in_valid deassertion");
            errors++;
        end

        if (errors == 0)
            $display("PASS: requantize_int8 matched all %0d vectors", NUM_VECTORS);
        else
            $fatal(1, "FAIL: requantize_int8 had %0d errors", errors);

        $finish;
    end

endmodule
