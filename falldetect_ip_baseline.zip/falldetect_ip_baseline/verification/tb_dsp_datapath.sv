`timescale 1ns/1ps
module tb_dsp_datapath;
    logic clk,rst_n,input_valid,input_ready,lpf_valid,lpf_ready,energy_valid;
    logic signed[15:0] input_x,input_y,input_z,lpf_x,lpf_y,lpf_z;
    logic[39:0] accel_energy,jerk_energy;
    integer received,errors;
    lpf_iir3 #(.WIDTH(16),.SHIFT(0)) lpf(.clk,.rst_n,.input_valid,.input_ready,
        .input_x,.input_y,.input_z,.output_valid(lpf_valid),.output_ready(lpf_ready),
        .output_x(lpf_x),.output_y(lpf_y),.output_z(lpf_z));
    jerk_energy3 jerk(.clk,.rst_n,.input_valid(lpf_valid),.input_ready(lpf_ready),
        .input_x(lpf_x),.input_y(lpf_y),.input_z(lpf_z),.output_valid(energy_valid),
        .output_ready(1'b1),.accel_energy,.jerk_energy);
    always #5 clk=~clk;
    always@(posedge clk)if(energy_valid)begin
        case(received)
            0:if(accel_energy!==0||jerk_energy!==0)begin $error("DSP vector0 a=%0d j=%0d",accel_energy,jerk_energy);errors++;end
            1:if(accel_energy!==25||jerk_energy!==25)begin $error("DSP vector1 a=%0d j=%0d",accel_energy,jerk_energy);errors++;end
            2:if(accel_energy!==100||jerk_energy!==25)begin $error("DSP vector2 a=%0d j=%0d",accel_energy,jerk_energy);errors++;end
        endcase
        received++;
    end
    task send_sample(input signed[15:0] x,input signed[15:0] y,input signed[15:0] z);
        begin while(!input_ready)@(posedge clk);@(negedge clk);input_x=x;input_y=y;input_z=z;input_valid=1;
              @(negedge clk);input_valid=0;end
    endtask
    initial begin
        clk=0;rst_n=0;input_valid=0;input_x=0;input_y=0;input_z=0;received=0;errors=0;
        repeat(3)@(posedge clk);rst_n=1;
        send_sample(0,0,0);send_sample(3,4,0);send_sample(6,8,0);
        while(received<3)@(posedge clk);
        if(errors==0)$display("PASS: LPF and jerk energy matched 3 directed vectors");
        else $fatal(1,"DSP datapath had %0d errors",errors);
        $finish;
    end
endmodule
