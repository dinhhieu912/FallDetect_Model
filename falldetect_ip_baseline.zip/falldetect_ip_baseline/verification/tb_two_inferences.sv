`timescale 1ns/1ps
module tb_two_inferences;
    logic clk,rst_n,sample_valid,sample_ready,event_valid,event_ready,event_fall,dsp_armed,cnn_active;
    logic signed[15:0] accel_x,accel_y,accel_z;logic[71:0] cnn_features_int8;
    logic[39:0] cfg_accel_threshold,cfg_jerk_threshold;logic[7:0] cfg_consecutive;
    logic signed[7:0] event_logit;logic signed[7:0] input_mem[0:449],expected[0:0];
    integer channel,errors;
    fall_detect_app_top #(.LPF_SHIFT(0)) dut(.*);
    always #5 clk=~clk;
    task send_window(input signed[15:0] base_accel,input signed[15:0] last_accel);
        integer sample_index;
        begin
            for(sample_index=0;sample_index<50;sample_index++)begin
                while(!sample_ready)@(posedge clk);@(negedge clk);
                for(channel=0;channel<9;channel++)cnn_features_int8[channel*8+:8]=input_mem[sample_index*9+channel];
                accel_x=(sample_index==49)?last_accel:base_accel;
                accel_y=(sample_index==49)?last_accel:base_accel;
                accel_z=(sample_index==49)?last_accel:base_accel;
                sample_valid=1;@(negedge clk);sample_valid=0;
            end
        end
    endtask
    task check_and_accept_event;
        integer wait_cycles;
        begin
            wait_cycles=0;while(!event_valid&&wait_cycles<70000)begin @(posedge clk);wait_cycles++;end
            if(wait_cycles>=70000)$fatal(1,"Two-inference event timeout");
            if(event_logit!==expected[0]||!event_fall)begin $error("Repeated inference result incorrect");errors++;end
            @(negedge clk);event_ready=1;@(negedge clk);event_ready=0;
            while(!sample_ready)@(posedge clk);
        end
    endtask
    initial begin
        $readmemh("verification/vectors/input.mem",input_mem);$readmemh("verification/vectors/dense2_out.mem",expected);
        clk=0;rst_n=0;sample_valid=0;accel_x=0;accel_y=0;accel_z=0;cnn_features_int8=0;
        cfg_accel_threshold={40{1'b1}};cfg_jerk_threshold=40'd1000000;cfg_consecutive=1;
        event_ready=0;errors=0;repeat(3)@(posedge clk);rst_n=1;
        send_window(0,1000);check_and_accept_event();
        // Preserve 1000 for 49 samples, then step back to zero to create only the final trigger.
        send_window(1000,0);check_and_accept_event();
        if(errors==0)$display("PASS: two consecutive DSP-gated CNN inferences completed with correct events");
        else $fatal(1,"Two-inference test had %0d errors",errors);
        $finish;
    end
endmodule
