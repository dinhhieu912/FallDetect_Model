# Verification Matrix

| Requirement | Evidence | Status |
|---|---|---|
| TFLite-compatible requantization | 256 directed/random vectors | PASS |
| Conv1 complete tensor | 800-byte golden comparison | PASS |
| Pool1 complete tensor | 400-byte golden comparison | PASS |
| Conv2 complete tensor | 800-byte golden comparison | PASS |
| Pool2 odd-length VALID behavior | 384 outputs and all 800 inputs consumed | PASS |
| GAP quantized mean | 32-byte golden comparison | PASS |
| Dense1 and Dense2 | 16-byte and one-logit comparisons | PASS |
| Full CNN fall decision | independent tensor, logit 11 > -14 | PASS |
| DSP trigger to event | acceleration step, buffer drain, CNN and event | PASS |
| CNN remains asleep without trigger | quiet 50-sample window | PASS |
| Triggered non-fall decision | independent golden scenario, logit -35 | PASS |
| Circular window ordering | 55 writes, latest 50 samples checked | PASS |
| Trigger consecutive/rearm policy | directed FSM test | PASS |
| Reset during inference | abort plus successful fresh inference | PASS |
| Repeated operation | two trigger/inference/event sequences | PASS |
| APB configuration and IRQ | register transactions and W1C | PASS |
| Real KFall batch | 33 SA12 ADL/fall windows, complete RTL logits | PASS, 33/33 golden matches |

KFall trigger calibration covers all 5,075 trials. The 33-window SA12 batch uses label-aligned fall-impact windows and representative ADL windows. A formal subject-independent CNN test split remains a model-evaluation artifact rather than an RTL equivalence requirement.
