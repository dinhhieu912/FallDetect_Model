`timescale 1ns/1ps
module tb_kfall_batch_cnn;
    localparam integer WINDOWS=33;
    localparam integer INPUTS_PER_WINDOW=450;
    localparam integer TOTAL_INPUTS=WINDOWS*INPUTS_PER_WINDOW;
    logic clk,rst_n,input_valid,input_ready,start_valid,start_ready,output_valid,output_ready,fall_detected,done;
    logic signed[7:0] input_data,output_logit;
    logic signed[7:0] input_mem[0:TOTAL_INPUTS-1],expected_mem[0:WINDOWS-1];
    logic[0:0] label_mem[0:WINDOWS-1];
    integer window_index,input_index,cycles,errors,label_matches;
    logic expected_fall;
    fall_cnn_int8_top dut(.*);
    always #5 clk=~clk;
    initial begin
        $readmemh("verification/vectors/kfall_batch_input.mem",input_mem);
        $readmemh("verification/vectors/kfall_batch_expected.mem",expected_mem);
        $readmemh("verification/vectors/kfall_batch_label.mem",label_mem);
        if($isunknown(input_mem[0])||$isunknown(input_mem[TOTAL_INPUTS-1])
           ||$isunknown(expected_mem[0])||$isunknown(expected_mem[WINDOWS-1]))
            $fatal(1,"KFall batch vectors missing or incomplete");
        clk=0;rst_n=0;input_valid=0;input_data=0;start_valid=0;output_ready=1;
        cycles=0;errors=0;label_matches=0;repeat(3)@(posedge clk);rst_n=1;
        for(window_index=0;window_index<WINDOWS;window_index++)begin
            for(input_index=0;input_index<INPUTS_PER_WINDOW;input_index++)begin
                @(negedge clk);
                if(!input_ready)$fatal(1,"CNN not ready loading window %0d byte %0d",window_index,input_index);
                input_valid=1;input_data=input_mem[window_index*INPUTS_PER_WINDOW+input_index];
            end
            @(negedge clk);input_valid=0;
            if(!start_ready)@(posedge start_ready);
            @(negedge clk);start_valid=1;@(negedge clk);start_valid=0;
            do begin @(posedge clk);cycles++;if(cycles>2000000)$fatal(1,"KFall batch timeout");end while(!output_valid);
            expected_fall=($signed(expected_mem[window_index])>-8'sd14);
            if(output_logit!==expected_mem[window_index])begin
                $error("KFall window %0d logit got %0d expected %0d",window_index,output_logit,expected_mem[window_index]);errors++;
            end
            if(fall_detected!==expected_fall)begin
                $error("KFall window %0d decision mismatch",window_index);errors++;
            end
            if(expected_fall==label_mem[window_index])label_matches++;
        end
        if(label_matches!=31)begin $error("Expected 31/33 golden label matches, got %0d",label_matches);errors++;end
        if(errors==0)$display("PASS: RTL matched all %0d real KFall golden logits; selected-window model accuracy %0d/%0d",WINDOWS,label_matches,WINDOWS);
        else $fatal(1,"KFall batch RTL test had %0d errors",errors);
        $finish;
    end
endmodule
