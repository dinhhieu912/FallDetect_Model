`timescale 1ns/1ps

module tb_global_avg_pool_int8;
    localparam integer INPUT_COUNT=12*32;
    localparam integer OUTPUT_COUNT=32;
    localparam integer TIMEOUT_CYCLES=2000;
    logic clk,rst_n,input_valid,input_ready,output_valid,output_ready,done;
    logic signed [7:0] input_data,output_data;
    logic [3:0] input_position;
    logic [4:0] input_channel,output_channel;
    logic signed [7:0] source_mem[0:INPUT_COUNT-1];
    logic signed [7:0] expected_mem[0:OUTPUT_COUNT-1];
    integer sent,received,cycles,errors;
    logic done_seen;

    global_avg_pool_int8 dut(.*);
    always #5 clk=~clk;
    initial begin
        $readmemh("verification/vectors/pool2_out.mem",source_mem);
        $readmemh("verification/vectors/gap_out.mem",expected_mem);
        if($isunknown(source_mem[0])||$isunknown(source_mem[INPUT_COUNT-1])
           ||$isunknown(expected_mem[0])||$isunknown(expected_mem[OUTPUT_COUNT-1]))
            $fatal(1,"GAP vectors missing or incomplete");
        clk=0;rst_n=0;input_valid=0;input_data=0;input_position=0;input_channel=0;
        output_ready=0;sent=0;received=0;cycles=0;errors=0;done_seen=0;
        repeat(3)@(posedge clk);rst_n=1;
        while(((sent<INPUT_COUNT)||(received<OUTPUT_COUNT)||!done_seen)&&cycles<TIMEOUT_CYCLES)begin
            @(negedge clk);
            input_valid=(sent<INPUT_COUNT)&&((cycles%7)!=2);
            output_ready=((cycles%5)!=0);
            if(sent<INPUT_COUNT)begin
                input_data=source_mem[sent];input_position=sent/32;input_channel=sent%32;
            end
            @(posedge clk);
            if(input_valid&&input_ready)sent++;
            if(output_valid&&output_ready)begin
                if(output_channel!==received)begin $error("GAP channel mismatch %0d",received);errors++;end
                if(output_data!==expected_mem[received])begin
                    $error("GAP data mismatch %0d: got %0d expected %0d",received,output_data,expected_mem[received]);errors++;
                end
                received++;
            end
            if(done)done_seen=1;
            cycles++;
        end
        if(cycles>=TIMEOUT_CYCLES)$fatal(1,"GAP timeout sent=%0d recv=%0d done=%0d",sent,received,done_seen);
        if(errors==0)$display("PASS: global_avg_pool_int8 matched all %0d bytes",OUTPUT_COUNT);
        else $fatal(1,"FAIL: GAP had %0d errors",errors);
        $finish;
    end
endmodule
