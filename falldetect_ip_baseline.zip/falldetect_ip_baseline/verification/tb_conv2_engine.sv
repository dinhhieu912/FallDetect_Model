`timescale 1ns/1ps

module tb_conv2_engine;
    localparam integer IN_LENGTH = 25;
    localparam integer IN_CHANNELS = 16;
    localparam integer OUT_CHANNELS = 32;
    localparam integer INPUT_COUNT = IN_LENGTH * IN_CHANNELS;
    localparam integer OUTPUT_COUNT = IN_LENGTH * OUT_CHANNELS;
    localparam integer TIMEOUT_CYCLES = 30000;

    logic clk;
    logic rst_n;
    logic input_valid;
    logic input_ready;
    logic signed [7:0] input_data;
    logic command_valid;
    logic command_ready;
    logic output_valid;
    logic output_ready;
    logic signed [7:0] output_data;
    logic [4:0] output_position;
    logic [4:0] output_channel;
    logic busy;
    logic done;

    logic signed [7:0] input_mem [0:INPUT_COUNT-1];
    logic signed [7:0] expected_mem [0:OUTPUT_COUNT-1];
    integer index;
    integer received;
    integer cycles;
    integer errors;
    logic done_seen;

    conv1d_engine #(
        .IN_LENGTH          (IN_LENGTH),
        .IN_CHANNELS        (IN_CHANNELS),
        .OUT_CHANNELS       (OUT_CHANNELS),
        .KERNEL_SIZE        (3),
        .NUM_MAC            (4),
        .INPUT_ZERO_POINT   (-128),
        .OUTPUT_ZERO_POINT  (-128),
        .ACTIVATION_MIN     (-128),
        .ACTIVATION_MAX     (127),
        .WEIGHT_MEM_FILE    ("mem/conv2_weight_lane4.mem"),
        .BIAS_MEM_FILE      ("mem/conv2_bias.mem"),
        .MULTIPLIER_MEM_FILE("mem/conv2_multiplier.mem"),
        .RSHIFT_MEM_FILE    ("mem/conv2_rshift.mem")
    ) dut (
        .clk, .rst_n,
        .input_valid, .input_ready, .input_data,
        .command_valid, .command_ready,
        .output_valid, .output_ready, .output_data,
        .output_position, .output_channel,
        .busy, .done
    );

    always #5 clk = ~clk;

    initial begin
        $readmemh("verification/vectors/pool1_out.mem", input_mem);
        $readmemh("verification/vectors/conv2_out.mem", expected_mem);
        if ($isunknown(input_mem[0]) || $isunknown(input_mem[INPUT_COUNT-1])
                || $isunknown(expected_mem[0]) || $isunknown(expected_mem[OUTPUT_COUNT-1]))
            $fatal(1, "Conv2 source/golden vector files are missing or incomplete");

        clk = 1'b0;
        rst_n = 1'b0;
        input_valid = 1'b0;
        input_data = '0;
        command_valid = 1'b0;
        output_ready = 1'b0;
        received = 0;
        cycles = 0;
        errors = 0;
        done_seen = 1'b0;

        repeat (3) @(posedge clk);
        rst_n = 1'b1;

        for (index = 0; index < INPUT_COUNT; index++) begin
            @(negedge clk);
            if (!input_ready)
                $fatal(1, "Conv2 input_ready dropped while loading byte %0d", index);
            input_valid = 1'b1;
            input_data = input_mem[index];
        end
        @(negedge clk);
        input_valid = 1'b0;

        if (!command_ready)
            @(posedge command_ready);
        @(negedge clk);
        command_valid = 1'b1;
        @(negedge clk);
        command_valid = 1'b0;

        while ((received < OUTPUT_COUNT) && (cycles < TIMEOUT_CYCLES)) begin
            @(negedge clk);
            output_ready = ((cycles % 7) != 0) && ((cycles % 17) != 0);
            @(posedge clk);
            if (output_valid && output_ready) begin
                if (output_position !== received / OUT_CHANNELS) begin
                    $error("Conv2 position mismatch %0d: got %0d expected %0d",
                           received, output_position, received / OUT_CHANNELS);
                    errors++;
                end
                if (output_channel !== received % OUT_CHANNELS) begin
                    $error("Conv2 channel mismatch %0d: got %0d expected %0d",
                           received, output_channel, received % OUT_CHANNELS);
                    errors++;
                end
                if (output_data !== expected_mem[received]) begin
                    $error("Conv2 data mismatch %0d: got %0d expected %0d",
                           received, output_data, expected_mem[received]);
                    errors++;
                end
                received++;
            end
            if (done)
                done_seen = 1'b1;
            cycles++;
        end

        @(posedge clk);
        if (done)
            done_seen = 1'b1;
        if (cycles >= TIMEOUT_CYCLES)
            $fatal(1, "Conv2 timeout: received %0d/%0d", received, OUTPUT_COUNT);
        if (!done_seen)
            $fatal(1, "Conv2 done pulse was not observed");
        if (errors == 0)
            $display("PASS: Conv2 engine matched all %0d bytes in %0d monitored cycles",
                     OUTPUT_COUNT, cycles);
        else
            $fatal(1, "FAIL: Conv2 engine had %0d errors", errors);
        $finish;
    end
endmodule
