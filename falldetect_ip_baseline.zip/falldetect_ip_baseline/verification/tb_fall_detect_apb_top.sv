`timescale 1ns/1ps
module tb_fall_detect_apb_top;
    logic PCLK,PRESETn,PSEL,PENABLE,PWRITE,PREADY,PSLVERR,sample_valid,sample_ready,irq;
    logic[7:0] PADDR;logic[31:0] PWDATA,PRDATA;
    logic signed[15:0] accel_x,accel_y,accel_z;logic[71:0] cnn_features_int8;
    logic signed[7:0] input_mem[0:449],expected[0:0];
    logic[31:0] read_value;integer sample_index,channel,cycles,errors;
    fall_detect_apb_top #(.LPF_SHIFT(0)) dut(.*);
    always #5 PCLK=~PCLK;
    task apb_write(input[7:0] address,input[31:0] data);
        begin @(negedge PCLK);PSEL=1;PENABLE=0;PWRITE=1;PADDR=address;PWDATA=data;
              @(negedge PCLK);PENABLE=1;@(negedge PCLK);
              if(!PREADY||PSLVERR)$fatal(1,"APB write failure at %0h",address);
              PSEL=0;PENABLE=0;PWRITE=0;PADDR=0;PWDATA=0;end
    endtask
    task apb_read(input[7:0] address,output[31:0] data);
        begin @(negedge PCLK);PSEL=1;PENABLE=0;PWRITE=0;PADDR=address;
              @(negedge PCLK);PENABLE=1;@(posedge PCLK);data=PRDATA;
              @(negedge PCLK);if(!PREADY||PSLVERR)$fatal(1,"APB read failure at %0h",address);
              PSEL=0;PENABLE=0;PADDR=0;end
    endtask
    initial begin
        $readmemh("verification/vectors/input.mem",input_mem);$readmemh("verification/vectors/dense2_out.mem",expected);
        if($isunknown(input_mem[0])||$isunknown(input_mem[449])||$isunknown(expected[0]))$fatal(1,"APB test vectors missing");
        PCLK=0;PRESETn=0;PSEL=0;PENABLE=0;PWRITE=0;PADDR=0;PWDATA=0;
        sample_valid=0;accel_x=0;accel_y=0;accel_z=0;cnn_features_int8=0;cycles=0;errors=0;
        repeat(3)@(posedge PCLK);PRESETn=1;
        apb_read(8'h00,read_value);if(read_value!==32'h46414C4C)$fatal(1,"Bad IP ID");
        apb_read(8'h14,read_value);if(read_value!==32'd14325)$fatal(1,"Bad calibrated jerk reset default");
        apb_read(8'h1C,read_value);if(read_value[7:0]!==8'd3)$fatal(1,"Bad calibrated consecutive reset default");
        apb_write(8'h0C,32'hFFFFFFFF);apb_write(8'h10,32'h000000FF);
        apb_write(8'h14,32'd1000000);apb_write(8'h18,32'd0);
        apb_write(8'h1C,32'd1);apb_write(8'h04,32'h3);
        for(sample_index=0;sample_index<50;sample_index++)begin
            while(!sample_ready)@(posedge PCLK);@(negedge PCLK);
            for(channel=0;channel<9;channel++)cnn_features_int8[channel*8+:8]=input_mem[sample_index*9+channel];
            if(sample_index==49)begin accel_x=1000;accel_y=1000;accel_z=1000;end
            else begin accel_x=0;accel_y=0;accel_z=0;end
            sample_valid=1;@(negedge PCLK);sample_valid=0;
        end
        while(!irq&&cycles<70000)begin @(posedge PCLK);cycles++;end
        if(cycles>=70000)$fatal(1,"APB wrapper timeout waiting for IRQ");
        apb_read(8'h08,read_value);if(!read_value[2])begin $error("STATUS event_pending missing");errors++;end
        apb_read(8'h20,read_value);
        if($signed(read_value[7:0])!==expected[0])begin $error("APB logit got %0d expected %0d",$signed(read_value[7:0]),expected[0]);errors++;end
        if(!read_value[8])begin $error("APB fall bit missing");errors++;end
        apb_write(8'h24,32'h1);repeat(2)@(posedge PCLK);
        if(irq)begin $error("IRQ did not clear after W1C");errors++;end
        apb_read(8'h24,read_value);if(read_value[0])begin $error("IRQ status did not clear");errors++;end
        if(errors==0)$display("PASS: APB configuration -> DSP/CNN -> sticky IRQ, logit %0d, W1C clear",expected[0]);
        else $fatal(1,"APB integration had %0d errors",errors);
        $finish;
    end
endmodule
