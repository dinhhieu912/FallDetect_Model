`timescale 1ns/1ps

module tb_cnn_frontend_chain;
    localparam integer INPUT_COUNT = 50 * 9;
    localparam integer OUTPUT_COUNT = 12 * 32;
    localparam integer TIMEOUT_CYCLES = 60000;

    logic clk, rst_n;
    logic source_valid, source_ready;
    logic signed [7:0] source_data;
    logic c1_cmd_valid, c1_cmd_ready;
    logic c1_valid, c1_ready;
    logic signed [7:0] c1_data;
    logic [5:0] c1_pos; logic [3:0] c1_ch;
    logic p1_valid, p1_ready;
    logic signed [7:0] p1_data;
    logic [4:0] p1_pos; logic [3:0] p1_ch;
    logic c2_cmd_valid, c2_cmd_ready;
    logic c2_valid, c2_ready;
    logic signed [7:0] c2_data;
    logic [4:0] c2_pos; logic [4:0] c2_ch;
    logic p2_valid, p2_ready;
    logic signed [7:0] p2_data;
    logic [3:0] p2_pos; logic [4:0] p2_ch;
    logic p2_done;
    logic signed [7:0] input_mem [0:INPUT_COUNT-1];
    logic signed [7:0] expected_mem [0:OUTPUT_COUNT-1];
    integer index, received, cycles, errors;
    logic p2_done_seen;

    conv1d_engine conv1 (
        .clk, .rst_n, .input_valid(source_valid), .input_ready(source_ready),
        .input_data(source_data), .command_valid(c1_cmd_valid), .command_ready(c1_cmd_ready),
        .output_valid(c1_valid), .output_ready(c1_ready), .output_data(c1_data),
        .output_position(c1_pos), .output_channel(c1_ch), .busy(), .done()
    );
    maxpool1d_stream #(.IN_LENGTH(50), .CHANNELS(16)) pool1 (
        .clk, .rst_n, .input_valid(c1_valid), .input_ready(c1_ready), .input_data(c1_data),
        .input_position(c1_pos), .input_channel(c1_ch),
        .output_valid(p1_valid), .output_ready(p1_ready), .output_data(p1_data),
        .output_position(p1_pos), .output_channel(p1_ch), .done()
    );
    conv1d_engine #(
        .IN_LENGTH(25), .IN_CHANNELS(16), .OUT_CHANNELS(32), .KERNEL_SIZE(3), .NUM_MAC(4),
        .INPUT_ZERO_POINT(-128), .OUTPUT_ZERO_POINT(-128),
        .WEIGHT_MEM_FILE("mem/conv2_weight_lane4.mem"),
        .BIAS_MEM_FILE("mem/conv2_bias.mem"),
        .MULTIPLIER_MEM_FILE("mem/conv2_multiplier.mem"),
        .RSHIFT_MEM_FILE("mem/conv2_rshift.mem")
    ) conv2 (
        .clk, .rst_n, .input_valid(p1_valid), .input_ready(p1_ready), .input_data(p1_data),
        .command_valid(c2_cmd_valid), .command_ready(c2_cmd_ready),
        .output_valid(c2_valid), .output_ready(c2_ready), .output_data(c2_data),
        .output_position(c2_pos), .output_channel(c2_ch), .busy(), .done()
    );
    maxpool1d_stream #(.IN_LENGTH(25), .CHANNELS(32)) pool2 (
        .clk, .rst_n, .input_valid(c2_valid), .input_ready(c2_ready), .input_data(c2_data),
        .input_position(c2_pos), .input_channel(c2_ch),
        .output_valid(p2_valid), .output_ready(p2_ready), .output_data(p2_data),
        .output_position(p2_pos), .output_channel(p2_ch), .done(p2_done)
    );

    always #5 clk = ~clk;

    initial begin
        $readmemh("verification/vectors/input.mem", input_mem);
        $readmemh("verification/vectors/pool2_out.mem", expected_mem);
        if ($isunknown(input_mem[0]) || $isunknown(input_mem[INPUT_COUNT-1])
                || $isunknown(expected_mem[0]) || $isunknown(expected_mem[OUTPUT_COUNT-1]))
            $fatal(1, "CNN frontend source/golden vectors missing or incomplete");
        clk=0; rst_n=0; source_valid=0; source_data=0;
        c1_cmd_valid=0; c2_cmd_valid=0; p2_ready=0;
        received=0; cycles=0; errors=0; p2_done_seen=0;
        repeat (3) @(posedge clk); rst_n=1;
        for (index=0; index<INPUT_COUNT; index++) begin
            @(negedge clk);
            if (!source_ready) $fatal(1, "Conv1 load stalled unexpectedly at %0d", index);
            source_valid=1; source_data=input_mem[index];
        end
        @(negedge clk); source_valid=0;
        if (!c1_cmd_ready) @(posedge c1_cmd_ready);
        @(negedge clk); c1_cmd_valid=1;
        @(negedge clk); c1_cmd_valid=0;
        if (!c2_cmd_ready) @(posedge c2_cmd_ready);
        @(negedge clk); c2_cmd_valid=1;
        @(negedge clk); c2_cmd_valid=0;

        while (((received < OUTPUT_COUNT) || !p2_done_seen) && cycles<TIMEOUT_CYCLES) begin
            @(negedge clk); p2_ready=((cycles%11)!=0)&&((cycles%23)!=0);
            @(posedge clk);
            if (p2_valid && p2_ready) begin
                if (p2_pos !== received/32) begin $error("Frontend pos mismatch %0d", received); errors++; end
                if (p2_ch !== received%32) begin $error("Frontend ch mismatch %0d", received); errors++; end
                if (p2_data !== expected_mem[received]) begin
                    $error("Frontend data mismatch %0d: got %0d expected %0d",
                           received, p2_data, expected_mem[received]); errors++;
                end
                received++;
            end
            if (p2_done) p2_done_seen=1;
            cycles++;
        end
        if (cycles>=TIMEOUT_CYCLES)
            $fatal(1, "CNN frontend timeout: received %0d/%0d done=%0d", received,OUTPUT_COUNT,p2_done_seen);
        if (errors==0)
            $display("PASS: Conv1-Pool1-Conv2-Pool2 matched all %0d bytes in %0d monitored cycles",
                     OUTPUT_COUNT, cycles);
        else $fatal(1, "FAIL: CNN frontend had %0d errors", errors);
        $finish;
    end
endmodule
