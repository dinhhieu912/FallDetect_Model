`timescale 1ns/1ps

module tb_maxpool1d_stream;
    localparam integer IN_LENGTH   = 50;
    localparam integer CHANNELS    = 16;
    localparam integer INPUT_COUNT = IN_LENGTH * CHANNELS;
    localparam integer OUTPUT_COUNT = (IN_LENGTH / 2) * CHANNELS;
    localparam integer TIMEOUT_CYCLES = 5000;

    logic clk;
    logic rst_n;
    logic input_valid;
    logic input_ready;
    logic signed [7:0] input_data;
    logic [5:0] input_position;
    logic [3:0] input_channel;
    logic output_valid;
    logic output_ready;
    logic signed [7:0] output_data;
    logic [4:0] output_position;
    logic [3:0] output_channel;
    logic done;

    logic signed [7:0] source_mem [0:INPUT_COUNT-1];
    logic signed [7:0] expected_mem [0:OUTPUT_COUNT-1];
    integer sent;
    integer received;
    integer cycles;
    integer errors;
    logic done_seen;

    maxpool1d_stream #(
        .IN_LENGTH (IN_LENGTH),
        .CHANNELS  (CHANNELS)
    ) dut (
        .clk, .rst_n,
        .input_valid, .input_ready, .input_data,
        .input_position, .input_channel,
        .output_valid, .output_ready, .output_data,
        .output_position, .output_channel,
        .done
    );

    always #5 clk = ~clk;

    initial begin
        $readmemh("verification/vectors/conv1_out.mem", source_mem);
        $readmemh("verification/vectors/pool1_out.mem", expected_mem);
        if ($isunknown(source_mem[0]) || $isunknown(source_mem[INPUT_COUNT-1])
                || $isunknown(expected_mem[0]) || $isunknown(expected_mem[OUTPUT_COUNT-1]))
            $fatal(1, "MaxPool source/golden vector files are missing or incomplete");

        clk = 1'b0;
        rst_n = 1'b0;
        input_valid = 1'b0;
        input_data = '0;
        input_position = '0;
        input_channel = '0;
        output_ready = 1'b0;
        sent = 0;
        received = 0;
        cycles = 0;
        errors = 0;
        done_seen = 1'b0;

        repeat (3) @(posedge clk);
        rst_n = 1'b1;

        while ((received < OUTPUT_COUNT) && (cycles < TIMEOUT_CYCLES)) begin
            @(negedge clk);
            output_ready = ((cycles % 5) != 0);
            input_valid = (sent < INPUT_COUNT) && ((cycles % 7) != 3);
            if (sent < INPUT_COUNT) begin
                input_data = source_mem[sent];
                input_position = sent / CHANNELS;
                input_channel = sent % CHANNELS;
            end

            @(posedge clk);
            if (input_valid && input_ready)
                sent++;

            if (output_valid && output_ready) begin
                if (output_position !== received / CHANNELS) begin
                    $error("Pool position mismatch %0d: got %0d expected %0d",
                           received, output_position, received / CHANNELS);
                    errors++;
                end
                if (output_channel !== received % CHANNELS) begin
                    $error("Pool channel mismatch %0d: got %0d expected %0d",
                           received, output_channel, received % CHANNELS);
                    errors++;
                end
                if (output_data !== expected_mem[received]) begin
                    $error("Pool data mismatch %0d: got %0d expected %0d",
                           received, output_data, expected_mem[received]);
                    errors++;
                end
                received++;
            end
            if (done)
                done_seen = 1'b1;
            cycles++;
        end

        // done is registered on final output acceptance.
        @(posedge clk);
        if (done)
            done_seen = 1'b1;

        if (cycles >= TIMEOUT_CYCLES)
            $fatal(1, "MaxPool timeout: sent %0d/%0d received %0d/%0d",
                   sent, INPUT_COUNT, received, OUTPUT_COUNT);
        if (sent != INPUT_COUNT)
            $fatal(1, "MaxPool did not consume the complete input tensor");
        if (!done_seen)
            $fatal(1, "MaxPool done pulse was not observed");
        if (errors == 0)
            $display("PASS: maxpool1d_stream matched all %0d Pool1 bytes in %0d cycles",
                     OUTPUT_COUNT, cycles);
        else
            $fatal(1, "FAIL: maxpool1d_stream had %0d errors", errors);
        $finish;
    end
endmodule
