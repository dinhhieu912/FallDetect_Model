`timescale 1ns/1ps
module tb_dense_engine;
    logic clk,rst_n,in_valid,in_ready,cmd_valid,cmd_ready,out_valid,out_ready,busy,done_wire;
    logic signed[7:0] in_data,out_data;
    logic[3:0] out_feature;
    logic signed[7:0] in_mem[0:31],expected[0:15];
    integer sent,received,cycles,errors;logic done_seen;
    dense_engine dut(.clk,.rst_n,.input_valid(in_valid),.input_ready(in_ready),.input_data(in_data),
        .command_valid(cmd_valid),.command_ready(cmd_ready),.output_valid(out_valid),.output_ready(out_ready),
        .output_data(out_data),.output_feature(out_feature),.busy,.done(done_wire));
    always #5 clk=~clk;
    initial begin
        $readmemh("verification/vectors/gap_out.mem",in_mem);$readmemh("verification/vectors/dense1_out.mem",expected);
        if($isunknown(in_mem[0])||$isunknown(in_mem[31])||$isunknown(expected[0])||$isunknown(expected[15]))$fatal(1,"Dense1 vectors missing");
        clk=0;rst_n=0;in_valid=0;in_data=0;cmd_valid=0;out_ready=0;sent=0;received=0;cycles=0;errors=0;done_seen=0;
        repeat(3)@(posedge clk);rst_n=1;
        while (sent < 32) begin
            @(negedge clk);
            in_valid = 1;
            in_data = in_mem[sent];
            @(posedge clk);
            if (in_valid && in_ready)
                sent = sent + 1;
        end
        @(negedge clk);
        in_valid = 0;
        if (!cmd_ready)
            @(posedge cmd_ready);
        @(negedge clk);
        cmd_valid = 1;
        @(negedge clk);
        cmd_valid = 0;
        while ((received < 16 || !done_seen) && cycles < 2000) begin
            @(negedge clk);
            out_ready = ((cycles % 5) != 0);
            @(posedge clk);
            if (out_valid && out_ready) begin
                if (out_feature !== received) begin
                    $error("Dense1 tag %0d", received);
                    errors = errors + 1;
                end
                if (out_data !== expected[received]) begin
                    $error("Dense1 data %0d got %0d exp %0d", received, out_data, expected[received]);
                    errors = errors + 1;
                end
                received = received + 1;
            end
            if(done_wire) begin
                done_seen = 1'b1;
            end
            cycles = cycles + 1;
        end
        if(cycles>=2000)$fatal(1,"Dense1 timeout");
        if(errors==0)$display("PASS: Dense1 engine matched all 16 bytes");else $fatal(1,"Dense1 errors %0d",errors);$finish;
    end
endmodule
