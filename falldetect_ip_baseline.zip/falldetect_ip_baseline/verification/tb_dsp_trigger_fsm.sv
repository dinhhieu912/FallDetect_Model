`timescale 1ns/1ps
module tb_dsp_trigger_fsm;
    logic clk,rst_n,energy_valid,window_full,rearm,armed,trigger;
    logic[39:0] accel_energy,jerk_energy,cfg_accel_threshold,cfg_jerk_threshold;
    logic[7:0] cfg_consecutive;integer triggers,errors;
    dsp_trigger_fsm dut(.*);
    always #5 clk=~clk;
    always@(posedge clk)if(trigger)triggers++;
    task send_energy(input[39:0] a,input[39:0] j);
        begin @(negedge clk);accel_energy=a;jerk_energy=j;energy_valid=1;
              @(negedge clk);energy_valid=0; end
    endtask
    initial begin
        clk=0;rst_n=0;energy_valid=0;window_full=0;rearm=0;accel_energy=0;jerk_energy=0;
        cfg_accel_threshold=100;cfg_jerk_threshold=200;cfg_consecutive=2;triggers=0;errors=0;
        repeat(3)@(posedge clk);rst_n=1;
        send_energy(1000,1000); // ignored until a complete CNN window exists
        window_full=1;
        send_energy(0,250);     // suspicious 1/2
        if(triggers!=0)begin $error("Trigger asserted before consecutive count");errors++;end
        send_energy(150,0);     // suspicious 2/2
        repeat(2)@(posedge clk);
        if(triggers!=1)begin $error("Expected one trigger, got %0d",triggers);errors++;end
        if(armed)begin $error("FSM did not disarm");errors++;end
        send_energy(1000,1000); // ignored while disarmed
        if(triggers!=1)begin $error("Disarmed FSM retriggered");errors++;end
        @(negedge clk);rearm=1;@(negedge clk);rearm=0;@(posedge clk);
        if(!armed)begin $error("FSM did not rearm");errors++;end
        if(errors==0)$display("PASS: trigger FSM window gate, consecutive count, disarm and rearm");
        else $fatal(1,"Trigger FSM had %0d errors",errors);
        $finish;
    end
endmodule
