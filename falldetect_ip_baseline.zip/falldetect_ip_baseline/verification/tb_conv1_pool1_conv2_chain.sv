`timescale 1ns/1ps

module tb_conv1_pool1_conv2_chain;
    localparam integer INPUT_COUNT = 50 * 9;
    localparam integer OUTPUT_COUNT = 25 * 32;
    localparam integer TIMEOUT_CYCLES = 50000;

    logic clk;
    logic rst_n;
    logic source_valid;
    logic source_ready;
    logic signed [7:0] source_data;
    logic conv1_command_valid;
    logic conv1_command_ready;
    logic conv1_valid;
    logic conv1_ready;
    logic signed [7:0] conv1_data;
    logic [5:0] conv1_position;
    logic [3:0] conv1_channel;
    logic pool1_valid;
    logic pool1_ready;
    logic signed [7:0] pool1_data;
    logic [4:0] pool1_position;
    logic [3:0] pool1_channel;
    logic pool1_done;
    logic conv2_command_valid;
    logic conv2_command_ready;
    logic conv2_valid;
    logic conv2_ready;
    logic signed [7:0] conv2_data;
    logic [4:0] conv2_position;
    logic [4:0] conv2_channel;
    logic conv2_done;

    logic signed [7:0] input_mem [0:INPUT_COUNT-1];
    logic signed [7:0] expected_mem [0:OUTPUT_COUNT-1];
    integer index;
    integer received;
    integer cycles;
    integer errors;
    logic conv2_done_seen;

    conv1d_engine conv1 (
        .clk, .rst_n,
        .input_valid(source_valid), .input_ready(source_ready), .input_data(source_data),
        .command_valid(conv1_command_valid), .command_ready(conv1_command_ready),
        .output_valid(conv1_valid), .output_ready(conv1_ready), .output_data(conv1_data),
        .output_position(conv1_position), .output_channel(conv1_channel),
        .busy(), .done()
    );

    maxpool1d_stream #(.IN_LENGTH(50), .CHANNELS(16)) pool1 (
        .clk, .rst_n,
        .input_valid(conv1_valid), .input_ready(conv1_ready), .input_data(conv1_data),
        .input_position(conv1_position), .input_channel(conv1_channel),
        .output_valid(pool1_valid), .output_ready(pool1_ready), .output_data(pool1_data),
        .output_position(pool1_position), .output_channel(pool1_channel),
        .done(pool1_done)
    );

    conv1d_engine #(
        .IN_LENGTH(25), .IN_CHANNELS(16), .OUT_CHANNELS(32),
        .KERNEL_SIZE(3), .NUM_MAC(4),
        .INPUT_ZERO_POINT(-128), .OUTPUT_ZERO_POINT(-128),
        .ACTIVATION_MIN(-128), .ACTIVATION_MAX(127),
        .WEIGHT_MEM_FILE("mem/conv2_weight_lane4.mem"),
        .BIAS_MEM_FILE("mem/conv2_bias.mem"),
        .MULTIPLIER_MEM_FILE("mem/conv2_multiplier.mem"),
        .RSHIFT_MEM_FILE("mem/conv2_rshift.mem")
    ) conv2 (
        .clk, .rst_n,
        .input_valid(pool1_valid), .input_ready(pool1_ready), .input_data(pool1_data),
        .command_valid(conv2_command_valid), .command_ready(conv2_command_ready),
        .output_valid(conv2_valid), .output_ready(conv2_ready), .output_data(conv2_data),
        .output_position(conv2_position), .output_channel(conv2_channel),
        .busy(), .done(conv2_done)
    );

    always #5 clk = ~clk;

    initial begin
        $readmemh("verification/vectors/input.mem", input_mem);
        $readmemh("verification/vectors/conv2_out.mem", expected_mem);
        if ($isunknown(input_mem[0]) || $isunknown(input_mem[INPUT_COUNT-1])
                || $isunknown(expected_mem[0]) || $isunknown(expected_mem[OUTPUT_COUNT-1]))
            $fatal(1, "Three-stage source/golden vector files are missing or incomplete");

        clk = 1'b0;
        rst_n = 1'b0;
        source_valid = 1'b0;
        source_data = '0;
        conv1_command_valid = 1'b0;
        conv2_command_valid = 1'b0;
        conv2_ready = 1'b0;
        received = 0;
        cycles = 0;
        errors = 0;
        conv2_done_seen = 1'b0;

        repeat (3) @(posedge clk);
        rst_n = 1'b1;

        for (index = 0; index < INPUT_COUNT; index++) begin
            @(negedge clk);
            if (!source_ready)
                $fatal(1, "Conv1 source_ready dropped while loading byte %0d", index);
            source_valid = 1'b1;
            source_data = input_mem[index];
        end
        @(negedge clk);
        source_valid = 1'b0;

        if (!conv1_command_ready)
            @(posedge conv1_command_ready);
        @(negedge clk);
        conv1_command_valid = 1'b1;
        @(negedge clk);
        conv1_command_valid = 1'b0;

        // Pool1 streams directly into Conv2's activation memory.
        if (!conv2_command_ready)
            @(posedge conv2_command_ready);
        @(negedge clk);
        conv2_command_valid = 1'b1;
        @(negedge clk);
        conv2_command_valid = 1'b0;

        while ((received < OUTPUT_COUNT) && (cycles < TIMEOUT_CYCLES)) begin
            @(negedge clk);
            conv2_ready = ((cycles % 11) != 0) && ((cycles % 19) != 0);
            @(posedge clk);
            if (conv2_valid && conv2_ready) begin
                if (conv2_position !== received / 32) begin
                    $error("Three-stage position mismatch %0d: got %0d expected %0d",
                           received, conv2_position, received / 32);
                    errors++;
                end
                if (conv2_channel !== received % 32) begin
                    $error("Three-stage channel mismatch %0d: got %0d expected %0d",
                           received, conv2_channel, received % 32);
                    errors++;
                end
                if (conv2_data !== expected_mem[received]) begin
                    $error("Three-stage data mismatch %0d: got %0d expected %0d",
                           received, conv2_data, expected_mem[received]);
                    errors++;
                end
                received++;
            end
            if (conv2_done)
                conv2_done_seen = 1'b1;
            cycles++;
        end

        @(posedge clk);
        if (conv2_done)
            conv2_done_seen = 1'b1;
        if (cycles >= TIMEOUT_CYCLES)
            $fatal(1, "Three-stage timeout: received %0d/%0d", received, OUTPUT_COUNT);
        if (!conv2_done_seen)
            $fatal(1, "Three-stage Conv2 done pulse was not observed");
        if (errors == 0)
            $display("PASS: Conv1-Pool1-Conv2 matched all %0d Conv2 bytes in %0d cycles",
                     OUTPUT_COUNT, cycles);
        else
            $fatal(1, "FAIL: three-stage chain had %0d errors", errors);
        $finish;
    end
endmodule
