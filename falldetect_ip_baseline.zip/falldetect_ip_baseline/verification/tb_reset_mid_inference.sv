`timescale 1ns/1ps
module tb_reset_mid_inference;
    logic clk,rst_n,sample_valid,sample_ready,event_valid,event_ready,event_fall,dsp_armed,cnn_active;
    logic signed[15:0] accel_x,accel_y,accel_z;logic[71:0] cnn_features_int8;
    logic[39:0] cfg_accel_threshold,cfg_jerk_threshold;logic[7:0] cfg_consecutive;
    logic signed[7:0] event_logit;logic signed[7:0] input_mem[0:449],expected[0:0];
    integer channel,cycles,errors;
    fall_detect_app_top #(.LPF_SHIFT(0)) dut(.*);
    always #5 clk=~clk;
    task send_window;
        integer sample_index;
        begin
            for(sample_index=0;sample_index<50;sample_index++)begin
                while(!sample_ready)@(posedge clk);@(negedge clk);
                for(channel=0;channel<9;channel++)cnn_features_int8[channel*8+:8]=input_mem[sample_index*9+channel];
                if(sample_index==49)begin accel_x=1000;accel_y=1000;accel_z=1000;end
                else begin accel_x=0;accel_y=0;accel_z=0;end
                sample_valid=1;@(negedge clk);sample_valid=0;
            end
        end
    endtask
    initial begin
        $readmemh("verification/vectors/input.mem",input_mem);$readmemh("verification/vectors/dense2_out.mem",expected);
        clk=0;rst_n=0;sample_valid=0;accel_x=0;accel_y=0;accel_z=0;cnn_features_int8=0;
        cfg_accel_threshold={40{1'b1}};cfg_jerk_threshold=40'd1000000;cfg_consecutive=1;
        event_ready=0;cycles=0;errors=0;repeat(3)@(posedge clk);rst_n=1;
        send_window();
        while(dut.ctrl_state!=2'd2)@(posedge clk);
        repeat(100)@(posedge clk);
        @(negedge clk);rst_n=0;repeat(3)@(posedge clk);@(negedge clk);rst_n=1;
        repeat(3)@(posedge clk);
        if(event_valid)begin $error("Stale event survived reset");errors++;end
        if(!dsp_armed||!sample_ready)begin $error("IP did not return to armed monitor state after reset");errors++;end
        send_window();
        while(!event_valid&&cycles<70000)begin @(posedge clk);cycles++;end
        if(cycles>=70000)$fatal(1,"Post-reset inference timeout");
        if(event_logit!==expected[0]||!event_fall)begin $error("Post-reset inference result incorrect");errors++;end
        if(errors==0)$display("PASS: reset aborted active inference and a fresh inference completed correctly");
        else $fatal(1,"Reset-mid-inference test had %0d errors",errors);
        $finish;
    end
endmodule
