`timescale 1ns/1ps
module tb_window_buffer_50x9;
    logic clk,rst_n,sample_valid,sample_ready,trigger,resume_capture,window_full,output_valid,output_ready,done;
    logic[71:0] sample_features;logic signed[7:0] output_data;
    integer sample_index,channel,received,errors,expected_sample,expected_channel,cycles;
    logic done_seen;
    window_buffer_50x9 dut(.*);
    always #5 clk=~clk;
    initial begin
        clk=0;rst_n=0;sample_valid=0;sample_features=0;trigger=0;resume_capture=0;output_ready=0;
        received=0;errors=0;cycles=0;done_seen=0;repeat(3)@(posedge clk);rst_n=1;
        // 55 samples force the write pointer to wrap. The retained window must be 5..54.
        for(sample_index=0;sample_index<55;sample_index++)begin
            @(negedge clk);
            for(channel=0;channel<9;channel++)sample_features[channel*8+:8]=(sample_index*9+channel)&8'hff;
            sample_valid=1;
            @(posedge clk);if(!sample_ready)$fatal(1,"Buffer refused capture sample %0d",sample_index);
        end
        @(negedge clk);sample_valid=0;trigger=1;
        @(negedge clk);trigger=0;
        while((received<450||!done_seen)&&cycles<2000)begin
            output_ready=((cycles%7)!=3);
            @(posedge clk);
            if(output_valid&&output_ready)begin
                expected_sample=5+(received/9);expected_channel=received%9;
                if(output_data!==((expected_sample*9+expected_channel)&8'hff))begin
                    $error("Buffer byte %0d got %0h expected %0h",received,output_data,
                           ((expected_sample*9+expected_channel)&8'hff));errors++;
                end
                received++;
            end
            if(done)done_seen=1;
            cycles++;
            @(negedge clk);
        end
        if(cycles>=2000)$fatal(1,"Buffer timeout received=%0d done=%0d",received,done_seen);
        if(sample_ready)$fatal(1,"Buffer must remain frozen until resume_capture");
        @(negedge clk);resume_capture=1;@(negedge clk);resume_capture=0;@(posedge clk);
        if(!sample_ready)$fatal(1,"Buffer did not resume capture");
        if(errors==0)$display("PASS: circular window retained latest 50 samples across pointer wrap");
        else $fatal(1,"Window buffer had %0d errors",errors);
        $finish;
    end
endmodule
