`timescale 1ns/1ps

module tb_conv1_pool1_chain;
    localparam integer INPUT_COUNT = 50 * 9;
    localparam integer OUTPUT_COUNT = 25 * 16;
    localparam integer TIMEOUT_CYCLES = 30000;

    logic clk;
    logic rst_n;
    logic source_valid;
    logic source_ready;
    logic signed [7:0] source_data;
    logic command_valid;
    logic command_ready;
    logic conv_valid;
    logic conv_ready;
    logic signed [7:0] conv_data;
    logic [5:0] conv_position;
    logic [3:0] conv_channel;
    logic conv_done;
    logic pool_valid;
    logic pool_ready;
    logic signed [7:0] pool_data;
    logic [4:0] pool_position;
    logic [3:0] pool_channel;
    logic pool_done;

    logic signed [7:0] input_mem [0:INPUT_COUNT-1];
    logic signed [7:0] expected_mem [0:OUTPUT_COUNT-1];
    integer index;
    integer received;
    integer cycles;
    integer errors;
    logic pool_done_seen;

    conv1d_engine conv1 (
        .clk, .rst_n,
        .input_valid(source_valid), .input_ready(source_ready), .input_data(source_data),
        .command_valid, .command_ready,
        .output_valid(conv_valid), .output_ready(conv_ready), .output_data(conv_data),
        .output_position(conv_position), .output_channel(conv_channel),
        .busy(), .done(conv_done)
    );

    maxpool1d_stream #(
        .IN_LENGTH (50),
        .CHANNELS  (16)
    ) pool1 (
        .clk, .rst_n,
        .input_valid(conv_valid), .input_ready(conv_ready), .input_data(conv_data),
        .input_position(conv_position), .input_channel(conv_channel),
        .output_valid(pool_valid), .output_ready(pool_ready), .output_data(pool_data),
        .output_position(pool_position), .output_channel(pool_channel),
        .done(pool_done)
    );

    always #5 clk = ~clk;

    initial begin
        $readmemh("verification/vectors/input.mem", input_mem);
        $readmemh("verification/vectors/pool1_out.mem", expected_mem);
        if ($isunknown(input_mem[0]) || $isunknown(input_mem[INPUT_COUNT-1])
                || $isunknown(expected_mem[0]) || $isunknown(expected_mem[OUTPUT_COUNT-1]))
            $fatal(1, "Conv1-Pool1 source/golden vector files are missing or incomplete");

        clk = 1'b0;
        rst_n = 1'b0;
        source_valid = 1'b0;
        source_data = '0;
        command_valid = 1'b0;
        pool_ready = 1'b0;
        received = 0;
        cycles = 0;
        errors = 0;
        pool_done_seen = 1'b0;

        repeat (3) @(posedge clk);
        rst_n = 1'b1;

        for (index = 0; index < INPUT_COUNT; index++) begin
            @(negedge clk);
            if (!source_ready)
                $fatal(1, "Conv1 source_ready dropped while loading byte %0d", index);
            source_valid = 1'b1;
            source_data = input_mem[index];
        end
        @(negedge clk);
        source_valid = 1'b0;

        if (!command_ready)
            @(posedge command_ready);
        @(negedge clk);
        command_valid = 1'b1;
        @(negedge clk);
        command_valid = 1'b0;

        while ((received < OUTPUT_COUNT) && (cycles < TIMEOUT_CYCLES)) begin
            @(negedge clk);
            pool_ready = ((cycles % 11) != 0) && ((cycles % 13) != 0);
            @(posedge clk);
            if (pool_valid && pool_ready) begin
                if (pool_position !== received / 16) begin
                    $error("Chain position mismatch %0d: got %0d expected %0d",
                           received, pool_position, received / 16);
                    errors++;
                end
                if (pool_channel !== received % 16) begin
                    $error("Chain channel mismatch %0d: got %0d expected %0d",
                           received, pool_channel, received % 16);
                    errors++;
                end
                if (pool_data !== expected_mem[received]) begin
                    $error("Chain data mismatch %0d: got %0d expected %0d",
                           received, pool_data, expected_mem[received]);
                    errors++;
                end
                received++;
            end
            if (pool_done)
                pool_done_seen = 1'b1;
            cycles++;
        end

        @(posedge clk);
        if (pool_done)
            pool_done_seen = 1'b1;

        if (cycles >= TIMEOUT_CYCLES)
            $fatal(1, "Conv1-Pool1 timeout: received %0d/%0d", received, OUTPUT_COUNT);
        if (!pool_done_seen)
            $fatal(1, "Conv1-Pool1 done pulse was not observed");
        if (errors == 0)
            $display("PASS: Conv1-Pool1 chain matched all %0d Pool1 bytes in %0d cycles",
                     OUTPUT_COUNT, cycles);
        else
            $fatal(1, "FAIL: Conv1-Pool1 chain had %0d errors", errors);
        $finish;
    end
endmodule
