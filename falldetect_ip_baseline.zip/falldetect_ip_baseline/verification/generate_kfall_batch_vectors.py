import argparse
import csv
import json
from pathlib import Path

import numpy as np

from generate_scenario_vectors import infer, write_vector

FEATURES = ("AccX", "AccY", "AccZ", "GyrX", "GyrY", "GyrZ", "EulerX", "EulerY", "EulerZ")
INPUT_SCALE = 0.08433684706687927
INPUT_ZERO_POINT = -22


def load_rows(path):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def quantize(rows, mean, std):
    values = np.asarray([[float(row[name]) for name in FEATURES] for row in rows], dtype=np.float64)
    normalized = (values - mean) / std
    return np.clip(np.rint(normalized / INPUT_SCALE) + INPUT_ZERO_POINT, -128, 127).astype(np.int64)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sensor-root", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--subject", type=int, default=12)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mean", type=Path, default=Path("model/mean.npy"))
    parser.add_argument("--std", type=Path, default=Path("model/std.npy"))
    args = parser.parse_args()
    mean = np.load(args.mean).reshape(9)
    std = np.load(args.std).reshape(9)
    labels = json.loads(args.labels.read_text(encoding="utf-8"))
    subject_dir = args.sensor_root / f"SA{args.subject:02d}"
    windows = []

    for task in list(range(1, 20)) + list(range(35, 37)):
        paths = sorted(subject_dir.glob(f"S{args.subject:02d}T{task:02d}R*.csv"))
        if not paths:
            continue
        path = paths[0]
        rows = load_rows(path)
        start = max(0, len(rows) // 2 - 25)
        selected = rows[start : start + 50]
        windows.append((path.name, task, 0, start + 1, quantize(selected, mean, std)))

    for task in range(20, 35):
        task_entries = sorted((entry for entry in labels if entry["task"] == task), key=lambda entry: entry["trial"])
        selected_pair = None
        for entry in task_entries:
            candidate = subject_dir / f"S{args.subject:02d}T{task:02d}R{entry['trial']:02d}.csv"
            if candidate.exists():
                selected_pair = (entry, candidate)
                break
        if selected_pair is None:
            continue
        entry, path = selected_pair
        rows = load_rows(path)
        by_frame = {int(row["FrameCounter"]): row for row in rows}
        end = int(entry["impactFrame"])
        selected = [by_frame[frame] for frame in range(end - 49, end + 1)]
        windows.append((path.name, task, 1, end - 49, quantize(selected, mean, std)))

    args.output.mkdir(parents=True, exist_ok=True)
    all_inputs = np.concatenate([window[4].reshape(-1) for window in windows])
    logits = [infer(window[4]) for window in windows]
    write_vector(args.output / "kfall_batch_input.mem", all_inputs)
    (args.output / "kfall_batch_expected.mem").write_text(
        "\n".join(f"{value & 0xFF:02X}" for value in logits) + "\n", encoding="ascii"
    )
    (args.output / "kfall_batch_label.mem").write_text(
        "\n".join(str(window[2]) for window in windows) + "\n", encoding="ascii"
    )
    with (args.output / "kfall_batch_metadata.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(("index", "file", "task", "label_fall", "window_start_frame", "golden_logit", "predicted_fall"))
        for index, (window, logit) in enumerate(zip(windows, logits)):
            writer.writerow((index, window[0], window[1], window[2], window[3], logit, int(logit > -14)))
    correct = sum((logit > -14) == bool(window[2]) for window, logit in zip(windows, logits))
    summary = {"windows": len(windows), "golden_label_matches": correct, "selection_accuracy": correct / len(windows)}
    (args.output / "kfall_batch_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
