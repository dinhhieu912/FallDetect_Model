`timescale 1ns/1ps
module tb_fall_detect_app_top;
    localparam integer SAMPLES=50;
    logic clk,rst_n,sample_valid,sample_ready,event_valid,event_ready,event_fall,dsp_armed,cnn_active;
    logic signed[15:0] accel_x,accel_y,accel_z;
    logic[71:0] cnn_features_int8;
    logic[39:0] cfg_accel_threshold,cfg_jerk_threshold;
    logic[7:0] cfg_consecutive;
    logic signed[7:0] event_logit;
    logic signed[7:0] input_mem[0:449],expected[0:0];
    integer sample_index,channel,cycles,errors;logic saw_cnn_active;

    fall_detect_app_top #(.LPF_SHIFT(0)) dut(.*);
    always #5 clk=~clk;
    initial begin
        $dumpfile("verification/waves/fall_detect_demo.vcd");
        $dumpvars(0, clk, rst_n, sample_valid, sample_ready);
        $dumpvars(0, accel_x, accel_y, accel_z);
        $dumpvars(0, event_valid, event_ready, event_logit, event_fall);
        $dumpvars(0, dsp_armed, cnn_active);
        $dumpvars(0, dut.ctrl_state, dut.dsp_pending);
        $dumpvars(0, dut.lpf_valid, dut.lpf_x, dut.lpf_y, dut.lpf_z);
        $dumpvars(0, dut.energy_valid, dut.accel_energy, dut.jerk_energy);
        $dumpvars(0, dut.window_full, dut.trigger_pulse);
        $dumpvars(0, dut.buffer_valid, dut.buffer_ready, dut.buffer_done);
        $dumpvars(0, dut.cnn_start_valid, dut.cnn_start_ready);
        $dumpvars(0, dut.cnn_valid, dut.cnn_ready, dut.cnn_logit, dut.cnn_fall);
        $readmemh("verification/vectors/input.mem",input_mem);
        $readmemh("verification/vectors/dense2_out.mem",expected);
        if($isunknown(input_mem[0])||$isunknown(input_mem[449])||$isunknown(expected[0]))
            $fatal(1,"Application vectors missing or incomplete");
        clk=0;rst_n=0;sample_valid=0;accel_x=0;accel_y=0;accel_z=0;cnn_features_int8='0;
        cfg_accel_threshold=40'd1099511627775;cfg_jerk_threshold=40'd1000000;cfg_consecutive=1;
        event_ready=0;cycles=0;errors=0;saw_cnn_active=0;
        repeat(3)@(posedge clk);rst_n=1;

        for(sample_index=0;sample_index<SAMPLES;sample_index++)begin
            while(!sample_ready)@(posedge clk);
            @(negedge clk);
            for(channel=0;channel<9;channel++)
                cnn_features_int8[channel*8+:8]=input_mem[sample_index*9+channel];
            if(sample_index==SAMPLES-1)begin accel_x=16'sd1000;accel_y=16'sd1000;accel_z=16'sd1000;end
            else begin accel_x=0;accel_y=0;accel_z=0;end
            sample_valid=1;
            @(negedge clk);sample_valid=0;
        end

        while(!event_valid&&cycles<70000)begin
            @(negedge clk);event_ready=((cycles%13)!=0);@(posedge clk);
            if(cnn_active)saw_cnn_active=1;
            cycles++;
        end
        if(cycles>=70000)$fatal(1,"Application timeout waiting for event");
        if(!saw_cnn_active)begin $error("CNN never became active");errors++;end
        if(event_logit!==expected[0])begin $error("Event logit got %0d expected %0d",event_logit,expected[0]);errors++;end
        if(!event_fall)begin $error("Expected fall event");errors++;end
        if(dsp_armed)begin $error("DSP must remain disarmed while event is pending");errors++;end
        @(negedge clk);event_ready=1;@(posedge clk);@(negedge clk);event_ready=0;
        repeat(3)@(posedge clk);
        if(!dsp_armed)begin $error("DSP did not rearm after event acceptance");errors++;end
        if(!sample_ready)begin $error("Sensor path did not return to monitoring");errors++;end
        if(errors==0)$display("PASS: DSP trigger -> 50x9 buffer -> full CNN -> fall event, logit %0d, %0d cycles",expected[0],cycles);
        else $fatal(1,"FAIL: application integration had %0d errors",errors);
        $finish;
    end
endmodule
