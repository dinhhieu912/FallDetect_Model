# Waveform Demo

Run from the project root:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/run_waveform_demo.ps1 `
  -IverilogRoot "D:\Icarus\iverilog" -OpenGtkWave
```

The generated VCD is `verification/waves/fall_detect_demo.vcd`.

Recommended signal order in GTKWave:

1. `clk`, `rst_n`
2. `sample_valid`, `sample_ready`, `accel_x`, `accel_y`, `accel_z`
3. `dut.lpf_valid`, `dut.lpf_x`, `dut.lpf_y`, `dut.lpf_z`
4. `dut.energy_valid`, `dut.accel_energy`, `dut.jerk_energy`
5. `dut.window_full`, `dut.trigger_pulse`, `dsp_armed`
6. `dut.ctrl_state`, `dut.buffer_valid`, `dut.buffer_done`
7. `cnn_active`, `dut.cnn_start_valid`, `dut.cnn_valid`
8. `event_valid`, `event_ready`, `event_logit`, `event_fall`

Use signed decimal radix for acceleration, LPF values and logit. Use unsigned decimal for energy signals. Use binary or symbolic display for valid/ready/state signals.

The presentation story is: the first 49 acceleration samples remain zero; sample 50 steps to 1000 on all axes; jerk energy exceeds 1,000,000; the trigger disarms DSP and drains the frozen 50x9 window; CNN becomes active; logit 11 creates a fall event; event acceptance rearms monitoring.
