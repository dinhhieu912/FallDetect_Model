# Full Icarus Regression Report

Date: 2026-08-01  
Simulator: Icarus Verilog 12, installed at `D:\Icarus\iverilog`

## Summary

| Category | Count | Result |
|---|---:|---|
| New bit-accurate/directed baseline tests | 22 | 22 passed |
| Legacy testbenches compiled and completed | 15 | 15 completed |
| Legacy bit-accurate/self-checking tests | 0 | None currently qualify |
| Compile failures | 0 | None |
| Runtime failures/timeouts | 0 | None |
| X/Z detected in printed results | 0 | None |
| `$readmemh` failures | 0 | None |

## Bit-accurate baseline

| Testbench | Coverage | Result |
|---|---|---|
| `tb_requantize_int8` | 256 accumulator/multiplier/shift/zero-point/clamp vectors | PASS, 256/256 |
| `tb_conv1d_engine` | Complete Conv1 tensor, SAME padding, all 800 output bytes, position/channel tags and output backpressure | PASS, 800/800 |
| `tb_maxpool1d_stream` | Pool1 standalone with input bubbles and output backpressure | PASS, 400/400 |
| `tb_conv1_pool1_chain` | Integrated Conv1 to Pool1 ready/valid path | PASS, 400/400 |
| `tb_conv2_engine` | Conv2 standalone with per-channel requantization | PASS, 800/800 |
| `tb_conv1_pool1_conv2_chain` | Integrated three-stage path | PASS, 800/800 |
| `tb_pool2_stream` | Odd-length 25 to 12 pooling and discarded-tail handling | PASS, 384/384; 800/800 inputs consumed |
| `tb_cnn_frontend_chain` | Conv1, Pool1, Conv2 and Pool2 | PASS, 384/384 |
| `tb_global_avg_pool_int8` | Quantized 12-sample mean | PASS, 32/32 |
| `tb_dense_engine` | Dense1 four-lane engine | PASS, 16/16 |
| `tb_dense2_engine` | Dense2 one-lane logit engine | PASS, 1/1 |
| `tb_fall_cnn_int8_top` | Complete CNN and quantized decision threshold | PASS, logit byte 11 and fall decision |
| `tb_fall_detect_app_top` | Raw acceleration step through DSP trigger, window, CNN and held event | PASS, logit 11 and fall event |
| `tb_window_buffer_50x9` | Latest-50 ordering after circular write-pointer wrap | PASS, 450/450 bytes |
| `tb_dsp_trigger_fsm` | Window gate, consecutive count, disarm and rearm | PASS |
| `tb_dsp_datapath` | LPF and acceleration/jerk energy directed arithmetic | PASS, 3/3 vectors |
| `tb_fall_detect_apb_top` | APB configuration, full inference, sticky IRQ, event read and W1C clear | PASS, logit 11 and fall event |
| `tb_no_trigger_sleep` | Quiet 50-sample window and CNN power-gating behavior | PASS, CNN remained inactive |
| `tb_nonfall_event` | Independently generated triggered non-fall scenario | PASS, logit -35 and fall=0 |
| `tb_reset_mid_inference` | Reset while CNN is active, followed by clean recovery | PASS |
| `tb_two_inferences` | Two complete trigger/inference/event/rearm sequences | PASS, 2/2 events |
| `tb_kfall_batch_cnn` | 33 real SA12 KFall windows versus independent integer golden model | PASS, 33/33 RTL logits; 31/33 labels |

Conv1 required 19,598 monitored cycles in its self-checking test. The complete CNN required 39,597 monitored cycles from `start` to the accepted logit while output backpressure was enabled.

The complete application path required 40,051 monitored cycles from the trigger-producing sample sequence to the held event in the directed regression.

The baseline testbenches now terminate with `$fatal` if their vector files are missing or incomplete. This prevents a failed `$readmemh` from producing a false pass.

## Legacy RTL results

| Testbench | Simulation status | Verification strength |
|---|---|---|
| `tb_conv1_16_filter` | Completed | Smoke-only; prints 16 raw accumulator values |
| `tb_conv1_16_filter_relu` | Completed | Smoke-only; prints 16 ReLU values |
| `tb_conv1_first_mac` | Completed | Smoke-only; prints one accumulator |
| `tb_conv1_layer` | Completed | Smoke-only; prints four boundary values |
| `tb_conv1_pool_layer` | Completed | Smoke-only; prints four boundary values |
| `tb_conv2_32_filter` | Completed | Smoke-only; prints 32 raw values |
| `tb_conv2_first_mac` | Completed | Smoke-only; prints one accumulator |
| `tb_conv2_layer` | Completed | Smoke-only; prints four boundary values |
| `tb_dense1_16` | Completed | Smoke-only; prints 16 values |
| `tb_dense2_output` | Completed | Smoke-only; prints score/class from hard-coded input |
| `tb_fall_detect_top` | Completed | Smoke-only; top contains only the hard-coded Dense2 demo |
| `tb_global_avg_pool` | Completed | Smoke-only; checks only channels 0 and 31 using hard-coded data |
| `tb_mac_int8` | Completed | Smoke-only; three expected-looking values are printed but not asserted |
| `tb_maxpool1d` | Reports PASS | Only the final one of three examples is conditionally checked; no `$fatal` |
| `tb_weight_rom` | Completed | Smoke-only; prints addresses 0-4 |

Legacy simulations prove that the source compiles, memory files open, clocks/reset progress and each test terminates. They do **not** prove equivalence with TFLite. The architecture audit findings remain unchanged: legacy layers use dummy internal activation data, incompatible tensor shapes/weight addressing, and omit TFLite requantization.

## Warnings

- Legacy design modules do not declare explicit time units, producing Icarus time-unit warnings.
- Legacy `weight_rom.v` uses a combinational read over the full array; Icarus warns that `@*` is sensitive to all 720 words. This style is unsuitable for synchronous FPGA BRAM inference.
- No X/Z values or memory-open errors appeared in simulation output.

## Reproduction

Run the bit-accurate baseline:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass `
  -File scripts/run_iverilog.ps1 `
  -IverilogRoot "D:\Icarus\iverilog"
```

Run all legacy smoke tests:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass `
  -File scripts/run_legacy_smoke.ps1 `
  -IverilogRoot "D:\Icarus\iverilog" `
  -LegacyRtlDir "<path-to-legacy-rtl_code>"
```

Individual legacy logs and the machine-readable summary are stored under `verification/legacy_logs/`.
