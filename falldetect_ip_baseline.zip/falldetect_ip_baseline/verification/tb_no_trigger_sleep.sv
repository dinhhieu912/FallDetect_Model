`timescale 1ns/1ps
module tb_no_trigger_sleep;
    logic clk,rst_n,sample_valid,sample_ready,event_valid,event_ready,event_fall,dsp_armed,cnn_active;
    logic signed[15:0] accel_x,accel_y,accel_z;logic[71:0] cnn_features_int8;
    logic[39:0] cfg_accel_threshold,cfg_jerk_threshold;logic[7:0] cfg_consecutive;
    logic signed[7:0] event_logit;logic signed[7:0] input_mem[0:449];
    integer sample_index,channel,errors;logic saw_cnn_active;
    fall_detect_app_top #(.LPF_SHIFT(0)) dut(.*);
    always #5 clk=~clk;
    always@(posedge clk)if(cnn_active)saw_cnn_active<=1;
    initial begin
        $readmemh("verification/vectors/input.mem",input_mem);
        if($isunknown(input_mem[0])||$isunknown(input_mem[449]))$fatal(1,"No-trigger vector missing");
        clk=0;rst_n=0;sample_valid=0;accel_x=0;accel_y=0;accel_z=0;cnn_features_int8=0;
        cfg_accel_threshold={40{1'b1}};cfg_jerk_threshold=40'd1000000;cfg_consecutive=1;
        event_ready=0;errors=0;saw_cnn_active=0;repeat(3)@(posedge clk);rst_n=1;
        for(sample_index=0;sample_index<50;sample_index++)begin
            while(!sample_ready)@(posedge clk);@(negedge clk);
            for(channel=0;channel<9;channel++)cnn_features_int8[channel*8+:8]=input_mem[sample_index*9+channel];
            sample_valid=1;@(negedge clk);sample_valid=0;
        end
        repeat(200)@(posedge clk);
        if(saw_cnn_active)begin $error("CNN activated without a suspicious motion");errors++;end
        if(event_valid)begin $error("Event appeared without trigger");errors++;end
        if(!dsp_armed)begin $error("DSP unexpectedly disarmed");errors++;end
        if(!sample_ready)begin $error("Monitor path is not ready after quiet window");errors++;end
        if(errors==0)$display("PASS: quiet motion filled the window while CNN remained asleep and DSP armed");
        else $fatal(1,"No-trigger sleep test had %0d errors",errors);
        $finish;
    end
endmodule
