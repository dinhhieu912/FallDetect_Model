# Validation Record

## Golden model

- Frozen TFLite SHA-256: `FE44C82B85898A5EE00DC5B845F07209A6B65D28AB1E7157942C14ECFABBF8AE`
- Runtime: LiteRT 2.1.6 reference kernels (`BUILTIN_REF`)
- Stimulus: deterministic INT8 tensor, shape `[1,50,9]`

| Tensor | Values compared | Result |
|---|---:|---|
| Input | 450 | Pass |
| Conv1 | 800 | Pass |
| Pool1 | 400 | Pass |
| Conv2 | 800 | Pass |
| Pool2 | 384 | Pass |
| GAP | 32 | Pass |
| Dense1 | 16 | Pass |
| Dense2 logit | 1 | Pass |

Final quantized sigmoid output for this vector is decimal `107` (`0x6B`).

The reference-kernel choice is intentional. Optimized host CPU delegates can differ by one LSB on intermediate tensors; the reference kernel defines the portable bit-exact contract used by the RTL.

## RTL checks

- `requantize_int8.sv` and its testbench elaborate with zero diagnostics under slang/pyslang 11.0.
- A 256-vector self-checking RTL test set has been generated from the same integer reference algorithm.
- Dynamic RTL simulation was not run in this workspace because Icarus/Verilator is not installed. The supplied testbench is ready to run with any SystemVerilog simulator.

## Conv1 engine artifact check

- Packed four-lane ROM contains 180 words from 720 Conv1 weight bytes.
- An independent cycle-order datapath check reproduced all 800 Conv1 golden bytes with zero mismatches.
- Output order and ready/valid backpressure are checked by `tb_conv1d_engine.sv`.
- Icarus Verilog 12 regression result:
  - `requantize_int8`: 256/256 vectors passed.
  - `conv1d_engine`: 800/800 Conv1 bytes passed with output backpressure.
  - Conv1 monitored execution: 19,598 cycles.

The testbenches now explicitly fail when vector files are missing or incomplete; a failed `$readmemh` can no longer produce a false pass.
