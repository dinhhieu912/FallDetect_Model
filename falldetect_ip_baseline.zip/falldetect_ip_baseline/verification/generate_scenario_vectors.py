from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
MEM = ROOT / "mem"
VECTORS = ROOT / "verification" / "vectors"


def read_mem(name, bits, shape):
    values = []
    for line in (MEM / name).read_text(encoding="ascii").splitlines():
        value = int(line, 16)
        if value >= (1 << (bits - 1)):
            value -= 1 << bits
        values.append(value)
    return np.asarray(values, dtype=np.int64).reshape(shape)


def trunc_div(numerator, denominator):
    quotient = abs(numerator) // denominator
    return -quotient if numerator < 0 else quotient


def high_mul(a, b):
    if a == -(1 << 31) and b == -(1 << 31):
        return (1 << 31) - 1
    product = int(a) * int(b)
    nudge = (1 << 30) if product >= 0 else 1 - (1 << 30)
    return trunc_div(product + nudge, 1 << 31)


def rounding_divide_by_pot(value, exponent):
    if exponent == 0:
        return int(value)
    mask = (1 << exponent) - 1
    remainder = int(value) & mask
    threshold = (mask >> 1) + (1 if value < 0 else 0)
    return (int(value) >> exponent) + (1 if remainder > threshold else 0)


def requant(accumulator, multiplier, right_shift, output_zp, activation_min=-128):
    value = rounding_divide_by_pot(high_mul(accumulator, multiplier), right_shift)
    return min(max(value + output_zp, activation_min), 127)


def conv1d(inputs, weights, bias, multipliers, shifts, input_zp):
    length, input_channels = inputs.shape
    output_channels, kernel, _ = weights.shape
    outputs = np.empty((length, output_channels), dtype=np.int64)
    pad = kernel // 2
    for position in range(length):
        for output_channel in range(output_channels):
            acc = int(bias[output_channel])
            for kernel_index in range(kernel):
                source = position + kernel_index - pad
                if 0 <= source < length:
                    for input_channel in range(input_channels):
                        acc += (int(inputs[source, input_channel]) - input_zp) * int(
                            weights[output_channel, kernel_index, input_channel]
                        )
            outputs[position, output_channel] = requant(
                acc, multipliers[output_channel], shifts[output_channel], -128, -128
            )
    return outputs


def dense(inputs, weights, bias, multipliers, shifts, output_zp, activation_min):
    outputs = np.empty(weights.shape[0], dtype=np.int64)
    for output_channel in range(weights.shape[0]):
        acc = int(bias[output_channel])
        for input_channel in range(weights.shape[1]):
            acc += (int(inputs[input_channel]) + 128) * int(weights[output_channel, input_channel])
        outputs[output_channel] = requant(
            acc, multipliers[output_channel], shifts[output_channel], output_zp, activation_min
        )
    return outputs


conv1_w = read_mem("conv1_weight.mem", 8, (16, 5, 9))
conv1_b = read_mem("conv1_bias.mem", 32, (16,))
conv1_m = read_mem("conv1_multiplier.mem", 32, (16,))
conv1_s = read_mem("conv1_rshift.mem", 8, (16,))
conv2_w = read_mem("conv2_weight.mem", 8, (32, 3, 16))
conv2_b = read_mem("conv2_bias.mem", 32, (32,))
conv2_m = read_mem("conv2_multiplier.mem", 32, (32,))
conv2_s = read_mem("conv2_rshift.mem", 8, (32,))
dense1_w = read_mem("dense1_weight.mem", 8, (16, 32))
dense1_b = read_mem("dense1_bias.mem", 32, (16,))
dense1_m = read_mem("dense1_multiplier.mem", 32, (16,))
dense1_s = read_mem("dense1_rshift.mem", 8, (16,))
dense2_w = read_mem("dense2_weight.mem", 8, (1, 16))
dense2_b = read_mem("dense2_bias.mem", 32, (1,))
dense2_m = read_mem("dense2_multiplier.mem", 32, (1,))
dense2_s = read_mem("dense2_rshift.mem", 8, (1,))


def infer(inputs):
    conv1 = conv1d(inputs, conv1_w, conv1_b, conv1_m, conv1_s, -22)
    pool1 = np.maximum(conv1[0::2], conv1[1::2])
    conv2 = conv1d(pool1, conv2_w, conv2_b, conv2_m, conv2_s, -128)
    pool2 = np.maximum(conv2[0:24:2], conv2[1:24:2])
    gap = np.empty(32, dtype=np.int64)
    for channel in range(32):
        acc = sum(int(value) + 128 for value in pool2[:, channel])
        gap[channel] = requant(acc, 1308363552, 2, -128, -128)
    dense1 = dense(gap, dense1_w, dense1_b, dense1_m, dense1_s, -128, -128)
    dense2 = dense(dense1, dense2_w, dense2_b, dense2_m, dense2_s, -14, -128)
    return int(dense2[0])


def read_vector(name):
    values = read_mem(name, 8, (50, 9))
    return values


def write_vector(path, values):
    lines = [f"{int(value) & 0xFF:02X}" for value in values.reshape(-1)]
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def main():
    reference_logit = infer(read_vector("../verification/vectors/input.mem"))
    if reference_logit != 11:
        raise RuntimeError(f"Scenario generator self-check failed: expected logit 11, got {reference_logit}")

    candidates = [np.full((50, 9), value, dtype=np.int64) for value in (-22, -128, 0, 127)]
    rng = np.random.default_rng(0x4E4F4E46)
    candidates.extend(rng.integers(-128, 128, size=(50, 9), dtype=np.int16).astype(np.int64) for _ in range(128))
    for candidate_index, candidate in enumerate(candidates):
        logit = infer(candidate)
        if logit <= -14:
            write_vector(VECTORS / "input_nonfall.mem", candidate)
            (VECTORS / "dense2_nonfall_expected.mem").write_text(f"{logit & 0xFF:02X}\n", encoding="ascii")
            print(f"PASS: generated independent non-fall scenario {candidate_index}, logit {logit}")
            return
    raise RuntimeError("No non-fall scenario found")


if __name__ == "__main__":
    main()
