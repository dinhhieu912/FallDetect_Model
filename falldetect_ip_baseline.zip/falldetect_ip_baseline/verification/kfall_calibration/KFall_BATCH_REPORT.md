# Real KFall CNN RTL Batch

The batch contains 33 windows from subject SA12:

- ADL windows use the center 50 samples of the first available trial for T01-T19 and T35-T36.
- Fall windows use 50 samples ending at the labeled `Fall_impact_frame` for the first available trial of T20-T34.
- Every window uses the frozen nine-feature mean/std normalization and TFLite INT8 input quantization.

Results:

- RTL versus independent golden integer model: 33/33 exact logit matches.
- Golden model versus selected window labels: 31/33 (93.94%).
- False positives in this selection: S12T10R01 and S12T36R01.
- No RTL mismatch occurred on either correctly or incorrectly classified model windows.

The test separates model accuracy from hardware correctness: classification errors are retained as test vectors, and RTL is required to reproduce the model logit exactly.
