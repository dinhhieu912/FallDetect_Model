# KFall DSP Trigger Calibration Report

## Dataset

- 5,075 CSV trials and 3,995,100 samples.
- Sampling rate: 100 Hz.
- ADL: T01-T19 and T35-T36, 2,729 trials.
- Fall: T20-T34, 2,346 trials.
- Acceleration range observed: approximately -4 g to +4 g on every axis.
- Internal RTL acceleration format: signed16 Q5.10, 1024 counts/g.
- Signed16 clipping: 0 dataset values.
- CNN INT8 saturation: 6,820 of 35,955,900 feature values (0.019%).

## Method

Each CSV trial was processed with the same integer arithmetic as RTL. Trigger scoring begins only after sample 50, matching the `window_full` gate. Five LPF shifts and consecutive counts 1-3 were swept. Metrics are trial-level: an ADL trial is a false trigger if it wakes CNN at least once; a fall trial is recalled if DSP wakes CNN at least once.

## Consecutive-3 trade-off

| LPF shift | Target ADL trigger rate | Threshold | Measured ADL trigger rate | Fall trigger recall |
|---:|---:|---:|---:|---:|
| 0 | 20% | 764,466 | 19.97% | 73.87% |
| 1 | 20% | 340,499 | 19.97% | 82.52% |
| 2 | 20% | 146,632 | 19.97% | 87.43% |
| 3 | 20% | 51,077 | 19.97% | 93.22% |
| 4 | 10% | 22,554 | 9.97% | 87.51% |
| 4 | 20% | 14,325 | 19.97% | 97.10% |
| 4 | 50% | 3,437 | 49.98% | 100.00% |

## Frozen default

- `LPF_SHIFT = 4`
- `cfg_consecutive = 3`
- `cfg_jerk_threshold = 14,325`
- `cfg_accel_threshold = maximum` (jerk-only trigger policy)

This operating point prioritizes fall recall while still avoiding CNN execution in approximately 80% of complete ADL trials. The CNN remains responsible for rejecting triggered ADL windows. APB registers allow a lower-power or higher-recall operating point without changing RTL.

## Limitations

This is a trial-level DSP screening analysis, not end-to-end model sensitivity/specificity. Subject-independent holdout reporting and CNN evaluation on the exact training window-selection policy should remain separate metrics.
