# Fall Detection INT8 IP Baseline

This baseline freezes `falldetect_small_int8.tflite` as the version-1 hardware model and provides the first bit-accurate RTL foundation.

## What is complete

- Model SHA-256 is locked in `model/model_manifest.json`.
- TFLite tensor shapes, scales, zero-points and per-channel quantization are extracted automatically.
- Conv/Dense weights use one canonical filter-major layout:
  - Conv: `OC_K_IC` from TFLite `[OC,1,K,IC]`.
  - Dense: `OC_IC`.
- The previously missing Dense2 INT32 bias is generated as `mem/dense2_bias.mem`.
- Q31 multiplier and right-shift tables are generated for Conv1, Conv2, Dense1 and Dense2.
- A pure integer Python golden model covers Conv1, Pool1, Conv2, Pool2, GAP, Dense1 and Dense2.
- Every intermediate tensor matches the LiteRT reference kernel byte-for-byte for the deterministic regression input.
- `rtl/requantize_int8.sv` implements the verified TFLite multiplier, rounding, zero-point and saturation contract.
- `verification/tb_requantize_int8.sv` is a self-checking 256-vector testbench.
- The complete `Conv1 -> Pool1 -> Conv2 -> Pool2 -> GAP -> Dense1 -> Dense2` RTL path is self-checking against the frozen golden tensors.
- The DSP-gated application wrapper, circular window buffer and event handshake are integrated and self-checking.
- An APB3 register/IRQ wrapper and reproducible FPGA/NanGate45 synthesis scripts are included.

## Frozen network

```text
INT8 [50,9]
  -> Conv1 K5 SAME, 16, ReLU     [50,16]
  -> MaxPool K2 S2 VALID         [25,16]
  -> Conv2 K3 SAME, 32, ReLU     [25,32]
  -> MaxPool K2 S2 VALID         [12,32]
  -> Global Average Pool         [32]
  -> Dense 16, ReLU              [16]
  -> Dense 1                     [1 logit]
  -> Sigmoid                     [1 probability]
```

The accelerator should expose the pre-sigmoid logit or event decision. A hardware sigmoid is unnecessary when only binary classification is required.

## Regenerate and verify artifacts

Run from this directory with Python packages `numpy`, `tflite`, `flatbuffers`, and `ai-edge-litert` available:

```powershell
python model/build_model_artifacts.py `
  --model model/falldetect_small_int8.tflite `
  --output .
```

Expected result:

```text
PASS input: 450 values
PASS conv1_out: 800 values
PASS pool1_out: 400 values
PASS conv2_out: 800 values
PASS pool2_out: 384 values
PASS gap_out: 32 values
PASS dense1_out: 16 values
PASS dense2_out: 1 values
PASS LiteRT output probability byte: 107
```

## Simulate requantization RTL

Example with Icarus Verilog:

```powershell
iverilog -g2012 -s tb_requantize_int8 `
  -o sim_requant `
  rtl/requantize_int8.sv `
  verification/tb_requantize_int8.sv
vvp sim_requant
```

Expected result:

```text
PASS: requantize_int8 matched all 256 vectors
```

Run the complete Windows regression using the installed Icarus location:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/run_iverilog.ps1 `
  -IverilogRoot "D:\Icarus\iverilog"
```

Verified result:

```text
PASS: requantize_int8 matched all 256 vectors
PASS: conv1d_engine matched all 800 bytes in 19598 monitored cycles
PASS: maxpool1d_stream matched all 400 Pool1 bytes
PASS: Conv1-Pool1 chain matched all 400 Pool1 bytes
PASS: Conv2 engine matched all 800 bytes
PASS: Pool2 odd-length stream matched all 384 bytes
PASS: global_avg_pool_int8 matched all 32 bytes
PASS: Dense1 engine matched all 16 bytes
PASS: Dense2 engine matched logit byte 11
PASS: full INT8 CNN matched logit byte 11 and fall decision
PASS: DSP trigger -> 50x9 buffer -> full CNN -> fall event
PASS: circular window retained latest 50 samples across pointer wrap
PASS: trigger FSM window gate, consecutive count, disarm and rearm
PASS: LPF and jerk energy matched directed vectors
PASS: APB configuration -> DSP/CNN -> sticky IRQ and W1C clear
PASS: quiet motion kept CNN asleep
PASS: triggered non-fall produced logit -35 and fall=0
PASS: reset aborted inference and recovered cleanly
PASS: two consecutive inferences completed correctly
PASS: RTL matched 33/33 real KFall golden logits; selected-window accuracy 31/33

## KFall calibration milestone

- Complete scan: 5,075 trials, 3,995,100 samples at 100 Hz.
- Frozen sensor contract: signed16 Q5.10 acceleration, no clipping over the dataset.
- Default trigger: `LPF_SHIFT=4`, jerk threshold 14,325, consecutive count 3.
- Measured trial-level operating point: 97.10% fall trigger recall and 19.97% ADL trigger rate.
- Real-data RTL batch: all 33 SA12 window logits match the independent golden integer model; 31/33 selected labels are classified correctly.
```

The complete baseline plus legacy simulation classification is documented in
`verification/FULL_REGRESSION.md`.

## Hardware contract

`requantize_int8.sv` accepts an INT32 accumulator, positive Q31 multiplier, right shift, output zero-point and activation clamp limits. It has a one-cycle registered output and an always-ready input.

This version intentionally supports real multipliers strictly between zero and one. All requantization multipliers in the frozen model satisfy that condition. Supporting positive binary shifts later should be a deliberate interface revision with new overflow tests.

## Conv1 engine milestone

- `rtl/conv1d_engine.sv`: parameterized four-lane Conv1D engine.
- `rtl/sync_rom_1r.sv`: technology-neutral synchronous ROM wrapper.
- `mem/conv1_weight_lane4.mem`: 180 packed 32-bit weight words.
- `verification/tb_conv1d_engine.sv`: self-checking 800-byte Conv1 regression with output backpressure.
- `architecture/conv1d_engine.md`: interface, datapath, FSM, timing and power decisions.

The packed-ROM/addressing datapath reproduces all 800 Conv1 golden bytes with zero mismatches in the independent reference check.

## Pool1 streaming milestone

- `rtl/maxpool1d_stream.sv`: parameterized signed INT8 K2/S2/VALID streaming pool.
- `verification/tb_maxpool1d_stream.sv`: standalone 400-byte Pool1 regression with bubbles and backpressure.
- `verification/tb_conv1_pool1_chain.sv`: integrated Conv1-to-Pool1 regression.
- `architecture/maxpool1d_stream.md`: interface, datapath, timing, area and power decisions.

## Next implementation milestone

Freeze the physical sensor/Q-format contract, generate the nine raw-to-INT8 affine preprocessing constants, select the exact FPGA part/board pinout, then run the supplied implementation flow.

## DSP-gated application milestone

- `rtl/lpf_iir3.sv`: three-axis shift-coefficient IIR low-pass filter.
- `rtl/jerk_energy3.sv`: acceleration and jerk sum-of-squares datapath without square root.
- `rtl/dsp_trigger_fsm.sv`: configurable threshold, consecutive-count, arm/disarm/rearm policy.
- `rtl/window_buffer_50x9.sv`: latest-window circular buffer with chronological drain.
- `rtl/fall_detect_app_top.sv`: complete DSP-gated CNN/event integration.
- `verification/tb_fall_detect_app_top.sv`: directed sensor-to-event system regression.

The application interface intentionally carries raw signed 16-bit acceleration for DSP and nine already-quantized INT8 features for CNN. Direct raw-IMU quantization is not frozen until the sensor unit, range and fixed-point format are specified.

Do not integrate LPF/Jerk/Trigger until the CNN core passes end-to-end integer regression.
