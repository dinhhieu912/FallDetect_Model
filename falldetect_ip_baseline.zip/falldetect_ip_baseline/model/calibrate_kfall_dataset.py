import argparse
import csv
import json
import re
from pathlib import Path

import numpy as np

FEATURES = ("AccX", "AccY", "AccZ", "GyrX", "GyrY", "GyrZ", "EulerX", "EulerY", "EulerZ")
INPUT_SCALE = 0.08433684706687927
INPUT_ZERO_POINT = -22
TASK_RE = re.compile(r"T(\d{2})R", re.IGNORECASE)


def run_score(values, consecutive):
    if len(values) < consecutive:
        return 0
    if consecutive == 1:
        return int(np.max(values))
    windows = np.lib.stride_tricks.sliding_window_view(values, consecutive)
    return int(np.max(np.min(windows, axis=1)))


def read_trial(path, mean, std, counts_per_g, lpf_shift):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        return None
    missing = [name for name in FEATURES if name not in rows[0]]
    if missing:
        raise RuntimeError(f"{path} missing columns {missing}")

    physical = np.asarray([[float(row[name]) for name in FEATURES] for row in rows], dtype=np.float64)
    normalized = (physical - mean) / std
    quantized = np.clip(np.rint(normalized / INPUT_SCALE) + INPUT_ZERO_POINT, -128, 127)
    saturation = int(np.count_nonzero((quantized == -128) | (quantized == 127)))

    raw_unclipped = np.rint(physical[:, :3] * counts_per_g).astype(np.int64)
    clipped_values = int(np.count_nonzero((raw_unclipped < -32768) | (raw_unclipped > 32767)))
    raw = np.clip(raw_unclipped, -32768, 32767)
    state = np.zeros(3, dtype=np.int64)
    previous = None
    accel = np.empty(len(rows), dtype=np.int64)
    jerk = np.empty(len(rows), dtype=np.int64)
    for index, sample in enumerate(raw):
        state = state + ((sample - state) >> lpf_shift)
        accel[index] = np.dot(state, state)
        jerk[index] = 0 if previous is None else np.dot(state - previous, state - previous)
        previous = state.copy()

    timestamps = np.asarray([float(row["TimeStamp(s)"]) for row in rows], dtype=np.float64)
    positive_dt = np.diff(timestamps)
    positive_dt = positive_dt[positive_dt > 0]
    median_dt = float(np.median(positive_dt)) if positive_dt.size else None
    return {
        "samples": len(rows),
        "acc_min_g": physical[:, :3].min(axis=0).tolist(),
        "acc_max_g": physical[:, :3].max(axis=0).tolist(),
        "saturation": saturation,
        "feature_values": int(quantized.size),
        "clipped_accel_values": clipped_values,
        "median_dt": median_dt,
        "max_accel_energy": int(np.max(accel)),
        "jerk_scores": {str(c): run_score(jerk[49:], c) for c in (1, 2, 3)},
    }


def select_threshold(adl_scores, fall_scores, target_fpr):
    candidates = np.unique(np.concatenate((adl_scores, fall_scores)))
    candidates = np.append(candidates, candidates[-1] + 1)
    feasible = []
    for threshold in candidates:
        fpr = float(np.mean(adl_scores >= threshold))
        recall = float(np.mean(fall_scores >= threshold))
        if fpr <= target_fpr:
            feasible.append((recall, -int(threshold), fpr, int(threshold)))
    recall, _, fpr, threshold = max(feasible)
    return {"threshold": threshold, "adl_false_trigger_rate": fpr, "fall_trigger_recall": recall}


def main():
    parser = argparse.ArgumentParser(description="Calibrate the RTL DSP trigger on the complete KFall dataset")
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mean", type=Path, default=Path("model/mean.npy"))
    parser.add_argument("--std", type=Path, default=Path("model/std.npy"))
    parser.add_argument("--accel-counts-per-g", type=float, default=1024.0)
    parser.add_argument("--lpf-shift", type=int, default=3)
    parser.add_argument("--target-adl-false-trigger-rate", type=float, default=0.01)
    args = parser.parse_args()

    mean = np.load(args.mean).reshape(9)
    std = np.load(args.std).reshape(9)
    csv_paths = sorted(args.dataset.rglob("*.csv"))
    if not csv_paths:
        raise RuntimeError(f"No CSV files found below {args.dataset}")

    trials = []
    global_min = np.full(3, np.inf)
    global_max = np.full(3, -np.inf)
    saturation = feature_values = clipped_accel_values = total_samples = 0
    sample_periods = []
    for index, path in enumerate(csv_paths, start=1):
        match = TASK_RE.search(path.name)
        if not match:
            continue
        task = int(match.group(1))
        label = "fall" if 20 <= task <= 34 else "adl"
        result = read_trial(path, mean, std, args.accel_counts_per_g, args.lpf_shift)
        if result is None:
            continue
        global_min = np.minimum(global_min, result["acc_min_g"])
        global_max = np.maximum(global_max, result["acc_max_g"])
        saturation += result["saturation"]
        feature_values += result["feature_values"]
        clipped_accel_values += result["clipped_accel_values"]
        total_samples += result["samples"]
        if result["median_dt"] is not None:
            sample_periods.append(result["median_dt"])
        trials.append({
            "file": str(path.relative_to(args.dataset)), "task": task, "label": label,
            "samples": result["samples"], "max_accel_energy": result["max_accel_energy"],
            "jerk_score_c1": result["jerk_scores"]["1"],
            "jerk_score_c2": result["jerk_scores"]["2"],
            "jerk_score_c3": result["jerk_scores"]["3"],
        })
        if index % 500 == 0:
            print(f"processed {index}/{len(csv_paths)}", flush=True)

    metrics = {}
    for consecutive in (1, 2, 3):
        key = f"jerk_score_c{consecutive}"
        adl = np.asarray([trial[key] for trial in trials if trial["label"] == "adl"], dtype=np.int64)
        fall = np.asarray([trial[key] for trial in trials if trial["label"] == "fall"], dtype=np.int64)
        metrics[str(consecutive)] = select_threshold(adl, fall, args.target_adl_false_trigger_rate)
        metrics[str(consecutive)]["adl_trials"] = int(adl.size)
        metrics[str(consecutive)]["fall_trials"] = int(fall.size)

    best_consecutive = max(
        metrics,
        key=lambda key: (metrics[key]["fall_trigger_recall"], -metrics[key]["adl_false_trigger_rate"], -int(key)),
    )
    summary = {
        "dataset_root": str(args.dataset),
        "trial_count": len(trials),
        "sample_count": total_samples,
        "sample_rate_hz": 1.0 / float(np.median(sample_periods)),
        "task_policy": "ADL=T01-T19,T35-T36; fall=T20-T34",
        "acceleration_format": {
            "counts_per_g": args.accel_counts_per_g,
            "rtl_interpretation": "signed16 Q5.10 g" if args.accel_counts_per_g == 1024 else "custom",
            "dataset_min_g_xyz": global_min.tolist(),
            "dataset_max_g_xyz": global_max.tolist(),
            "clipped_value_count": clipped_accel_values,
        },
        "lpf_shift": args.lpf_shift,
        "feature_quantization": {
            "total_values": feature_values,
            "saturated_values": saturation,
            "saturation_rate": saturation / feature_values,
        },
        "target_adl_false_trigger_rate": args.target_adl_false_trigger_rate,
        "jerk_threshold_metrics": metrics,
        "recommended": {"consecutive": int(best_consecutive), **metrics[best_consecutive]},
        "note": "Trial-level trigger screening only; CNN classification remains responsible for rejecting triggered ADL windows.",
    }

    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "kfall_calibration_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    with (args.output / "kfall_trial_scores.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(trials[0]))
        writer.writeheader(); writer.writerows(trials)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
