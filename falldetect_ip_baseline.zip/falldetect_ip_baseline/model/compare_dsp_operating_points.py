import argparse
import csv
import json
import re
from pathlib import Path

import numpy as np

TASK_RE = re.compile(r"T(\d{2})R", re.IGNORECASE)


def score(values, consecutive):
    if consecutive == 1:
        return int(values.max())
    windows = np.lib.stride_tricks.sliding_window_view(values, consecutive)
    return int(np.min(windows, axis=1).max())


def threshold_at_fpr(adl, fall, target):
    candidates = np.unique(np.concatenate((adl, fall, [adl.max() + 1])))
    feasible = []
    for threshold in candidates:
        fpr = float(np.mean(adl >= threshold))
        recall = float(np.mean(fall >= threshold))
        if fpr <= target:
            feasible.append((recall, -int(threshold), fpr, int(threshold)))
    recall, _, fpr, threshold = max(feasible)
    return {"threshold": threshold, "adl_false_trigger_rate": fpr, "fall_trigger_recall": recall}


def main():
    parser = argparse.ArgumentParser(description="Compare KFall DSP trigger operating points")
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--accel-counts-per-g", type=float, default=1024.0)
    parser.add_argument("--lpf-shifts", default="0,1,2,3,4")
    parser.add_argument("--target-fprs", default="0.01,0.05,0.10,0.20,0.50")
    args = parser.parse_args()
    shifts = [int(value) for value in args.lpf_shifts.split(",")]
    target_fprs = [float(value) for value in args.target_fprs.split(",")]
    paths = sorted(args.dataset.rglob("*.csv"))
    trial_scores = []

    for file_index, path in enumerate(paths, start=1):
        match = TASK_RE.search(path.name)
        if not match:
            continue
        task = int(match.group(1))
        label = "fall" if 20 <= task <= 34 else "adl"
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            raw = np.asarray(
                [[float(row["AccX"]), float(row["AccY"]), float(row["AccZ"])] for row in reader],
                dtype=np.float64,
            )
        raw = np.clip(np.rint(raw * args.accel_counts_per_g), -32768, 32767).astype(np.int64)
        record = {"file": str(path.relative_to(args.dataset)), "task": task, "label": label}
        for shift in shifts:
            state = np.zeros(3, dtype=np.int64)
            previous = None
            jerk = np.empty(len(raw), dtype=np.int64)
            for index, sample in enumerate(raw):
                state = state + ((sample - state) >> shift)
                jerk[index] = 0 if previous is None else np.dot(state - previous, state - previous)
                previous = state.copy()
            # The RTL trigger is gated until the 50-sample CNN window is full.
            eligible_jerk = jerk[49:]
            for consecutive in (1, 2, 3):
                record[f"s{shift}_c{consecutive}"] = score(eligible_jerk, consecutive)
        trial_scores.append(record)
        if file_index % 500 == 0:
            print(f"processed {file_index}/{len(paths)}", flush=True)

    operating_points = []
    for shift in shifts:
        for consecutive in (1, 2, 3):
            key = f"s{shift}_c{consecutive}"
            adl = np.asarray([row[key] for row in trial_scores if row["label"] == "adl"], dtype=np.int64)
            fall = np.asarray([row[key] for row in trial_scores if row["label"] == "fall"], dtype=np.int64)
            for target_fpr in target_fprs:
                point = threshold_at_fpr(adl, fall, target_fpr)
                operating_points.append({
                    "lpf_shift": shift, "consecutive": consecutive,
                    "target_adl_false_trigger_rate": target_fpr, **point,
                })

    candidates_95 = [point for point in operating_points if point["fall_trigger_recall"] >= 0.95]
    if candidates_95:
        recommended = min(
            candidates_95,
            key=lambda point: (point["adl_false_trigger_rate"], -point["fall_trigger_recall"], point["lpf_shift"]),
        )
        policy = "minimum measured ADL false-trigger rate among operating points with at least 95% fall recall"
    else:
        recommended = max(
            operating_points,
            key=lambda point: (point["fall_trigger_recall"], -point["adl_false_trigger_rate"]),
        )
        policy = "maximum fall recall because no evaluated point reached 95%"

    summary = {
        "trial_count": len(trial_scores),
        "accel_counts_per_g": args.accel_counts_per_g,
        "operating_points": operating_points,
        "recommendation_policy": policy,
        "recommended": recommended,
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "dsp_operating_points.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    with (args.output / "dsp_operating_points.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(operating_points[0]))
        writer.writeheader(); writer.writerows(operating_points)
    print(json.dumps({"recommendation_policy": policy, "recommended": recommended}, indent=2))


if __name__ == "__main__":
    main()
