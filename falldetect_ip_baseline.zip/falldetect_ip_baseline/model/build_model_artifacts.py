#!/usr/bin/env python3
"""Build and verify the frozen small-model hardware artifacts.

The script reads the TFLite FlatBuffer directly, generates a machine-readable
manifest and hardware memory images, then compares a pure integer NumPy model
against LiteRT intermediate tensors.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import struct
from pathlib import Path

import numpy as np
import tflite
from ai_edge_litert.interpreter import Interpreter, OpResolverType


EXPECTED_MODEL_SHA256 = "FE44C82B85898A5EE00DC5B845F07209A6B65D28AB1E7157942C14ECFABBF8AE"

TENSOR_IDS = {
    "input": 0,
    "dense2_bias": 7,
    "dense2_weight": 8,
    "dense1_bias": 9,
    "dense1_weight": 10,
    "conv2_bias": 11,
    "conv2_weight": 12,
    "conv1_bias": 13,
    "conv1_weight": 14,
    "conv1_out": 17,
    "pool1_out": 20,
    "conv2_out": 23,
    "pool2_out": 26,
    "gap_out": 27,
    "dense1_out": 28,
    "dense2_out": 29,
    "output": 30,
}

LAYER_SPECS = {
    "conv1": ("input", "conv1_weight", "conv1_out"),
    "conv2": ("pool1_out", "conv2_weight", "conv2_out"),
    "dense1": ("gap_out", "dense1_weight", "dense1_out"),
    "dense2": ("dense1_out", "dense2_weight", "dense2_out"),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def decode(value) -> str:
    return value.decode("utf-8", errors="replace") if isinstance(value, bytes) else str(value)


def vec(obj, length_name: str, item_name: str):
    return [getattr(obj, item_name)(i) for i in range(getattr(obj, length_name)())]


def tensor_quant(tensor) -> dict:
    quant = tensor.Quantization()
    return {
        "scale": [float(v) for v in vec(quant, "ScaleLength", "Scale")],
        "zero_point": [int(v) for v in vec(quant, "ZeroPointLength", "ZeroPoint")],
        "quantized_dimension": int(quant.QuantizedDimension()),
    }


def tensor_info(subgraph, index: int) -> dict:
    tensor = subgraph.Tensors(index)
    return {
        "index": index,
        "name": decode(tensor.Name()),
        "shape": [int(v) for v in vec(tensor, "ShapeLength", "Shape")],
        "type": int(tensor.Type()),
        "buffer": int(tensor.Buffer()),
        "quantization": tensor_quant(tensor),
    }


def tensor_array(model, subgraph, index: int) -> np.ndarray:
    tensor = subgraph.Tensors(index)
    shape = tuple(int(v) for v in vec(tensor, "ShapeLength", "Shape"))
    raw = model.Buffers(tensor.Buffer()).DataAsNumpy().tobytes()
    dtype_by_type = {
        tflite.TensorType.INT8: np.dtype("i1"),
        tflite.TensorType.INT32: np.dtype("<i4"),
    }
    dtype = dtype_by_type.get(tensor.Type())
    if dtype is None:
        raise ValueError(f"Unsupported constant tensor type {tensor.Type()} at index {index}")
    return np.frombuffer(raw, dtype=dtype).reshape(shape).copy()


def quantize_multiplier(real_multiplier: float) -> tuple[int, int]:
    if not (0.0 < real_multiplier < 1.0):
        raise ValueError(f"This baseline supports 0 < multiplier < 1, got {real_multiplier}")
    significand, shift = math.frexp(real_multiplier)
    q_fixed = int(math.floor(significand * (1 << 31) + 0.5))
    if q_fixed == (1 << 31):
        q_fixed //= 2
        shift += 1
    return q_fixed, shift


def trunc_div(numerator: int, denominator: int) -> int:
    quotient = abs(numerator) // denominator
    return -quotient if numerator < 0 else quotient


def saturating_rounding_doubling_high_mul(a: int, b: int) -> int:
    if a == -(1 << 31) and b == -(1 << 31):
        return (1 << 31) - 1
    product = int(a) * int(b)
    nudge = (1 << 30) if product >= 0 else 1 - (1 << 30)
    return trunc_div(product + nudge, 1 << 31)


def rounding_divide_by_pot(value: int, exponent: int) -> int:
    if exponent == 0:
        return int(value)
    mask = (1 << exponent) - 1
    remainder = int(value) & mask
    threshold = (mask >> 1) + (1 if value < 0 else 0)
    return (int(value) >> exponent) + (1 if remainder > threshold else 0)


def multiply_by_quantized_multiplier(value: int, multiplier: int, shift: int) -> int:
    if shift > 0:
        raise ValueError("Positive shifts are outside this baseline's verified hardware contract")
    high = saturating_rounding_doubling_high_mul(int(value), int(multiplier))
    return rounding_divide_by_pot(high, -shift)


def requantize_scalar(
    accumulator: int,
    multiplier: int,
    shift: int,
    output_zero_point: int,
    activation_min: int = -128,
    activation_max: int = 127,
) -> np.int8:
    value = multiply_by_quantized_multiplier(accumulator, multiplier, shift)
    value += output_zero_point
    return np.int8(min(max(value, activation_min), activation_max))


def layer_requant_params(tensors: dict, layer: str) -> tuple[np.ndarray, np.ndarray]:
    input_name, weight_name, output_name = LAYER_SPECS[layer]
    input_scale = tensors[input_name]["quantization"]["scale"][0]
    weight_scales = tensors[weight_name]["quantization"]["scale"]
    output_scale = tensors[output_name]["quantization"]["scale"][0]
    multipliers = []
    shifts = []
    for weight_scale in weight_scales:
        multiplier, shift = quantize_multiplier(input_scale * weight_scale / output_scale)
        multipliers.append(multiplier)
        shifts.append(shift)
    return np.asarray(multipliers, dtype=np.int64), np.asarray(shifts, dtype=np.int64)


def conv1d_same_int8(
    inputs: np.ndarray,
    weights: np.ndarray,
    bias: np.ndarray,
    input_zero_point: int,
    output_zero_point: int,
    multipliers: np.ndarray,
    shifts: np.ndarray,
    relu: bool,
) -> np.ndarray:
    # TFLite Conv2D storage is [OC, 1, K, IC].
    weights = weights[:, 0, :, :]
    length, input_channels = inputs.shape
    output_channels, kernel, weight_input_channels = weights.shape
    assert input_channels == weight_input_channels
    pad_left = kernel // 2
    outputs = np.empty((length, output_channels), dtype=np.int8)
    activation_min = output_zero_point if relu else -128
    for position in range(length):
        for output_channel in range(output_channels):
            accumulator = int(bias[output_channel])
            for kernel_index in range(kernel):
                source_position = position + kernel_index - pad_left
                if 0 <= source_position < length:
                    for input_channel in range(input_channels):
                        centered = int(inputs[source_position, input_channel]) - input_zero_point
                        accumulator += centered * int(weights[output_channel, kernel_index, input_channel])
            outputs[position, output_channel] = requantize_scalar(
                accumulator,
                int(multipliers[output_channel]),
                int(shifts[output_channel]),
                output_zero_point,
                activation_min,
                127,
            )
    return outputs


def maxpool2_valid(inputs: np.ndarray) -> np.ndarray:
    output_length = inputs.shape[0] // 2
    return np.maximum(inputs[0 : 2 * output_length : 2], inputs[1 : 2 * output_length : 2])


def mean_int8(inputs: np.ndarray, input_quant: dict, output_quant: dict) -> np.ndarray:
    count, channels = inputs.shape
    real_multiplier = input_quant["scale"][0] / (count * output_quant["scale"][0])
    multiplier, shift = quantize_multiplier(real_multiplier)
    input_zero_point = input_quant["zero_point"][0]
    output_zero_point = output_quant["zero_point"][0]
    outputs = np.empty(channels, dtype=np.int8)
    for channel in range(channels):
        accumulator = sum(int(v) - input_zero_point for v in inputs[:, channel])
        outputs[channel] = requantize_scalar(
            accumulator, multiplier, shift, output_zero_point, -128, 127
        )
    return outputs


def dense_int8(
    inputs: np.ndarray,
    weights: np.ndarray,
    bias: np.ndarray,
    input_zero_point: int,
    output_zero_point: int,
    multipliers: np.ndarray,
    shifts: np.ndarray,
    relu: bool,
) -> np.ndarray:
    outputs = np.empty(weights.shape[0], dtype=np.int8)
    activation_min = output_zero_point if relu else -128
    for output_channel in range(weights.shape[0]):
        accumulator = int(bias[output_channel])
        for input_channel in range(weights.shape[1]):
            centered = int(inputs[input_channel]) - input_zero_point
            accumulator += centered * int(weights[output_channel, input_channel])
        outputs[output_channel] = requantize_scalar(
            accumulator,
            int(multipliers[output_channel]),
            int(shifts[output_channel]),
            output_zero_point,
            activation_min,
            127,
        )
    return outputs


def deterministic_input() -> np.ndarray:
    values = np.arange(50 * 9, dtype=np.int64)
    return (((values * 37 + 11) % 256) - 128).astype(np.int8).reshape(50, 9)


def write_mem(path: Path, values: np.ndarray, bits: int):
    mask = (1 << bits) - 1
    width = (bits + 3) // 4
    lines = [f"{int(value) & mask:0{width}X}" for value in values.reshape(-1)]
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def write_lane_packed_conv_mem(path: Path, weights: np.ndarray, lanes: int):
    if weights.ndim != 4 or weights.shape[1] != 1:
        raise ValueError(f"Expected TFLite Conv weight [OC,1,K,IC], got {weights.shape}")
    output_channels, _, kernel, input_channels = weights.shape
    if output_channels % lanes:
        raise ValueError(f"Output channels {output_channels} are not divisible by {lanes} lanes")
    lines = []
    for group in range(output_channels // lanes):
        for kernel_index in range(kernel):
            for input_channel in range(input_channels):
                word = 0
                for lane in range(lanes):
                    output_channel = group * lanes + lane
                    value = int(weights[output_channel, 0, kernel_index, input_channel]) & 0xFF
                    word |= value << (8 * lane)
                lines.append(f"{word:0{2 * lanes}X}")
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def write_lane_packed_dense_mem(path: Path, weights: np.ndarray, lanes: int):
    if weights.ndim != 2:
        raise ValueError(f"Expected Dense weight [OC,IC], got {weights.shape}")
    output_channels, input_features = weights.shape
    if output_channels % lanes:
        raise ValueError(f"Output channels {output_channels} are not divisible by {lanes} lanes")
    lines = []
    for group in range(output_channels // lanes):
        for input_feature in range(input_features):
            word = 0
            for lane in range(lanes):
                output_channel = group * lanes + lane
                value = int(weights[output_channel, input_feature]) & 0xFF
                word |= value << (8 * lane)
            lines.append(f"{word:0{2 * lanes}X}")
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def generate_requant_vectors(tensors: dict, requant: dict, vector_dir: Path):
    rng = np.random.default_rng(0xF411)
    accumulators = rng.integers(-(1 << 31), 1 << 31, size=256, dtype=np.int64)
    layer_names = tuple(LAYER_SPECS)
    multipliers = []
    right_shifts = []
    output_zero_points = []
    activation_mins = []
    activation_maxes = []
    expected = []
    for index, accumulator in enumerate(accumulators):
        layer = layer_names[index % len(layer_names)]
        output_name = LAYER_SPECS[layer][2]
        channel = (index // len(layer_names)) % len(requant[layer]["multiplier"])
        multiplier = requant[layer]["multiplier"][channel]
        right_shift = requant[layer]["right_shift"][channel]
        output_zero_point = tensors[output_name]["quantization"]["zero_point"][0]
        activation_min = output_zero_point if layer != "dense2" else -128
        activation_max = 127
        value = requantize_scalar(
            int(accumulator),
            int(multiplier),
            -int(right_shift),
            int(output_zero_point),
            int(activation_min),
            int(activation_max),
        )
        multipliers.append(multiplier)
        right_shifts.append(right_shift)
        output_zero_points.append(output_zero_point)
        activation_mins.append(activation_min)
        activation_maxes.append(activation_max)
        expected.append(int(value))
    write_mem(vector_dir / "requant_acc.mem", accumulators, 32)
    write_mem(vector_dir / "requant_multiplier.mem", np.asarray(multipliers), 32)
    write_mem(vector_dir / "requant_rshift.mem", np.asarray(right_shifts), 8)
    write_mem(vector_dir / "requant_output_zp.mem", np.asarray(output_zero_points), 32)
    write_mem(vector_dir / "requant_activation_min.mem", np.asarray(activation_mins), 32)
    write_mem(vector_dir / "requant_activation_max.mem", np.asarray(activation_maxes), 32)
    write_mem(vector_dir / "requant_expected.mem", np.asarray(expected), 8)


def compare(name: str, actual: np.ndarray, expected: np.ndarray):
    actual = np.asarray(actual).reshape(expected.shape)
    mismatches = np.flatnonzero(actual.reshape(-1) != expected.reshape(-1))
    if mismatches.size:
        first = int(mismatches[0])
        raise AssertionError(
            f"{name}: {mismatches.size} mismatches; first index {first}, "
            f"golden={int(actual.reshape(-1)[first])}, LiteRT={int(expected.reshape(-1)[first])}"
        )
    print(f"PASS {name}: {actual.size} values")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    mem_dir = args.output / "mem"
    vector_dir = args.output / "verification" / "vectors"
    mem_dir.mkdir(parents=True, exist_ok=True)
    vector_dir.mkdir(parents=True, exist_ok=True)

    digest = sha256(args.model)
    if digest != EXPECTED_MODEL_SHA256:
        raise RuntimeError(f"Model hash mismatch: expected {EXPECTED_MODEL_SHA256}, got {digest}")

    model = tflite.Model.GetRootAsModel(args.model.read_bytes(), 0)
    subgraph = model.Subgraphs(0)
    tensors = {name: tensor_info(subgraph, index) for name, index in TENSOR_IDS.items()}
    constants = {
        name: tensor_array(model, subgraph, TENSOR_IDS[name])
        for name in (
            "conv1_weight",
            "conv1_bias",
            "conv2_weight",
            "conv2_bias",
            "dense1_weight",
            "dense1_bias",
            "dense2_weight",
            "dense2_bias",
        )
    }

    requant = {}
    for layer in LAYER_SPECS:
        multipliers, shifts = layer_requant_params(tensors, layer)
        if np.any(shifts > 0):
            raise RuntimeError(f"{layer} requires unsupported positive requantization shift")
        requant[layer] = {
            "multiplier": multipliers.tolist(),
            "shift": shifts.tolist(),
            "right_shift": (-shifts).tolist(),
        }

    manifest = {
        "schema_version": 1,
        "model_file": args.model.name,
        "model_sha256": digest,
        "source_of_truth": True,
        "classification": {
            "type": "binary_sigmoid",
            "hardware_output": "pre_sigmoid_logit",
            "fall_when_real_logit_gt": 0.0,
            "dense2_quantized_zero": tensors["dense2_out"]["quantization"]["zero_point"][0],
        },
        "tensors": tensors,
        "requantization": requant,
        "weight_layout": {
            "conv": "OC_K_IC (TFLite tensor [OC,1,K,IC] with dimension 1 removed)",
            "dense": "OC_IC",
        },
    }
    (args.output / "model" / "model_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )

    for name, array in constants.items():
        bits = 8 if array.dtype == np.int8 else 32
        write_mem(mem_dir / f"{name}.mem", array, bits)
    write_lane_packed_conv_mem(mem_dir / "conv1_weight_lane4.mem", constants["conv1_weight"], 4)
    write_lane_packed_conv_mem(mem_dir / "conv2_weight_lane4.mem", constants["conv2_weight"], 4)
    write_lane_packed_dense_mem(mem_dir / "dense1_weight_lane4.mem", constants["dense1_weight"], 4)
    write_lane_packed_dense_mem(mem_dir / "dense2_weight_lane1.mem", constants["dense2_weight"], 1)
    for layer, params in requant.items():
        write_mem(mem_dir / f"{layer}_multiplier.mem", np.asarray(params["multiplier"]), 32)
        write_mem(mem_dir / f"{layer}_rshift.mem", np.asarray(params["right_shift"]), 8)

    input_tensor = deterministic_input()
    conv1_mul, conv1_shift = layer_requant_params(tensors, "conv1")
    conv1 = conv1d_same_int8(
        input_tensor,
        constants["conv1_weight"],
        constants["conv1_bias"],
        tensors["input"]["quantization"]["zero_point"][0],
        tensors["conv1_out"]["quantization"]["zero_point"][0],
        conv1_mul,
        conv1_shift,
        True,
    )
    pool1 = maxpool2_valid(conv1)
    conv2_mul, conv2_shift = layer_requant_params(tensors, "conv2")
    conv2 = conv1d_same_int8(
        pool1,
        constants["conv2_weight"],
        constants["conv2_bias"],
        tensors["pool1_out"]["quantization"]["zero_point"][0],
        tensors["conv2_out"]["quantization"]["zero_point"][0],
        conv2_mul,
        conv2_shift,
        True,
    )
    pool2 = maxpool2_valid(conv2)
    gap = mean_int8(
        pool2,
        tensors["pool2_out"]["quantization"],
        tensors["gap_out"]["quantization"],
    )
    dense1_mul, dense1_shift = layer_requant_params(tensors, "dense1")
    dense1 = dense_int8(
        gap,
        constants["dense1_weight"],
        constants["dense1_bias"],
        tensors["gap_out"]["quantization"]["zero_point"][0],
        tensors["dense1_out"]["quantization"]["zero_point"][0],
        dense1_mul,
        dense1_shift,
        True,
    )
    dense2_mul, dense2_shift = layer_requant_params(tensors, "dense2")
    dense2 = dense_int8(
        dense1,
        constants["dense2_weight"],
        constants["dense2_bias"],
        tensors["dense1_out"]["quantization"]["zero_point"][0],
        tensors["dense2_out"]["quantization"]["zero_point"][0],
        dense2_mul,
        dense2_shift,
        False,
    )

    golden = {
        "input": input_tensor,
        "conv1_out": conv1,
        "pool1_out": pool1,
        "conv2_out": conv2,
        "pool2_out": pool2,
        "gap_out": gap,
        "dense1_out": dense1,
        "dense2_out": dense2,
    }

    # The reference kernels define the bit-exact contract. Optimized CPU
    # delegates may legally differ by one LSB on intermediate tensors.
    interpreter = Interpreter(
        model_path=str(args.model),
        experimental_preserve_all_tensors=True,
        experimental_op_resolver_type=OpResolverType.BUILTIN_REF,
    )
    interpreter.allocate_tensors()
    interpreter.set_tensor(TENSOR_IDS["input"], input_tensor.reshape(1, 50, 9))
    interpreter.invoke()
    for name, values in golden.items():
        reference = interpreter.get_tensor(TENSOR_IDS[name])
        compare(name, values, reference.reshape(values.shape))
        write_mem(vector_dir / f"{name}.mem", values, 8)
        np.save(vector_dir / f"{name}.npy", values)

    generate_requant_vectors(tensors, requant, vector_dir)

    output_probability = interpreter.get_tensor(TENSOR_IDS["output"])
    np.save(vector_dir / "output_probability.npy", output_probability)
    write_mem(vector_dir / "output_probability.mem", output_probability, 8)
    print(f"PASS LiteRT output probability byte: {int(output_probability.reshape(-1)[0])}")
    print(f"Generated artifacts under {args.output}")


if __name__ == "__main__":
    main()
