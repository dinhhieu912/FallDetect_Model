import argparse
import csv
import json
from pathlib import Path

import numpy as np

FEATURES = ("AccX", "AccY", "AccZ", "GyrX", "GyrY", "GyrZ", "EulerX", "EulerY", "EulerZ")
INPUT_SCALE = 0.08433684706687927
INPUT_ZERO_POINT = -22


def quantize_features(rows, mean, std):
    physical = np.asarray([[float(row[name]) for name in FEATURES] for row in rows], dtype=np.float64)
    normalized = (physical - mean) / std
    return np.clip(np.rint(normalized / INPUT_SCALE) + INPUT_ZERO_POINT, -128, 127).astype(np.int8)


def dsp_energies(rows, counts_per_unit, lpf_shift):
    state = np.zeros(3, dtype=np.int64)
    previous = None
    results = []
    for index, row in enumerate(rows):
        raw = np.rint(
            np.asarray([float(row["AccX"]), float(row["AccY"]), float(row["AccZ"])])
            * counts_per_unit
        ).astype(np.int64)
        raw = np.clip(raw, -32768, 32767)
        state = state + ((raw - state) >> lpf_shift)
        accel_energy = int(np.dot(state, state))
        jerk_energy = 0 if previous is None else int(np.dot(state - previous, state - previous))
        previous = state.copy()
        results.append((index, *state.tolist(), accel_energy, jerk_energy))
    return results


def write_int8_mem(path, values):
    path.write_text("\n".join(f"{int(value) & 0xFF:02X}" for value in values.reshape(-1)) + "\n", encoding="ascii")


def main():
    parser = argparse.ArgumentParser(description="Quantize KFall-style CSV and calibrate DSP energy thresholds")
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mean", type=Path, default=Path("model/mean.npy"))
    parser.add_argument("--std", type=Path, default=Path("model/std.npy"))
    parser.add_argument("--accel-counts-per-unit", type=float, required=True,
                        help="Raw signed-16 sensor counts per acceleration unit used in the CSV")
    parser.add_argument("--lpf-shift", type=int, default=3)
    parser.add_argument("--percentile", type=float, default=99.5)
    parser.add_argument("--label-column", default=None)
    parser.add_argument("--nonfall-labels", default="0,ADL,nonfall",
                        help="Comma-separated labels used for false-trigger percentile calibration")
    args = parser.parse_args()

    with args.csv.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise RuntimeError("CSV contains no samples")
    missing = [name for name in FEATURES if name not in rows[0]]
    if missing:
        raise RuntimeError(f"CSV is missing feature columns: {missing}")
    if args.lpf_shift < 0 or args.lpf_shift > 15:
        raise ValueError("lpf-shift must be between 0 and 15")

    mean = np.load(args.mean).reshape(9)
    std = np.load(args.std).reshape(9)
    quantized = quantize_features(rows, mean, std)
    energies = dsp_energies(rows, args.accel_counts_per_unit, args.lpf_shift)
    args.output.mkdir(parents=True, exist_ok=True)
    write_int8_mem(args.output / "cnn_features_int8.mem", quantized)
    with (args.output / "dsp_energy.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(("sample", "lpf_x", "lpf_y", "lpf_z", "accel_energy", "jerk_energy"))
        writer.writerows(energies)

    calibration_rows = energies
    calibration_population = "all samples"
    if args.label_column:
        if args.label_column not in rows[0]:
            raise RuntimeError(f"CSV is missing label column {args.label_column!r}")
        nonfall = {value.strip() for value in args.nonfall_labels.split(",")}
        selected = [energy for row, energy in zip(rows, energies) if row[args.label_column].strip() in nonfall]
        if selected:
            calibration_rows = selected
            calibration_population = "non-fall samples"

    accel_values = np.asarray([row[4] for row in calibration_rows], dtype=np.float64)
    jerk_values = np.asarray([row[5] for row in calibration_rows], dtype=np.float64)
    summary = {
        "source_csv": str(args.csv),
        "sample_count": len(rows),
        "accel_counts_per_unit": args.accel_counts_per_unit,
        "lpf_shift": args.lpf_shift,
        "calibration_population": calibration_population,
        "percentile": args.percentile,
        "recommended_accel_threshold": int(np.ceil(np.percentile(accel_values, args.percentile))),
        "recommended_jerk_threshold": int(np.ceil(np.percentile(jerk_values, args.percentile))),
        "quantized_saturation_count": int(np.count_nonzero((quantized == -128) | (quantized == 127))),
    }
    (args.output / "calibration_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
