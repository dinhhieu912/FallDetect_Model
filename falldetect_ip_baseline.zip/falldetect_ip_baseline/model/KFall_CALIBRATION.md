# KFall Calibration Input

`calibrate_kfall.py` expects a CSV containing these exact columns:

`AccX, AccY, AccZ, GyrX, GyrY, GyrZ, EulerX, EulerY, EulerZ`

An optional label column may identify ADL/non-fall samples. The tool performs the frozen mean/std normalization, TFLite INT8 input quantization, signed-16 sensor-count conversion, bit-equivalent shift-IIR filtering and acceleration/jerk energy calculation.

Example:

```powershell
python model/calibrate_kfall.py `
  --csv path/to/kfall_window.csv `
  --output verification/calibration `
  --accel-counts-per-unit 16384 `
  --lpf-shift 4 `
  --label-column label `
  --nonfall-labels "0,ADL,nonfall"
```

`accel-counts-per-unit` must match the selected IMU full-scale configuration. For example, do not assume 16384 counts/g unless the actual sensor is configured for that convention.

The percentile threshold is a starting point for false-trigger control, not a trained final threshold. Final selection should measure trigger recall on fall samples and trigger rate on ADL samples, then freeze the chosen register defaults in the system specification.

Complete-dataset calibration and LPF sweep:

```powershell
python model/calibrate_kfall_dataset.py `
  --dataset "D:\KFall\KFall Dataset\KFall Dataset\sensor_data" `
  --output verification/kfall_calibration `
  --accel-counts-per-g 1024 --lpf-shift 4 `
  --target-adl-false-trigger-rate 0.20

python model/compare_dsp_operating_points.py `
  --dataset "D:\KFall\KFall Dataset\KFall Dataset\sensor_data" `
  --output verification/kfall_calibration
```
