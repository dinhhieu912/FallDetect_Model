# DSP-Gated Fall Detection Application IP

The application wrapper continuously accepts one IMU sample transaction containing raw signed 16-bit acceleration for the trigger path and nine already-quantized INT8 CNN features for the inference path.

The trigger path is `IIR LPF -> acceleration/jerk energy -> configurable consecutive-sample FSM`. Energy uses sums of squares, avoiding square-root hardware. The LPF coefficient is `2^-SHIFT`, which maps to adders and arithmetic shifts.

A 50x9 circular buffer retains the latest complete window. Once armed trigger criteria are met, acquisition is paused, the buffer drains in chronological time-major/channel-minor order, and the verified CNN starts automatically. The event output holds the quantized logit and fall decision until accepted, then the trigger and sensor path rearm.

This single-buffer policy is appropriate because the CNN latency is under one millisecond at 50 MHz while typical IMU sample intervals are several milliseconds. A ping-pong buffer is the upgrade path if acquisition must never pause.

Thresholds remain runtime inputs. The APB wrapper resets to the KFall-calibrated Q5.10 operating point: `LPF_SHIFT=4`, jerk threshold 14,325 and three consecutive suspicious samples.
