# Dense Engine Microarchitecture

The dense engine reuses the four-lane packed-ROM strategy used by Conv1D. Dense1 uses four MAC lanes and four output groups; Dense2 uses one lane. Inputs are buffered once, weights are read synchronously, and all outputs pass through the shared bit-accurate TFLite requantization contract.

Dense1 uses 32 input cycles per output group (with an explicit ROM latency cycle) and four parallel INT32 accumulators. This favors low area and deterministic timing. Dense2 is configured with one MAC lane because it has only one output logit.

The external contract is scalar ready/valid input, a command handshake after loading, scalar ready/valid output with an output-feature tag, and a one-cycle `done` pulse on final output acceptance.
