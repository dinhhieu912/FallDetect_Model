# Quantized Global Average Pool

The GAP block accumulates 12 signed INT8 samples per channel after subtracting input zero-point -128. It then uses the common TFLite Q31 requantizer with multiplier `1308363552` and right shift `2`, derived from `input_scale / (12 * output_scale)`.

Thirty-two INT32 accumulators allow the position-major stream to be accepted at one byte per cycle. One shared requantizer emits channels sequentially, minimizing area. A 32-cycle clear state avoids putting the accumulator bank on the asynchronous reset network and prepares the next inference deterministically.

The interface uses ready/valid and explicit position/channel tags. Output backpressure is supported. `done` pulses when channel 31 is accepted.
