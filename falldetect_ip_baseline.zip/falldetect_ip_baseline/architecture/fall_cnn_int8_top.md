# Integrated INT8 CNN Top

`fall_cnn_int8_top` connects Conv1, Pool1, Conv2, Pool2, GAP, Dense1 and Dense2 entirely through ready/valid interfaces. The host loads exactly one 50x9 INT8 window and issues `start`. Downstream compute engines start automatically when their complete input tensor has arrived; no cycle-count delays are used.

The output is the quantized pre-sigmoid Dense2 logit. `fall_detected` compares it with the quantized real-zero threshold, Dense2 zero-point -14. A sigmoid unit is intentionally omitted because it does not change the binary decision boundary.

The current top is the CNN core boundary. DSP gating, LPF, jerk computation, trigger policy, registers and interrupt/event stretching belong in the later application-IP wrapper.
