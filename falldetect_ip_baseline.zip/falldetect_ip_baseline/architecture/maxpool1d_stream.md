# Streaming MaxPool1D Microarchitecture

## Architecture

`maxpool1d_stream` implements signed INT8 `K=2`, `stride=2`, `VALID` pooling. It stores only the even-position sample for each channel, then compares it with the following odd-position sample. Storage is therefore `CHANNELS * 8` bits instead of a full activation buffer.

The pooling operator preserves the input quantization scale and zero-point, so no requantization hardware is required.

## Interface and ordering

- Scalar signed INT8 ready/valid input and output.
- Explicit position and channel tags.
- Required order: position-major, channel-minor.
- One-entry elastic output register supports arbitrary downstream backpressure.
- `done` pulses when the final output is accepted. For odd input lengths, it pulses after the final unpaired input is consumed.

## Datapath and timing

The datapath contains one signed 8-bit comparator, one 8-bit mux, one register per channel, and one output register. With no stall it accepts one input byte per clock and produces one output byte for every two input positions.

There is a combinational ready path from `output_ready` to `input_ready`. This is short for the current scalar pipeline. A two-entry skid buffer can break that path if physical implementation later requires it.

## Area and power

- Pool1 storage: 16 bytes.
- Pool2 storage: 32 bytes.
- No multiplier, divider, BRAM, or activation reset network.
- Registers update only on accepted stream transfers.

## Verification

`tb_maxpool1d_stream` checks all 400 Pool1 bytes with input bubbles and output backpressure. `tb_conv1_pool1_chain` checks the complete integrated Conv1-to-Pool1 ready/valid path against the frozen TFLite tensor.
