# Sensor and Feature Interface Contract

Each accepted application sample contains two synchronized views of the same IMU instant:

1. `accel_x/y/z`: signed 16-bit Q5.10 acceleration (1024 counts/g) used by the low-power DSP trigger.
2. `cnn_features_int8[9*8-1:0]`: nine model-input bytes in channel order AccX, AccY, AccZ, GyrX, GyrY, GyrZ, EulerX, EulerY, EulerZ.

The feature byte at channel `c` occupies bits `c*8 +: 8`. Fifty accepted samples are drained time-major then channel-minor into the CNN.

The raw acceleration thresholds are sum-of-squares thresholds. The frozen default contract uses Q5.10 acceleration, 100 Hz samples, `LPF_SHIFT=4`, three consecutive suspicious samples and jerk threshold 14,325. APB can override these values. A different sensor scale requires threshold rescaling before use.

The CNN features must follow the training pipeline and TFLite input quantization:

`normalized = (physical_value - mean[c]) / std[c]`

`int8 = clamp(round(normalized / 0.08433684706687927) - 22, -128, 127)`

This affine conversion can be implemented in RTL once the physical-value fixed-point representation is frozen. Keeping it outside the current wrapper prevents an implicit unit mismatch from invalidating the trained model.
