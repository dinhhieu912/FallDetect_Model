# APB3 Register Map

All registers are 32-bit, naturally aligned, and complete with zero wait states. Invalid or unaligned accesses assert `PSLVERR`.

| Address | Name | Access | Description |
|---:|---|---|---|
| 0x00 | ID | RO | `0x46414C4C` (`FALL`) |
| 0x04 | CONTROL | RW | bit 0 enable, bit 1 IRQ enable |
| 0x08 | STATUS | RO | bit 0 DSP armed, bit 1 CNN active, bit 2 event pending, bit 3 sample ready |
| 0x0C | ACCEL_THRESHOLD_LO | RW | acceleration energy threshold bits 31:0 |
| 0x10 | ACCEL_THRESHOLD_HI | RW | acceleration energy threshold bits 39:32 |
| 0x14 | JERK_THRESHOLD_LO | RW | jerk energy threshold bits 31:0 |
| 0x18 | JERK_THRESHOLD_HI | RW | jerk energy threshold bits 39:32 |
| 0x1C | TRIGGER_CFG | RW | consecutive suspicious sample count in bits 7:0 |
| 0x20 | EVENT | RO | logit bits 7:0, fall bit 8 |
| 0x24 | IRQ_STATUS | RO/W1C | event pending in bit 0; write one to clear |

The wrapper captures an application event into sticky registers and immediately acknowledges the internal pipeline, allowing monitoring to resume before firmware services the IRQ.

Reset defaults are: IP disabled, IRQ enabled, acceleration threshold at maximum, jerk threshold 14,325 and consecutive count 3. The calibrated threshold assumes signed16 Q5.10 acceleration at 100 Hz.
