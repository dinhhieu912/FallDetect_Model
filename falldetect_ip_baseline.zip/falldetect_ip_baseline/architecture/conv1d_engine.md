# Conv1D Engine Microarchitecture

## Decision

The baseline uses four INT8 MAC lanes. Conv1 has 16 output channels and Conv2 has 32, so both divide evenly into four-lane output groups.

Weights are packed into one 32-bit ROM word per kernel/input-channel tap:

- byte 0: lane 0
- byte 1: lane 1
- byte 2: lane 2
- byte 3: lane 3

The ROM address order is `output_group -> kernel_index -> input_channel`.

## Interface

- Input tensor: scalar INT8 ready/valid stream, time-major then channel-minor.
- Command: one ready/valid inference command after all input bytes are loaded.
- Output tensor: scalar INT8 ready/valid stream with explicit position and channel tags.
- `done`: one-cycle pulse on acceptance of the final output byte.
- The engine returns directly to input loading for the next window.

## Datapath

- Internal INT8 input activation memory.
- One synchronous-read packed weight ROM.
- Four signed 9x8-bit products.
- Four INT32 accumulators.
- Four shared-contract TFLite requantizers.
- SAME padding is represented by centered zero, so padded samples do not require physical memory entries.

## FSM

`LOAD -> READY -> INIT -> WEIGHT_READ -> MAC -> ... -> REQUANTIZE -> WAIT -> OUTPUT`

Each tap uses one synchronous ROM-read cycle and one MAC cycle. This conservative schedule makes ROM latency explicit and avoids a long combinational path. It can later be pipelined to one tap per cycle without changing the external interface.

## Timing estimate

For Conv1 with 50 positions, 16 output channels, 45 taps and four lanes:

- 200 output groups.
- 90 read/MAC cycles per group.
- Approximately 18,000 core MAC scheduling cycles plus initialization, requantization and output cycles.
- Expected latency remains below 0.5 ms at 50 MHz.

## Power and implementation

- Only four multipliers toggle during inference.
- No activation RAM is reset.
- FPGA mapping can use four DSP blocks and a 32-bit synchronous BRAM/distributed ROM.
- ASIC mapping can replace `sync_rom_1r` with a ROM macro wrapper.
- Clock-enable should be applied above this block; generated clocks are not used in RTL.

## Verification contract

The output order is `position-major, channel-minor` and must match all 800 bytes in `verification/vectors/conv1_out.mem`.
