create_clock -name PCLK -period 20.000 [get_ports PCLK]
set_input_delay  -clock PCLK 2.000 [remove_from_collection [all_inputs] [get_ports {PCLK PRESETn}]]
set_output_delay -clock PCLK 2.000 [all_outputs]
set_false_path -from [get_ports PRESETn]
